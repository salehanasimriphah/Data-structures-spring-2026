
#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void insertAtPosition(Node*& head, int pos, int value) {

    if (pos == 1) {
        Node* newNode = new Node;
        newNode->data = value;
        newNode->next = head;
        head = newNode;
        return;
    }

    Node* temp = head;
    int count = 1;

    while (count < pos - 1 && temp != 0) {
        temp = temp->next;
        count++;
    }

    if (temp == 0) {
        cout << "Invalid Position!" << endl;
        return;
    }

    Node* newNode = new Node;
    newNode->data = value;

    newNode->next = temp->next;
    temp->next = newNode;
}

void printList(Node* head) {
    while (head != 0) {
        cout << head->data << " ";
        head = head->next;
    }
    cout << endl;
}

int main() {

    Node* head = 0;

    insertAtPosition(head, 1, 10);
    insertAtPosition(head, 2, 20);
    insertAtPosition(head, 3, 30);

    cout << "Before Insertion: ";
    printList(head);

    insertAtPosition(head, 3, 25);

    cout << "After Insertion: ";
    printList(head);

    return 0;
}
