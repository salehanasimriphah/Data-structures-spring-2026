#include <iostream>
using namespace std;

// Define Node structure
struct Node {
    int data;
    Node* next;
};

int main() {
    // Creating three nodes manually
    Node* head = new Node();
    Node* second = new Node();
    Node* third = new Node();

    // Assign data
    head->data = 10;
    head->next = second;

    second->data = 20;
    second->next = third;

    third->data = 30;
    third->next = NULL;

    // Traversing the linked list
    Node* temp = head;   // Start from head

    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;   // Move to next node
    }

    return 0;
}
