#include<iostream>
using namespace std;
struct Node{
	Node *prev;
	int data;
	Node *next;
};
void InsertAtBegin(Node *&head,int value){
	Node *node1=new Node();
	node1->prev=NULL;
	node1->data=value;
	
	if(head==NULL){
		node1->next=NULL;
		head=node1;
		return;
	}
	
	head->prev=node1;
	node1->next=head;
	head=node1;
}
void InsertAtPosition(Node *&head,int value,int pos){
	Node *node1=new Node();
	node1->prev=NULL;
	node1->data=value;
	
	if(pos==1 && head==NULL){
		node1->next=NULL;
		head=node1;
		return;
	}
	
	if(pos!=1 && head==NULL){
		cout<<"Invalid position"<<endl;
		delete node1;
		return;
	}
	 
	if(pos==1 && head!=NULL){
		node1->next=head;
		head->prev=node1;
		head=node1;
		return;
	}
	
	Node *temp=head;
	int count=1;
	while(count<pos-1 && temp!=NULL){
		temp=temp->next;
		count++;
	}
	
	if(temp==NULL){
		cout<<"Invalid position"<<endl;
		delete node1;
		return;
	}
	
	if(temp->next==NULL){
		node1->prev=temp;
		node1->next=NULL;
		temp->next=node1;
		return;
	}
	
	node1->next=temp->next;
	temp->next->prev=node1;
	node1->prev=temp;
	temp->next=node1;
	
}
void DeleteAtPosition(Node *&head,int pos){
	
	if(head==NULL){
		cout<<"list is empty"<<endl;
		return;
	}
	
	if(pos==1 && head->next==NULL){
		cout<<"Deleting: "<<head->data<<endl;
		delete head;
		head=NULL;
		return;
	}
	
	if(pos==1 && head->next!=NULL){
		Node *del=head;
		del->next->prev=NULL;
		head=del->next;
		cout<<"Deleting: "<<del->data<<endl;
		delete del;
		return;	
	}
	
	Node *temp=head;
	int count=1;
	while(count<pos-1 && temp!=NULL){
		temp=temp->next;
		count++;
	}
	
	if(temp==NULL || temp->next==NULL){
		cout<<"Invalid position"<<endl;
		return;
	}
	
	if(temp->next->next==NULL){
		Node *del=temp->next;
		temp->next=NULL;
		cout<<"Deleting: "<< del->data<<endl;
	    delete del;
	    return;
	}
	
	Node *del=temp->next;
	temp->next=del->next;
	del->next->prev=temp;
	cout<<"Deleting: "<<del->data<<endl;
	delete del;
}
void display(Node *head){
	if(head==NULL){
		cout<<"List is empty nothing to display"<<endl;
		return;
	}
	
	Node *temp=head;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp=temp->next;
	}
	cout<<endl;
}
int main(){
	Node *head=NULL;
	
	InsertAtBegin(head,10);
	InsertAtBegin(head,20);
	InsertAtBegin(head,30);
	cout<<"Linked list: ";
	display(head);
	
	InsertAtPosition(head,15,2);
	InsertAtPosition(head,5,1);
	InsertAtPosition(head,35,6);
	cout<<"Linked list: ";
	display(head);
	
	DeleteAtPosition(head,1);
	DeleteAtPosition(head,5);
	DeleteAtPosition(head,3);
	cout<<"Linked list: ";
	display(head);
	return 0;
}