#include <iostream>
using namespace std;
#define MAX_SIZE 5
class Queue {
private:
    int myQueue[MAX_SIZE];
    int front, rear;
public:
    // Constructor
    Queue() {
        front = -1;
        rear = -1;
}

bool isEmpty() {
        return (front == -1 && rear == -1);
    }

    bool isFull() {
        return (rear == MAX_SIZE - 1);
    }

    void enQueue(int value) {
        if (isFull()) {
            cout << "Queue Overflow: Cannot EnQueue " << value << endl;
            return;
        }
        else if (isEmpty()) {
            front = rear = 0;
        }
        else {
            rear++;
        }

        myQueue[rear] = value;
        cout << "EnQueued: " << value << endl;
    }

    void deQueue() {
        if (isEmpty()) {
            cout << "Queue Underflow: Queue is Empty" << endl;
            return;
        }

        int value = myQueue[front];

        if (front == rear) {
            front = rear = -1;
        }
        else {
            front++;
        }

        cout << "DeQueued: " << value << endl;
    }

    void display() {
        if (isEmpty()) {
            cout << "Queue is Empty" << endl;
            return;
        }

        cout << "Queue elements: ";
        for (int i = front; i <= rear; i++) {
            cout << myQueue[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    Queue q;
	q.enQueue(10);
    q.enQueue(20);
    q.enQueue(30);
    q.enQueue(40);
    q.enQueue(50);

    q.display();

    q.enQueue(60); // Overflow

    q.deQueue();
    q.deQueue();

    q.display();

    q.enQueue(60); 
q.display();
return 0;
}
