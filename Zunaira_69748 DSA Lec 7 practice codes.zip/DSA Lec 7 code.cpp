#include <iostream>
using namespace std;
#define MAX_SIZE 5
class Queue {
private:
    int myQueue[MAX_SIZE];
    int front, rear;
public:
Queue() {
        front = -1;
        rear = -1;
    }

    bool isEmpty() {
        if (front == -1 && rear == -1)
            return true;
        return false;
    }

    bool isFull() {
        if (rear == MAX_SIZE - 1)
            return true;
        return false;
    }
};

int main() {
    Queue q;

    if (q.isEmpty())
        cout << "Queue is empty" << endl;
    else
        cout << "Queue is not empty" << endl;

    return 0;
}
