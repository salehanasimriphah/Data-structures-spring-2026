#include <iostream>
using namespace std;

// Node structure
struct Node
{
    int data;
    Node* left;
    Node* right;
};

// Function to create new node
Node* createNode(int value)
{
    Node* newNode = new Node();

    newNode->data = value;
    newNode->left = NULL;
    newNode->right = NULL;

    return newNode;
}

// Function to insert node in BST
Node* insert(Node* root, int value)
{
    // If tree is empty
    if(root == NULL)
    {
        return createNode(value);
    }

    // Insert in left subtree
    if(value < root->data)
    {
        root->left = insert(root->left, value);
    }

    // Insert in right subtree
    else if(value > root->data)
    {
        root->right = insert(root->right, value);
    }

    return root;
}

// Function to search element
Node* search(Node* root, int key)
{
    // Base case
    if(root == NULL || root->data == key)
    {
        return root;
    }

    // Search in right subtree
    if(key > root->data)
    {
        return search(root->right, key);
    }

    // Search in left subtree
    return search(root->left, key);
}

// Inorder Traversal
void inorder(Node* root)
{
    if(root == NULL)
    {
        return;
    }

    inorder(root->left);

    cout << root->data << " ";

    inorder(root->right);
}

int main()
{
    Node* root = NULL;

    // Insert values
    root = insert(root, 50);
    root = insert(root, 30);
    root = insert(root, 70);
    root = insert(root, 20);
    root = insert(root, 40);
    root = insert(root, 60);
    root = insert(root, 80);

    cout << "Inorder Traversal: ";
    inorder(root);

    cout << endl;

    // Search value
    int key = 60;

    Node* result = search(root, key);

    if(result != NULL)
    {
        cout << key << " found in BST";
    }
    else
    {
        cout << key << " not found in BST";
    }

    return 0;
}
