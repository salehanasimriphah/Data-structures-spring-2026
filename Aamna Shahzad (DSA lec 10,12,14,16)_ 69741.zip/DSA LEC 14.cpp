#include <iostream>
using namespace std;

// Function to print array normally
void printArray(int arr[], int size, int index)
{
    if(index == size)
        return;

    cout << arr[index] << " ";

    printArray(arr, size, index + 1);
}

// Function to print array in reverse
void printReverse(int arr[], int size, int index)
{
    if(index == size)
        return;

    printReverse(arr, size, index + 1);

    cout << arr[index] << " ";
}

int main()
{
    int arr[5] = {10, 20, 30, 40, 50};

    cout << "Normal Array: ";
    printArray(arr, 5, 0);

    cout << endl;

    cout << "Reverse Array: ";
    printReverse(arr, 5, 0);

    return 0;
}
