#include <iostream>
using namespace std;

// Function to heapify
void heapify(int arr[], int size, int i)
{
    int largest = i;

    int left = 2 * i + 1;
    int right = 2 * i + 2;

    // Check left child
    if(left < size && arr[left] > arr[largest])
    {
        largest = left;
    }

    // Check right child
    if(right < size && arr[right] > arr[largest])
    {
        largest = right;
    }

    // Swap if needed
    if(largest != i)
    {
        swap(arr[i], arr[largest]);

        heapify(arr, size, largest);
    }
}

// Function to insert element
void insertHeap(int arr[], int &size, int value)
{
    // Insert at end
    arr[size] = value;

    int index = size;

    size++;

    // Move upward
    while(index > 0)
    {
        int parent = (index - 1) / 2;

        if(arr[parent] < arr[index])
        {
            swap(arr[parent], arr[index]);

            index = parent;
        }
        else
        {
            return;
        }
    }
}

// Function to delete root element
void deleteHeap(int arr[], int &size)
{
    // Replace root with last element
    arr[0] = arr[size - 1];

    size--;

    // Heapify root
    heapify(arr, size, 0);
}

// Function to print heap
void printHeap(int arr[], int size)
{
    for(int i = 0; i < size; i++)
    {
        cout << arr[i] << " ";
    }
}

int main()
{
    int arr[20] = {50, 40, 45, 30, 35};

    int size = 5;

    cout << "Original Heap: ";
    printHeap(arr, size);

    // Insert
    insertHeap(arr, size, 60);

    cout << endl;

    cout << "After Insertion: ";
    printHeap(arr, size);

    // Delete
    deleteHeap(arr, size);

    cout << endl;

    cout << "After Deletion: ";
    printHeap(arr, size);

    return 0;
}
