#include <iostream>
using namespace std;
struct Node
{
    char data;
    Node* left;
    Node* right;
};
Node* createNode(char value)
{
    Node* newNode = new Node;
    newNode->data = value;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}
void infix(Node* root)
{
    if (root != NULL)
    {
        if (root->left != NULL) 
		cout << "(";

        infix(root->left);
        cout << root->data;
        infix(root->right);

        if (root->right != NULL) cout << ")";
    }
}
void prefix(Node* root)
{
    if (root != NULL)
    {
        cout << root->data << " ";
        prefix(root->left);
        prefix(root->right);
    }
}

void postfix(Node* root)
{
    if (root != NULL)
    {
        postfix(root->left);
        postfix(root->right);
        cout << root->data << " ";
    }
}
int main()
{

    Node* root = createNode('*');
    root->left = createNode('+');
    root->right = createNode('C');

    root->left->left = createNode('A');
    root->left->right = createNode('B');

    cout << "Infix Expression: ";
    infix(root);

    cout << "\nPrefix Expression: ";
    prefix(root);

    cout << "\nPostfix Expression: ";
    postfix(root);

    return 0;
}
