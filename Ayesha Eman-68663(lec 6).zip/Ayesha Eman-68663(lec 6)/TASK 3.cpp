#include<iostream>
using namespace std;
struct Node
{
    int data;
    Node*prev;
    Node*next;
};
Node*head=NULL;

void insertAtPosition(int pos,int value)
{
    Node*newNode=new Node();
    newNode->data=value;
    if(pos==1)
	{
        newNode->prev=NULL;
        newNode->next=head;
        if(head!=NULL)
		{
            head->prev=newNode;
        }
        head=newNode;
        return;
    }
    Node*temp=head;
    for(int i=1;i<pos-1;i++)
	{
        temp=temp->next;
        if(temp==NULL)
		{
            cout<<"Position not found";
            return;
        }
    }
    newNode->next=temp->next;
    newNode->prev=temp;
    if(temp->next!=NULL)
	{
        temp->next->prev=newNode;
    }

    temp->next=newNode;
}

void display(){
    Node*temp=head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

int main()
{
    insertAtPosition(1,10);
    insertAtPosition(2,20);
    insertAtPosition(3,30);
    insertAtPosition(4,40);   //insert at 4th position
    cout<<"Doubly Linked List:";
    display();

    return 0;
}