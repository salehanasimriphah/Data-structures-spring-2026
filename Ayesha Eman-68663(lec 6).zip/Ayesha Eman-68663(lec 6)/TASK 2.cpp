#include<iostream>
using namespace std;
struct Node
{
    int data;
    Node*prev;
    Node*next;
};

Node*head=NULL;

void insertStart(int value)
{
    Node*newNode=new Node();
    newNode->data=value;
    newNode->prev=NULL;
    newNode->next=head;
    if(head!=NULL)
	{
        head->prev=newNode;
    }
    head=newNode;
}
void display()
{
    Node*temp=head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}
int main(){
    insertStart(80);
    insertStart(30);
    insertStart(20);
    insertStart(10);

    cout<<"Doubly Linked List:";
    display();

    return 0;
}