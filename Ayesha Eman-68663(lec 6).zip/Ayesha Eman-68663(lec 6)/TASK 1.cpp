#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node*prev;
    Node*next;
};
Node*head=NULL;
//function to insert at end
void insertEnd(int value)
{
    Node*newNode=new Node();
    newNode->data=value;
    newNode->next=NULL;
    if(head==NULL)
	{
        newNode->prev=NULL;
        head=newNode;
        return;
    }
    Node*temp=head;
    while(temp->next!=NULL)
	{
        temp=temp->next;
    }
    temp->next=newNode;
    newNode->prev=temp;
}
void display()
{
    Node*temp=head;
    while(temp!=NULL)
	{
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    cout<<"NULL";
}

int main(){
    insertEnd(10);
    insertEnd(20);
    insertEnd(30);
    insertEnd(40);

    cout<<"Doubly Linked List:";
    display();

    return 0;
}