#include<iostream>
using namespace std;
struct node
{
    int data;
    node*prev;
    node*next;
};
node*head=NULL;

void insertEnd(int value)
{
    node*newNode=new node();
    newNode->data=value;
    newNode->next=NULL;
    if(head==NULL)
	{
        newNode->prev=NULL;
        head=newNode;
        return;
    }
    node*temp=head;
    while(temp->next!=NULL)
	{
        temp=temp->next;
    }
    temp->next=newNode;
    newNode->prev=temp;
}

void deleteFromEnd(node*&head)
{
    if(head==NULL)
	{
        cout<<"List is empty. No node to delete."<<endl;
        return;
    }
    if(head->next==NULL)
	{
        delete head;
        head=NULL;
        return;
    }
    node*temp=head;
    while(temp->next!=NULL)
	{
        temp=temp->next;
    }
    temp->prev->next=NULL;
    delete temp;
}

void display()
{
    node*temp=head;

    while(temp!=NULL)
	{
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

int main()
{
    insertEnd(10);
    insertEnd(20);
    insertEnd(30);
    insertEnd(40);

    cout<<"Before deletion:"<<endl;
    display();

    deleteFromEnd(head);

    cout<<"After deletion:"<<endl;
    display();

    return 0;
}