#include<iostream>
using namespace std;
struct Node
{
    int data;
    Node*prev;
    Node*next;
};
Node*head=NULL;
void insertEnd(int value)
{
    Node*newNode=new Node();
    newNode->data=value;
    newNode->next=NULL;
    if(head==NULL)
	{
        newNode->prev=NULL;
        head=newNode;
        return;
    }
    Node*temp=head;
    while(temp->next!=NULL)
	{
        temp=temp->next;
    }
    temp->next=newNode;
    newNode->prev=temp;
}
void deleteStart()
{
    if(head==NULL)
	{
        cout<<"List is empty";
        return;
    }
    Node*temp=head;
    head=head->next;
    if(head!=NULL)
	{
        head->prev=NULL;
    }
    delete temp;
}
void display()
{
    Node*temp=head;
    while(temp!=NULL)
	{
        cout<<temp->data<<"  ";
        temp=temp->next;
    }
}

int main()
{
    insertEnd(10);
    insertEnd(20);
    insertEnd(30);
    insertEnd(40);

    cout<<"Before deletion:"<<endl;
    display();

    deleteStart();

    cout<<"After deletion:"<<endl;
    display();

    return 0;
}