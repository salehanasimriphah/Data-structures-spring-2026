#include <iostream>
using namespace std;
struct Node {
    int data;
    Node* next;
};
class CircularQueue {
private:
    Node* front;
    Node* rear;

public:
    CircularQueue() {
        front = rear = NULL;
    }
    void enqueue(int value) {
        Node* newNode = new Node;
        newNode->data = value;
        newNode->next = NULL;

        if (front == NULL) {
            front = rear = newNode;
            rear->next = front;
        }
		else {
            rear->next = newNode;
            rear = newNode;
            rear->next = front;  
        }
        cout << "Inserted: " << value << endl;
    }
    void dequeue() {
        if (front == NULL) {
            cout << "Queue is empty!\n";
            return;
        }

        if (front == rear) {
            cout << "Deleted: " << front->data << endl;
            delete front;
            front = rear = NULL;
        }
		else {
            Node* temp = front;
            cout << "Deleted: " << temp->data << endl;
            front = front->next;
            rear->next = front;  
            delete temp;
        }
    }
    void display() {
        if (front == NULL) {
            cout << "Queue is empty!\n";
            return;
        }

        Node* temp = front;
        cout << "Circular Queue elements: ";
        do {
            cout << temp->data << " ";
            temp = temp->next;
        } 
		while (temp != front);
        cout << endl;
    }
};
int main() {
    CircularQueue cq;
    int choice, value;

    do {
        cout << "\n1. Enqueue\n2. Dequeue\n3. Display\n4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value to insert: ";
                cin >> value;
                cq.enqueue(value);
                break;

            case 2:
                cq.dequeue();
                break;

            case 3:
                cq.display();
                break;

            case 4:
                cout << "Exiting...\n";
                break;

            default:
                cout << "Invalid choice!\n";
        }
    } while (choice != 4);

    return 0;
}
