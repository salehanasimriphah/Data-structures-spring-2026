#include <bits/stdc++.h>
using namespace std;

struct Queue {
    string customers[5];   
    int front;
    int rear;
    int size;
    int MAX;               

    Queue() {
        front = -1;
        rear = -1;
        size = 0;
        MAX = 5;          
    }

    bool isEmpty() {
        return (size == 0);
    }

    bool isFull() {
        return (size == MAX);
    }

    void enqueue(string customer) {
        if (isFull()) {
            cout << "Queue is FULL!" << endl;
            return;
        }

        if (front == -1) {
            front = 0;    
        }

        rear = (rear + 1) % MAX;
        customers[rear] = customer;
        size++;

        cout << customer << " has arrived and joined the queue." << endl;
        display();
    }

    void dequeue() {
        if (isEmpty()) {
            cout << "Queue is EMPTY!" << endl;
            return;
        }

        string served = customers[front];

        if (size == 1) {
            front = -1;
            rear = -1;
        } else {
            front = (front + 1) % MAX;
        }
        size--;

        cout << served << " has been served and removed from the queue." << endl;
        display();
    }

    void display() {
        if (isEmpty()) {
            cout << "Current waiting queue: [EMPTY]" << endl;
            return;
        }

        cout << "Current waiting queue: ";
        int i = front;
        for (int count = 0; count < size; count++) {
            cout << customers[i];
            if (count < size - 1) {
                cout << " <- ";
            }
            i = (i + 1) % MAX;
        }
        cout << endl;
    }
};

int main() {
    Queue ticketQueue;
    int choice;
    string customer;
    cout << "TICKET COUNTER" << endl; 
    cout << "Maximum queue capacity: " << ticketQueue.MAX << " customers\n" << endl;

    while (true) {
        cout << "\nMENU " << endl;
        cout << "1. Customer Arrives (Enqueue)" << endl;
        cout << "2. Issue Ticket (Dequeue)" << endl;
        cout << "3. Show Current Queue" << endl;
        cout << "4. Exit..." << endl;
        cout << "Enter your choice (1-4): ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter arriving customer name: ";
                cin >> customer;
                ticketQueue.enqueue(customer);
                break;

            case 2:
                ticketQueue.dequeue();
                break;

            case 3:
                ticketQueue.display();
                break;

            case 4:
                cout << "\nExiting... Thank you!" << endl;
                return 0;

            default:
                cout << "Invalid choice!" << endl;
        }
    }

    return 0;
}
