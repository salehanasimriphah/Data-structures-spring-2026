#include<iostream>
using namespace std;
struct Node{
	Node *prev;
    int data;
	Node *next;	
};
void InsertAtBegin(Node *&head,int value){
	Node *node1=new Node();
	node1->data=value;
	
	if(head==NULL){
		node1->next=node1;
		node1->prev=node1;
		head=node1;
		return;
	}
	
	Node *temp=head->prev;
	
	node1->next=head;
	head->prev=node1;
	node1->prev=temp;
	temp->next=node1;
	head=node1;
}
void InsertAtEnd(Node *&head,int value){
	Node *node1=new Node();
	node1->data=value;
	
	if(head==NULL){
		node1->next=node1;
		node1->prev=node1;
		head=node1;
		return;
	}
	
	Node *temp=head->prev;
	temp->next=node1;
	node1->prev=temp;
	node1->next=head;
	head->prev=node1;
}
void InsertAtPosition(Node *&head,int value,int pos){
	Node *node1=new Node();
	node1->data=value;
	
	if(pos==1 && head==NULL){
		node1->next=node1;
		node1->prev=node1;
		head=node1;
		return;
	}
	
	if(pos==1 && head->next==head){
		node1->next =head;
		node1->prev=head;
		head->prev=node1;
		head->next=node1;
		head=node1;
		return;
	}
	
	if(pos==1 && head!=NULL){
		Node *temp=head->prev;
		node1->next=head;
		node1->prev=temp;
		head->prev=node1;
		temp->next=node1;
		head=node1;
		return;
	}
	
	Node *temp=head;
	int count=1;
	while(count<pos-1 && temp->next!=head){
		temp=temp->next;
		count++;
	}
	
	if(count<pos-1){
		cout<<"Invalid Position"<<endl;
		delete node1;
		return;
	}
	
	node1->next=temp->next;
	temp->next->prev=node1;
	node1->prev=temp;
	temp->next=node1;
	
}
void DeleteAtBegin(Node *&head){
	 if(head==NULL){
	 	cout<<"List is empty Nothing to delete"<<endl;
	 	return;
	 }
	 
	 if(head->next==head){
	 	cout<<"Deleting: "<<head->data<<endl;
	 	delete head;
	 	head=NULL;
	 	return;
	 }
	 
	 Node *temp=head->prev;
	 Node *del=head;
	 del->next->prev=temp;
	 temp->next=del->next;
	 cout<<"Deleting: "<<del->data<<endl;
	 delete del;
}
void DeleteAtEnd(Node *&head){
	if(head==NULL){
	 	cout<<"List is empty Nothing to delete"<<endl;
	 	return;
	}
	 
	if(head->next==head){
	 	cout<<"Deleting: "<<head->data<<endl;
	 	delete head;
	 	head=NULL;
	 	return;
	 }
	 
	Node *temp=head->prev;
	temp->prev->next=head;
	head->prev=temp->prev;
	cout<<"Deleting: "<<temp->data<<endl;
	delete temp;
}
void DeleteAtPosition(Node *&head,int pos){
	if(pos==1 && head==NULL){
		cout<<"Invalid Position"<<endl;
		return;
	}
	
	if(pos==1 && head->next==head){
		cout<<"Deleting: "<<head->data<<endl;
	 	delete head;
	 	head=NULL;
	 	return;
	}
	
	if(pos==1 && head!=NULL){
		Node *temp=head->prev;
		head->next->prev=temp;
		temp->next=head->next;
		Node *del=head;
		head=head->next;
		cout<<"Deleting: "<<del->data<<endl;
	 	delete del;
	 	return;
	}
	
	Node *temp=head;
	int count=1;
	while(count<pos-1 && temp->next!=head){
		temp=temp->next;
		count++;
	}
	
	if(count<pos-1 || temp->next==head){
		cout<<"Invalid Position"<<endl;
		return;
	}
	
	Node *del=temp->next;
    temp->next=del->next;
    del->next->prev=temp;
	cout<<"Deleting: "<<del->data<<endl;
	delete del;
}
void display(Node *head){
	if(head==NULL){
		cout<<"list is empty Nothing to display"<<endl;
		return;
	}
	
	Node *temp=head;
	while(temp->next!=head){
		cout<<temp->data<<" ";
		temp=temp->next;
	};
	cout<<temp->data<<" ";
	cout<<endl;
}
int main(){
	Node *head=NULL;
	int choice;
	do{
		cout<<"------------- Menu ------------"<<endl;
		cout<<"1. Insert at begin"<<endl;
		cout<<"2. Insert at end"<<endl;
		cout<<"3. Insert at specific position"<<endl;
		cout<<"4. Delete at begin"<<endl;
		cout<<"5. Delete at end"<<endl;
		cout<<"6. Delete at specific position"<<endl;
		cout<<"7. Display"<<endl;
		cout<<"8. Exit"<<endl;
		cout<<endl;
		
		cout<<"Enter your choice: ";
		cin>>choice;
		
		switch(choice){
			case 1:
				int value1;
				cout<<"Enter the value: ";
				cin>>value1;
				InsertAtBegin(head,value1);
				display(head);
				break;
			case 2:
				int value2;
				cout<<"Enter the value: ";
				cin>>value2;
				InsertAtEnd(head,value2);
				display(head);
				break;
			case 3:
			    int value3;
				cout<<"Enter the value: ";
				cin>>value3;
				int position;
				cout<<"Enter the position: ";
				cin>>position;
				InsertAtPosition(head,value3,position);
				display(head);
				break;
			case 4:
				DeleteAtBegin(head);
				display(head);
				break;
			case 5:
				DeleteAtEnd(head);
				display(head);
				break;
			case 6:
				int position1;
				cout<<"Enter the position: ";
				cin>>position1;
				DeleteAtPosition(head,position1);
				display(head);
				break;
			case 7:
				display(head);
				break;
			case 8:
				cout<<"Exiting....."<<endl;
				break;
			default:
				cout<<"Invalid Choice!"<<endl;
				break;
		}
		
	}while(choice!=8);
	
	return 0;
	
	
}