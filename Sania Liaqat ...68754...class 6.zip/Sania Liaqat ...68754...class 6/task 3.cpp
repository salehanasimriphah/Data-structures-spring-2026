#include<iostream>
using namespace std;


struct Node{
	int data;
	Node*next;
	Node*prev;
};

void deleteFromEnd(Node*head) 
{
 if (head == NULL)
 {
cout << "List is empty. No node to delete." << endl;
return;
 }
 if (head->next == NULL) 
{
    delete head;
    head = NULL;
}
Node* temp = head;
while (temp->next != NULL) 
{
 temp = temp->next;
}
temp->prev->next = NULL;
 delete temp;
 }
 void display(Node* head)
 {
    Node* temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

int main(){
	Node* head=NULL;

    deleteFromEnd(head);
    

    display(head);
}

