#include<iostream>
using namespace std;

struct Node{
	int data;
	Node*next;
	Node*prev;
};

void insertatbeginning(Node*&head,int value){
	Node* newNode=new Node;
	newNode->data=value;
	newNode->next=head;
	newNode->prev=NULL;
	
	if(head!=NULL){
		head->prev=newNode;
	}
	head=newNode;
}
void display(Node* head)
{
    Node* temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

int main(){
	Node* head=NULL;

    insertatbeginning(head,10);
    insertatbeginning(head,20);
    insertatbeginning(head,30);

    display(head);
}
