#include<iostream>
using namespace std;

struct Node{
	int data;
	Node*next;
	Node*prev;
};

void deleteFromStart(Node* &head) {
	Node* newNode=new Node;
	newNode->next=NULL;
	newNode->prev=NULL;
        if (head == NULL) {
            cout << "List is empty. No node to delete." << endl;
            return;
        }
        Node* temp = head;
        head = head->next;
        if (head != NULL) {
            head->prev = NULL;
        }
        delete temp;
    }
    
void display(Node* head)
{
    Node* temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

int main(){
	Node* head=NULL;

    deleteFromStart(head);
    

    display(head);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
