//Rihab Sajid
//69585
#include<iostream>
using namespace std;
struct Node
{
    int data;
    Node* next;
    Node* prev;
};
void InsertAtPosition(Node* &head,int value,int pos)
{
    Node* newnode = new Node();
    newnode->data = value;
    newnode->prev = NULL;
    newnode->next = NULL; 
if(pos==1)
{
    if(head != NULL)
    {
        head->prev = newnode;
        newnode->next=head;
    }
head=newnode;
return;
}
    Node*temp=head;
for(int i=1;i<pos-1 &&temp!=NULL;i++)
{
    temp=temp->next;
}
if(temp==NULL)
{
	cout<<"Position out of range"<<endl;
	return;
}
	newnode->next=temp->next;
	newnode->prev=temp;
if(temp->next != NULL)
{
    temp->next->prev = newnode;
}
    temp->next = newnode;
}
void DeleteAtPosition(Node*&head,int pos)
{
if(head == NULL)
{
    cout<<"List empty"<<endl;
    return;
}
    Node*temp=head;
if(pos == 1)
{
head = temp->next;
    if(head != NULL)
    {
    head->prev = NULL;
    }
delete temp;
return;
}
for(int i=1;i<pos &&temp!=NULL;i++)
{
    temp=temp->next;
}
if(temp==NULL)
{
	cout<<"Position out of range"<<endl;
}
if(temp->prev!=NULL)
{
	temp->prev->next=temp->next;
    if(temp->next!= NULL)
    {
    temp->next->prev = temp->prev;
    }
    delete temp;
}
}
void printlist(Node* head)
{
    Node* temp = head;
    while(temp != NULL)
    {
        cout<<temp->data<<" "<<endl;
        temp = temp->next;
    }
    cout<<endl;
}
int main()
{
    Node* head = NULL;
    cout<<"Insert operations:"<<endl;
    InsertAtPosition(head,25,1);
    printlist(head);
    InsertAtPosition(head,30,2);
    printlist(head);
    InsertAtPosition(head,40,3);
    printlist(head);
    InsertAtPosition(head,45,1);
    printlist(head);
    InsertAtPosition(head,50,3);
    printlist(head);
    cout<<"Delete operations:"<<endl;
    DeleteAtPosition(head,3);
    printlist(head);
    DeleteAtPosition(head,4);
    printlist(head);
    return 0;
}

