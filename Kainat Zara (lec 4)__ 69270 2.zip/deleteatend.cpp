#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
};

void insertAtTail(Node* &head, int val)
{
    Node* ptr = new Node;
    ptr->data = val;
    ptr->next = NULL;

    if(head == NULL)
    {
        head = ptr;
        return;
    }

    Node* temp = head;

    while(temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = ptr;
}


void deleteAtEnd(Node* &head)
{
    if(head == NULL)
    {
        cout << "List is empty!" << endl;
        return;
    }

    if(head->next == NULL)
    {
        delete head;
        head = NULL;
        return;
    }

    Node* temp = head;

    while(temp->next->next != NULL)
    {
        temp = temp->next;
    }

    delete temp->next;
    temp->next = NULL;
}


void display(Node* head)
{
    Node* temp = head;

    while(temp != NULL)
    {
        cout << temp->data;

        if(temp->next != NULL)
            cout << "->";

        temp = temp->next;
    }

    cout << endl;
}

int main()
{
    Node* head = NULL;

    insertAtTail(head, 10);
    insertAtTail(head, 20);
    insertAtTail(head, 30);

    cout << "Before Deletion: ";
    display(head);

    deleteAtEnd(head);

    cout << "After Deleting End: ";
    display(head);

    return 0;
}
