#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
};


void insertAtTail(Node* &head, int val)
{
    Node* ptr = new Node;
    ptr->data = val;
    ptr->next = NULL;

    if(head == NULL)
    {
        head = ptr;
        return;
    }

    Node* temp = head;

    while(temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = ptr;
}


void display(Node* head)
{
    Node* temp = head;

    while(temp != NULL)
    {
        cout << temp->data;
        if(temp->next != NULL)
            cout << "->";
        temp = temp->next;
    }

    cout << endl;
}


bool search(Node* head, int key)
{
    Node* temp = head;

    while(temp != NULL)
    {
        if(temp->data == key)
        {
            return true;
        }
        temp = temp->next;
    }

    return false;
}

int main()
{
    Node* head = NULL;

    insertAtTail(head, 10);
    insertAtTail(head, 20);
    insertAtTail(head, 30);
    insertAtTail(head, 40);

    display(head);

    int key;
    cout << "Enter value to search: ";
    cin >> key;

    if(search(head, key))
        cout << "Value Found" << endl;
    else
        cout << "Value Not Found" << endl;

    return 0;
}
