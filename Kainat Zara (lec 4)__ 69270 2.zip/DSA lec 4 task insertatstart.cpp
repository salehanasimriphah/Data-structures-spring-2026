#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
};

// Insert at Start
void insertAtStart(Node* &head, int n)
{
    Node* newNode = new Node;
    newNode->data = n;
    newNode->next = head;
    head = newNode;
}

// Display Function
void display(Node* head)
{
    Node* temp = head;

    while(temp != NULL)
    {
        cout << temp->data << "->";
        temp = temp->next;
    }

    cout << "NULL" << endl;
}

int main()
{
    

    insertAtStart(head, 10);
    insertAtStart(head, 20);
    insertAtStart(head, 30);

    display(head);

    return 0;
}
	
