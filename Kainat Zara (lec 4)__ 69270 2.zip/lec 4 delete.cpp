#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
};


void insertAtTail(Node* &head, int val)
{
    Node* ptr = new Node;
    ptr->data = val;
    ptr->next = NULL;

    if(head == NULL)
    {
        head = ptr;
        return;
    }

    Node* temp = head;

    while(temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = ptr;
}


void deleteAtHead(Node* &head)
{
    if(head == NULL)
    {
        cout << "List is already empty!" << endl;
        return;
    }

    Node* ptr = head;
    head = head->next;
    delete ptr;
}


void display(Node* head)
{
    Node* temp = head;

    while(temp != NULL)
    {
        cout << temp->data << "->";
        temp = temp->next;
    }

    cout << "NULL" << endl;
}

int main()
{
    Node* head = NULL;

    insertAtTail(head, 10);
    insertAtTail(head, 20);
    insertAtTail(head, 30);

    cout << "Before Deletion: ";
    display(head);

    deleteAtHead(head);

    cout << "After Deleting Head: ";
    display(head);

    return 0;
}
