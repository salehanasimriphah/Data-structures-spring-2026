#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
};


void insertAtTail(Node* &head, int val)
{
    Node* ptr = new Node;
    ptr->data = val;
    ptr->next = NULL;

    if(head == NULL)
    {
        head = ptr;
        return;
    }

    Node* temp = head;

    while(temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = ptr;
}


void insertAtPosition(Node* &head, int val, int pos)
{
    Node* newNode = new Node;
    newNode->data = val;
    newNode->next = NULL;

    
    if(pos == 1)
    {
        newNode->next = head;
        head = newNode;
        return;
    }

    Node* temp = head;

    for(int i = 1; temp != NULL && i < pos-1; i++)
    {
        temp = temp->next;
    }

    if(temp == NULL)
    {
        cout << "Invalid Position!" << endl;
        delete newNode;
        return;
    }

    newNode->next = temp->next;
    temp->next = newNode;
}

void display(Node* head)
{
    Node* temp = head;

    while(temp != NULL)
    {
        cout << temp->data;
        if(temp->next != NULL)
            cout << "->";
        temp = temp->next;
    }

    cout << endl;
}

int main()
{
    Node* head = NULL;

    insertAtTail(head, 10);
    insertAtTail(head, 20);
    insertAtTail(head, 40);

    cout << "Before Insertion: ";
    display(head);

    insertAtPosition(head, 30, 3);

    cout << "After Inserting 30 at Position 3: ";
    display(head);

    return 0;
}
