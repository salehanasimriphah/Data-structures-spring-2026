#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
};


void insertAtTail(Node* &head, int val)
{
    Node* ptr = new Node;
    ptr->data = val;
    ptr->next = NULL;

    if(head == NULL)
    {
        head = ptr;
        return;
    }

    Node* temp = head;

    while(temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = ptr;
}


void deleteAtPosition(Node* &head, int pos)
{
    if(head == NULL)
    {
        cout << "List is empty!" << endl;
        return;
    }

    
    if(pos == 1)
    {
        Node* ptr = head;
        head = head->next;
        delete ptr;
        return;
    }

    Node* temp = head;

    for(int i = 1; temp != NULL && i < pos-1; i++)
    {
        temp = temp->next;
    }

    if(temp == NULL || temp->next == NULL)
    {
        cout << "Invalid Position!" << endl;
        return;
    }

    Node* ptr = temp->next;
    temp->next = ptr->next;
    delete ptr;
}


void display(Node* head)
{
    Node* temp = head;

    while(temp != NULL)
    {
        cout << temp->data;

        if(temp->next != NULL)
            cout << "->";

        temp = temp->next;
    }

    cout << endl;
}

int main()
{
    Node* head = NULL;

    insertAtTail(head, 10);
    insertAtTail(head, 20);
    insertAtTail(head, 30);
    insertAtTail(head, 40);

    cout << "Before Deletion: ";
    display(head);

    deleteAtPosition(head, 3);

    cout << "After Deleting Position 3: ";
    display(head);

    return 0;
}
