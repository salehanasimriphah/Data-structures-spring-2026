#include<iostream>
using namespace std;
struct Node {
    int data;
    Node* next;
};
Node* head = NULL;
void InsertatBeginning(int value){
	Node* newNode = new Node;
    newNode->data = value;
    newNode->next = head;
    head = newNode;
    cout << "Inserted at beginning successfully.\n";
}
void InsertatEnd(int value){
	Node* newNode = new Node;
    newNode->data = value;
    newNode->next = NULL;
    if(head == NULL){
        head = newNode;
    }
	else{
        Node* temp = head;
        while(temp->next != NULL){
            temp = temp->next;
        }
        temp->next = newNode;
    }
    cout << "Inserted at end successfully.\n";
	
}
void InsertatSpecificPosition(int value, int posit){
	 if (posit < 0) {
        cout << "Invalid position.\n";
        return;
    }

    if (posit == 0) {
        InsertatBeginning(value);
        return;
    }

    Node* temp = head;
    for (int i = 0; i < posit - 1 && temp != NULL; i++) {
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Invalid position.\n";
        return;
    }

    Node* newNode = new Node;
    newNode->data = value;
    newNode->next = temp->next;
    temp->next = newNode;

    cout << "Inserted successfully.\n";
}
void DisplayList(){
	if (head == NULL){
        cout << "List is empty.\n";
        return;
    }
    Node* temp = head;
    cout << "List elements: ";
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main(){
	int choice, value, posit;

    do {
        cout << "\n===== MENU =====\n";
        cout << "1. Insert at Beginning\n";
        cout << "2. Insert at End\n";
        cout << "3. Insert at Specific Position\n";
        cout << "4. Display List\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value: ";
                cin >> value;
                InsertatBeginning(value);
                break;

            case 2:
                cout << "Enter value: ";
                cin >> value;
                InsertatEnd(value);
                break;

            case 3:
                cout << "Enter value: ";
                cin >> value;
                cout << "Enter position : ";
                cin >> posit;
                InsertatSpecificPosition(value, posit);
                break;

            case 4:
                DisplayList();
                break;

            case 5:
                cout << "Exiting program...\n";
                break;
            default:
                cout << "Invalid choice. Try again.\n";
        }

    } while (choice != 5);

    return 0;
}
