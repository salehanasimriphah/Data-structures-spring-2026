#include <iostream>
#include <algorithm> 
using namespace std;

struct Node {
    int key;
    Node* left;
    Node* right;
    int height; 

    Node(int val) : key(val), left(nullptr), right(nullptr), height(1) {}
};

class AVLTree {
private:
    Node* root;

    int getHeight(Node* N) {
        if (N == nullptr){
            return 0;
        }
        return N->height;
    }

    
    int getBalanceFactor(Node* N) {
        if (N == nullptr){
            return 0;
        }
        return getHeight(N->left) - getHeight(N->right);
    }

    
    void updateHeight(Node* N) {
        
        N->height = 1 + max(getHeight(N->left), getHeight(N->right));
    }

   
    Node* rightRotate(Node* y) {
        Node* x = y->left;
        Node* T2 = x->right;

       
        x->right = y;
        y->left = T2;

       
        updateHeight(y);
        updateHeight(x);

       
        return x;
    }

   
    Node* leftRotate(Node* x) {
        Node* y = x->right;
        Node* T2 = y->left;

        
        y->left = x;
        x->right = T2;

       
        updateHeight(x);
        updateHeight(y);

        
        return y;
    }

   
    Node* insertRecursive(Node* node, int key) {
       
        if (node == nullptr){
		   return new Node(key);
	    }
       
        if (key < node->key){
            node->left = insertRecursive(node->left, key);
        }
        else if (key > node->key){
            node->right = insertRecursive(node->right, key);
        }
        else{ 
            return node;
        }

       
        updateHeight(node);

        
        int balance = getBalanceFactor(node);

        
        if (balance > 1 && key < node->left->key){
            return rightRotate(node);
        }

       
        if (balance < -1 && key > node->right->key){
            return leftRotate(node);
        }

       
        if (balance > 1 && key > node->left->key) {
            node->left = leftRotate(node->left); 
            return rightRotate(node);          
        }

      
        if (balance < -1 && key < node->right->key) {
            node->right = rightRotate(node->right); 
            return leftRotate(node);            
        }

        
        return node;
      }


    bool searchRecursive(Node* node, int key) {
        if (node == nullptr){
            return false;
        }
       
        if (key == node->key){
            return true;
        }
        else if (key < node->key){
            return searchRecursive(node->left, key);
        }
        else{
            return searchRecursive(node->right, key);
        }
    }

   
    void inorder(Node* root) {
        if (root != nullptr) {
            inorder(root->left);
            cout << root->key << "(BF:" << getBalanceFactor(root) << ") ";
            inorder(root->right);
        }
    }

public:
    AVLTree() : root(nullptr) {}

    
    void insert(int key) {
        root = insertRecursive(root, key);
    }

   
    bool search(int key) {
        return searchRecursive(root, key);
    }

    
    void printInorder() {
        cout << "Inorder Traversal (Sorted, with BF):" << endl;
        inorder(root);
        cout << endl;
    }
};

int main() {
    AVLTree tree;

    cout << "--- AVL Tree Demonstration ---" << endl;
   
    cout << "\nInserting: 90, 50 (Initial Skew)" << endl;
    tree.insert(90);
    tree.insert(50);
    tree.printInorder();

    cout << "\n--- Inserting 70 (Triggers L-R Double Rotation at 90) ---" << endl;
    tree.insert(70);
   
    cout << "Tree after L-R Rotation:" << endl;
    tree.printInorder();

   
    int searchKey = 90;
    cout << "\nSearching for " << searchKey << ": " << (tree.search(searchKey) ? "Found" : "Not Found") << endl;

    cout << "\nInserting more values: 10, 40, 80, 100" << endl;
    tree.insert(10);
    tree.insert(40);
    tree.insert(80);
    tree.insert(100);
   
    cout << "Final Tree State:" << endl;
    tree.printInorder();
   
    return 0;
}

