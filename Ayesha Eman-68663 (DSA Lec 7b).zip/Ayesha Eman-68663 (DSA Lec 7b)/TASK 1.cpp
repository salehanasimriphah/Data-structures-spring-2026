#include <iostream>
using namespace std;
#define MAX_SIZE 5

class Queue 
{
private:
    int myQueue[MAX_SIZE];
    int front, rear;
public:
    Queue() 
	{
        front=-1;
        rear=-1;
    }
    bool isEmpty() 
	{
        return(front == -1&&rear == -1);
    }
    bool isFull() 
	{
        return(rear == MAX_SIZE - 1);
    }
    void enqueue(int value) 
	{
        if(isFull()) 
		{
            cout<<"Queue is full!Cannot enqueue "<<value<<endl;
            return;
        }
        if(isEmpty()) 
		{
            front=0;
        }
        rear++;
        myQueue[rear]=value;
        cout<<value<<" enqueued successfully."<<endl;
    }
    int dequeue() 
	{
        if(isEmpty()) 
		{
            cout<<"Queue is empty! Cannot dequeue."<<endl;
            return -1;
        }
        int removed=myQueue[front];
        if(front == rear) 
		{
            front=-1;
            rear=-1;
        } else {
            front++;
        }
        return removed;
    }
    void display() 
	{
        if(isEmpty()) 
		{
            cout<<"Queue is empty."<<endl;
            return;
        }
        cout<<"Queue elements: ";
        for(int i=front; i <= rear; i++) 
		{
            cout<<myQueue[i]<<" ";
        }
        cout<<endl;
    }
};
int main() {
    Queue q;
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.display();
    cout<<"Dequeued: "<<q.dequeue()<<endl;
    q.display();
    q.enqueue(40);
    q.enqueue(50);
    q.enqueue(60); 
    q.display();

    return 0;
}
