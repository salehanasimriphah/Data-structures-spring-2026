#include<iostream>
#include<conio.h>
using namespace std;
int *min(int &x,int &y){
	if(x<y){
	  return(&x);
	}
	else{
		return(&y);
	}
}
int main(){
	int a,b,*c;
	cout<<"enter the value of a: ";
	cin>>a;
	cout<<"enter the value of b: ";
	cin>>b;
	
	c=min(a,b);
	cout<<"The minimum number is: "<<*c<<endl;
	getch();
	return 0;
}