#include<iostream>
#include<conio.h>
using namespace std;
class Parent{
	public:
	   void show(){
	   	cout<<"Base Function"<<endl;
	   }	
};
class Child:public Parent{
	public:
	   void show(){
	   	cout<<"Derived Function"<<endl;
	   }
};
int main(){
	Child obj;
	obj.Parent::show();
	getch();
	return 0;
}