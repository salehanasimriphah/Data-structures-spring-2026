#include<iostream>
#include<conio.h>
using namespace std;

int main(){
	int x=10;
	int y=20;
	
	cout<<"x: "<<x<<endl;
	cout<<"&x: "<<&x<<endl;
	cout<<"y: "<<y<<endl;
	cout<<"&y: "<<&y<<endl;
	
	int *p=&x;
	p=&y;
	*p=y;
	cout<<"p: "<<p<<endl;
	cout<<"*p: "<<*p<<endl;
	
	getch();
	return 0;
}