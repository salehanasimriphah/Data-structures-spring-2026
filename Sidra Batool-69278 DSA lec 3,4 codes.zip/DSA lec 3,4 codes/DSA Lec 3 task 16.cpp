#include<iostream>
#include<conio.h>
using namespace std;

int main(){
	const int x=10;
	const int y=20;
	
	int *const p=&x;
	*p=20;
	p=&y;
	
	getch();
	return 0;
}