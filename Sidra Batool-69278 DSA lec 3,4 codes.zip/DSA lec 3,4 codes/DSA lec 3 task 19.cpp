#include<iostream>
#include<conio.h>
using namespace std;
void swap(int *a,int *b){
	int temp=*a;
	*a=*b;
	*b=temp;
}
int main(){
	int x=5;
	int y=6;
	cout<<"x: "<<x<<" y: "<<y<<endl;
	swap(&x,&y);
	cout<<"x: "<<x<<" y: "<<y<<endl;
	getch();
	return 0;
}