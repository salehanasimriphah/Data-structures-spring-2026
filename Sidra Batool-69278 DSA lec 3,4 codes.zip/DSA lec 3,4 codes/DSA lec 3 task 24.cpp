#include<iostream>
#include<conio.h>
using namespace std;
struct Student{
	int rollno;
	char name[20];
};
int main(){
	Student s1;
	cout<<"Enter name: ";
	cin>>s1.name;
	cout<<"Enter rollno: ";
	cin>>s1.rollno;
	
	Student *s=&s1;
	cout<<"Name: "<<s->name<<" Rollno: "<<s->rollno<<endl;
	getch();
	return 0;
}