#include<iostream>
#include<conio.h>
using namespace std;

int main(){
	const int x=10;
	int y=20;
	
	const int *p=&x;
	*p=20;
	p=&y;
	
	getch();
	return 0;
}