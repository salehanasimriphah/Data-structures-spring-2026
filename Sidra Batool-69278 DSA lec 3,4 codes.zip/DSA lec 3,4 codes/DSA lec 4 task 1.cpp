#include<iostream>
#include<conio.h>
using namespace std;
class Animal{
	public:
		string name;
		string breed;
		int age;
	public:
		void eat(){
			cout<<name<<" is eating"<<endl;
		}
		void play(){
			cout<<name<<" is playing"<<endl;
		}
		void sleep(){
			cout<<name<<" is sleeping"<<endl;
		}
};
int main(){
	Animal dog;
	dog.name="Buddy";
	dog.breed="Golden Retriever";
	dog.age=5;
	
	cout<<"My dog name is "<<dog.name<<endl;
	dog.eat();
	dog.play();
	dog.sleep();
	
	getch();
	return 0;
}