#include<iostream>
#include<conio.h>
using namespace std;
class Student{
	public:
		string name;
		int age;
		
	public:
		Student(){
			name="Sana";
			age=20;
		}
		void show(){
			cout<<"Name: "<<name<<endl;
			cout<<"Age: "<<age<<endl;
		}
};
int main(){
	Student s;
	s.show();
	getch();
	return 0;
}