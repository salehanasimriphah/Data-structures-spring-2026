#include<iostream>
#include<conio.h>
using namespace std;
class Student{
	public:
		string name;
		int age;
		
	public:
		Student(string n, int a){
			name=n;
			age=a;
		}
		void show(){
			cout<<"Name: "<<name<<endl;
			cout<<"Age: "<<age<<endl;
		}
};
int main(){
	Student s("Sana",20);
	s.show();
	getch();
	return 0;
}