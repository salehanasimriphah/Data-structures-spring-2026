#include<iostream>
#include<conio.h>
using namespace std;
void cube(int &y){
	y=y*y*y;
}
int main(){
	int x=10;
	cout<<"X: "<<x<<endl;
	
	cube(x);
	cout<<"After: "<<x<<endl;
	
	getch();
	return 0;
}