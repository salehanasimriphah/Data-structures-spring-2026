#include<iostream>
#include<conio.h>
using namespace std;
class Construct{
	float area;
	
	public:
		Construct(){
			area=0;
		}
		Construct(int a,int b){
			area=a*b;
		}
		void show(){
			cout<<"Area: "<<area<<endl;
		}
};
int main(){
	Construct c1;
	Construct c2(3,4);
	c1.show();
	c2.show();
	getch();
	return 0;
}