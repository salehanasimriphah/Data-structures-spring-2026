#include<iostream>
#include<conio.h>
using namespace std;

int main(){
	int x=10;
	int y=20;
	
    int *const p=&x;
	*p=20;
	p=&y;
	
	getch();
	return 0;
}