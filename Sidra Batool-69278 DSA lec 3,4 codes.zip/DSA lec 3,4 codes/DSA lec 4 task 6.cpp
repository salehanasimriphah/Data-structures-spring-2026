#include<iostream>
#include<conio.h>
using namespace std;
void add(double a,double b){
	cout<<"Sum: "<<a+b<<endl;
}
void add(int a,int b){
	cout<<"Sum: "<<a+b<<endl;
}
int main(){
	add(2.5,3.5);
	add(3,4);
	
	getch();
	return 0;
}