#include<iostream>
#include<conio.h>
using namespace std;
void cube(int &x){
	x=x*x*x;
}
int main(){
	int y=10;
	cout<<"Y: "<<y<<endl;
	
    cube(y);
	cout<<"Y: "<<y<<endl;
	getch();
	return 0;
}