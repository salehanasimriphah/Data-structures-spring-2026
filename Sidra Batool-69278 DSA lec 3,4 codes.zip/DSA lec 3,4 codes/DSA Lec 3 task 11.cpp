#include<iostream>
#include<conio.h>
using namespace std;

int main(){
	char *menu[]={ "Biryani", "Karahi", "Nihari", "Kabab", "Raita"};
	cout<<"Today Menu:"<<endl;
	for(int i=0;i<5;i++){
		cout<<"-"<<menu[i]<<endl;
	}
	
	getch();
	return 0;
}