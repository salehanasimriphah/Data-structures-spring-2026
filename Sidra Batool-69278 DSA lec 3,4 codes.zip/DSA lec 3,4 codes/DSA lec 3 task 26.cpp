#include<iostream>
#include<conio.h>
using namespace std;
struct Student{
	int rollno;
	char name[20];
};
int main(){
	Student *s=new Student;
	strcpy(s->name,"sidra");
	s->rollno=1;
	
	cout<<"Name: "<<s->name<<" Rollno: "<<s->rollno<<endl;
	delete s;
	
	getch();
	return 0;
}