#include<iostream>
#include<conio.h>
using namespace std;
int &cube(int &y){
	y=y*y*y;
	return y;
}
int main(){
	int x=10;
	int num=5;
	cout<<"X: "<<x<<endl;
	
	cube(x)=num;
	cout<<"After: "<<endl;
	cout<<x<<endl;
	cout<<num<<endl;
	
	getch();
	return 0;
}