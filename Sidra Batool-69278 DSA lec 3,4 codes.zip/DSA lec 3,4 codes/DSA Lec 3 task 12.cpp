#include<iostream>
#include<conio.h>
using namespace std;

int main(){
	char *vehicle[]={ "Car", "Van", "Cycle", "Truck", "Bus"};
	for(int i=0;i<5;i++){
		cout<<vehicle[i]<<endl;
	}
	
	getch();
	return 0;
}