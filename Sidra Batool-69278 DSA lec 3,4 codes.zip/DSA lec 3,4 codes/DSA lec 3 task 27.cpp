#include<iostream>
#include<conio.h>
using namespace std;

int main(){
	int r=5;
	int c=5;
	int *arr=new int[r*c];
	
	for(int i=0;i<r;i++){
		cout<<"enter the elements in row "<<i+1<<endl;
		   for(int j=0;j<c;j++){
		   	  cin>>arr[i*c+j];
		   }
	}
	delete[] arr;
	getch();
	return 0;
}