#include<iostream>
#include<conio.h>
using namespace std;
class Student{
	public:
		string name;
		int age;
		
	public:
		void show(){
			cout<<"Name: "<<name<<endl;
			cout<<"Age: "<<age<<endl;
		}
};
int main(){
	Student s;
	s.name="Sana";
	s.age=20;
	s.show();
	getch();
	return 0;
}