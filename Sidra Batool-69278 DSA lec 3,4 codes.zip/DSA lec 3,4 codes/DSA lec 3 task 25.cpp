#include<iostream>
#include<conio.h>
using namespace std;
class Student{
	public:
		char name[20];
		int rollno;
	
	public:
	 void indata(){
	 	cout<<"Enter name: ";
	    cin>>name;
	    cout<<"Enter rollno: ";
	    cin>>rollno;
	 }	
	
	 void showdata(){
	 	cout<<"Name: "<<name<<" Rollno: "<<rollno<<endl;
	 }
};
int main(){
	Student s1;
	s1.indata();
	
	Student *s=&s1;
	s->showdata();
	
	getch();
	return 0;
}