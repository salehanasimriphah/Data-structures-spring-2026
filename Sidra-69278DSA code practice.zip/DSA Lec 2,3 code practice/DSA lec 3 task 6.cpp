#include<iostream>
using namespace std;
struct Student{
	string name;
	int marks;
};

void update(Student *ptr,int m){
	ptr->marks=m;
}
int main(){
	Student s1={"Saba",75};
	cout<<"Before update"<<endl;
	cout<<"The Student "<<s1.name<<" has "<<s1.marks<<" marks"<<endl;
	
	cout<<endl;
	update(&s1,90);
	cout<<"After update"<<endl;
	cout<<"The Student "<<s1.name<<" has "<<s1.marks<<" marks"<<endl;
	
	return 0;
}