#include<iostream>
using namespace std;

int main(){
	int size;
	cout<<"Enter the size: ";
	cin>>size;
	
	int*arr=new int[size];
	
	cout<<endl;
	cout<<"Enter "<<size<<" elements"<<endl;
	for(int i=0;i<size;i++){
		cin>>arr[i];
	}
	cout<<endl;
	
	cout<<"You enter the elements"<<endl;
	for(int i=0;i<size;i++){
		cout<<arr[i]<<" ";
	}
	delete[] arr;
	
	return 0;
}