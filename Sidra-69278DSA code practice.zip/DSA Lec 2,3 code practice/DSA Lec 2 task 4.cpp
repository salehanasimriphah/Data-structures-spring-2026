#include<iostream>
#include<string>
using namespace std;
class Car{
	private:
		string brand;
		string model;
		int year;
    public:
    	Car(string b, string m, int y){
    		brand=b;
    		model=m;
    		year=y;
		}
		
		void start(){
			cout<<"The "<<model<<" "<<brand<<" is starting"<<endl;
		}
};
int main(){
	Car c("Toyota","Corolla",2020);
	c.start();
	
	return 0;
}