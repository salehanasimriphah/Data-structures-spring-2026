#include<iostream>
using namespace std;

int main(){
	char str[]="Computer";
	char *cp=str;
	
	cout<<"Using variable name: "<<str<<endl;
	cout<<"Using pointer variable: "<<cp<<endl;
	
	return 0;
}