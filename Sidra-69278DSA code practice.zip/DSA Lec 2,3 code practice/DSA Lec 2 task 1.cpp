#include<iostream>
#include<string>
using namespace std;

class Car{
	private:
		string brand;
		string model;
	public:
		Car(string m, string b){
			model=m;
			brand=b;
			cout<<"Car object created "<<endl;
			cout<<"Model: "<<model<<" Brand: "<<brand<<endl;
		}
		
		void drive(){
			cout<<"The "<<brand<<" "<<model<<" is moving"<<endl;
		}
};

int main(){
	Car c("Toyota","Corolla");
	c.drive();
	
	return 0;
}