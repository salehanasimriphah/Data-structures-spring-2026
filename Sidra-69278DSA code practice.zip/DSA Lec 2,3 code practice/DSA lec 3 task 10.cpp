#include<iostream>
using namespace std;

int main(){
	char str[]="Cumputer";
	char *ptr=str;
	
	str[1]='o';
	cout<<"Using variable name: "<<str<<endl;
	cout<<"Using pointer variable: "<<ptr<<endl;
	
	return 0;
}