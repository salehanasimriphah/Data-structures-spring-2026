#include<iostream>
#include<string>
using namespace std;
class Student{
	private:
	string name;
	int rollno;
	double gpa;
	public:
		Student(string n, int r, double g){
			name=n;
			rollno=r;
			gpa=g;
		}
		
		void display(){
			cout<<"Student Information"<<endl;
			cout<<"Name: "<<name<<endl;
			cout<<"Roll No: "<<rollno<<endl;
			cout<<"GPA: "<<gpa<<endl;
		}
};
int main(){
	Student s("Sana",01,3.8);
	s.display();
	
	return 0;
}