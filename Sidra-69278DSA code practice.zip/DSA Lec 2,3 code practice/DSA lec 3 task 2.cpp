#include<iostream>
using namespace std;

int main(){
	int x=5;
	int *ptr=&x;
	
	cout<<"Value stored in pointer ptr: "<<*ptr<<endl;
	cout<<"Address stored in pointer ptr: "<<ptr<<endl;
	
	return 0;
}