#include<iostream>
using namespace std;

int main(){
	int original_arr[3]={1,2,3};
	int (&copy_arr)[3]=original_arr;
	 
	copy_arr[2]=4;
	cout<<"Original List"<<endl;
	for(int i=0;i<3;i++){
		cout<<copy_arr[i]<<" ";
	}
	cout<<endl;
	
	int copy_arr1[3];
	for(int i=0;i<3;i++){
		copy_arr1[i]=original_arr[i];
	}
	cout<<endl;
	
	copy_arr1[0]=99;
	cout<<"Copy List"<<endl;
	for(int i=0;i<3;i++){
		cout<<copy_arr1[i]<<" ";
	}
	cout<<endl;
	
	cout<<"Original List after modification in Copy List"<<endl;
	for(int i=0;i<3;i++){
		cout<<original_arr[i]<<" ";
	}
	cout<<endl;
	return 0;
}