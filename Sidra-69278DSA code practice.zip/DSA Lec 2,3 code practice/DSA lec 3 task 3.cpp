#include<iostream>
using namespace std;
void swap(int *a,int *b){
	int temp=*a;
	*a=*b;
	*b=temp;
}
int main(){
	int x;
	int y;
	cout<<"Enter value of x: ";
	cin>>x;
	cout<<"Enter value of y: ";
	cin>>y;
	
	swap(&x,&y);
	cout<<endl;
	cout<<"After Swapping"<<endl;
	cout<<"Value of x: "<<x<<endl;
	cout<<"Value of y: "<<y<<endl;
	
	return 0;
}