#include<iostream>
#include<queue>
using namespace std;

int main(){
	queue<string> customer;
	
	customer.push("sana");
	customer.push("labiba");
	customer.push("amna");
	customer.push("ayesha");
	cout<<"Front: "<<customer.front()<<endl;
	cout<<"Back: "<<customer.back()<<endl;
	
	if(!customer.empty()){
		cout<<"Front: "<<customer.front()<<endl;
		customer.pop();
	}
	
	if(!customer.empty()){
	  cout<<"Front: "<<customer.front()<<endl;
	  cout<<"Back: "<<customer.back()<<endl;
    }
    else{
    	cout<<"Queue is empty"<<endl;
	}
	
	return 0;
}