#include<iostream>
using namespace std;

int main(){
	
	int arr[3]={1,2,3};
	int *ptr=arr;
	
	cout<<"Value at arr[0]: "<<*ptr<<endl;
	cout<<"Address of arr[0]: "<<ptr<<endl;
	
	ptr++;
	cout<<"Value at arr[1]: "<<*ptr<<endl;
	cout<<"Address of arr[1]: "<<ptr<<endl;
}