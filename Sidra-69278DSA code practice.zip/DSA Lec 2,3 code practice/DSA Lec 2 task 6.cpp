#include<iostream>
#include<string>
using namespace std;
class BankAccount{
	private:
	string accountHolder;
	int accountNumber;
	double balance;
	
	public:
	BankAccount():accountHolder("Unknown"),accountNumber(0),balance(0.0){
	}
	
	BankAccount(string acc_hold, int acc_no, double b){
		accountHolder=acc_hold;
		accountNumber=acc_no;
		balance=b;
	}
	
	BankAccount(const BankAccount& other){
		accountHolder=other.accountHolder;
		accountNumber=other.accountNumber;
		balance=other.balance;
	}
	
	void display(){
		cout<<"Bank Account Information"<<endl;
		cout<<"Name: "<<accountHolder<<endl;
		cout<<"Account Number: "<<accountNumber<<endl;
		cout<<"Balance: "<<balance<<endl;
	}
	
};
int main(){
	BankAccount b1;
	BankAccount b2("Sana",1,1000);
	BankAccount b3=b2;
	b1.display();
	b2.display();
	b3.display();
	
	return 0;
}