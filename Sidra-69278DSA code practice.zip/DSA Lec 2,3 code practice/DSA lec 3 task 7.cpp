#include<iostream>
using namespace std;
struct Exam{
	string name;
	string status;
	
	void update(Exam *ptr,string s){
		ptr->status=s;
	}
};
int main(){
	Exam e[3]={ {"Alice","Pass"},{"Jack","Fail"},{"June","Pass"} };
	
	cout<<"Before update"<<endl;
	for(int i=0;i<3;i++){
		cout<<"The Student "<<e[i].name<<" has "<<e[i].status<<endl;
	}
	
	e[0].update(&e[0],"Fail");
	cout<<endl;
	cout<<"After update"<<endl;
	for(int i=0;i<3;i++){
		cout<<"The Student "<<e[i].name<<" has "<<e[i].status<<endl;
	}
	
	return 0;
}