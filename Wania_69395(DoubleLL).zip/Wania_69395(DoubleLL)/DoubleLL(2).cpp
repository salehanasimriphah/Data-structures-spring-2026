#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

void insertAtStart(Node*& head, int data) {
    Node* newNode = new Node();
    newNode->data = data;
    newNode->prev = nullptr;
    newNode->next = head;

   
    if (head != nullptr)
        head->prev = newNode;

    head = newNode;
}




void deleteFromStart(Node* &head) {
        if (head == NULL) {
            cout << "List is empty. No node to delete." << endl;
            return;
        }
        Node* temp = head;
        head = head->next;
        if (head != NULL) {
            head->prev = NULL;
        }
        delete temp;
    }
 
void deleteFromEnd(Node*head) 
{
 if (head == NULL)
 {
cout << "List is empty. No node to delete." << endl;
return;
 }
 if (head->next == NULL) 
{
            delete head;
            head = NULL;
}
 Node* temp = head;
while (temp->next != NULL) 
{
 temp = temp->next;
}
temp->prev->next = NULL;
 delete temp;
 }
void printList(Node* head) {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    Node* head = nullptr;

    
    insertAtStart(head, 10); 
    insertAtStart(head, 20); 
    insertAtStart(head, 30); 
    
    printList(head);
    
    
    deleteFromEnd(head);
    
    printList(head);
    
    deleteFromStart(head);
    
    printList(head);
    
    return 0;
    
}
