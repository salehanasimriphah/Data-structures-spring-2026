#include <iostream>
using namespace std;

struct node
{
    int data;
    node* next;

    node(int val)
    {
        data = val;
        next = NULL;
    }
};

void insertAtTail(node*& head, int val)
{
    node* ptr = new node(val);

    if (head == NULL)
    {
        head = ptr;
        return;
    }

    node* temp = head;
    while (temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = ptr;
}

void deleteAtPosition(node*& head, int pos)
{
    if (head == NULL)
        return;

    if (pos == 1)
    {
        node* ptr = head;
        head = head->next;
        delete ptr;
        return;
    }

    node* temp = head;

    for (int i = 1; i < pos - 1 && temp->next != NULL; i++)
    {
        temp = temp->next;
    }

    if (temp->next == NULL)
    {
        cout << "Position out of range!" << endl;
        return;
    }

    node* ptr = temp->next;
    temp->next = ptr->next;
    delete ptr;
}

void display(node* head)
{
    node* temp = head;
    while (temp != NULL)
    {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

int main()
{
    node* head = NULL;

    insertAtTail(head, 10);
    insertAtTail(head, 20);
    insertAtTail(head, 30);
    insertAtTail(head, 40);

    cout << "Before deletion: ";
    display(head);

    deleteAtPosition(head, 3);   // Delete node at position 3

    cout << "After deletion: ";
    display(head);

    return 0;
}