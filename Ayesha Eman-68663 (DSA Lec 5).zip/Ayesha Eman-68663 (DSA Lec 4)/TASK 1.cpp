#include<iostream>
using namespace std;

struct node{
    int data;
    node* next;
};

void insertAtHead(node*&head,int val)
{
    node* ptr=new node;
    ptr->data=val;
    ptr->next=head;
    head=ptr;
}

void display(node* head)
{
    node* temp=head;
    while(temp!=NULL)
	{
        cout<<temp->data<<"->";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}

int main()
{
   node* head=NULL;
   insertAtHead(head,10);
   insertAtHead(head,20);
   insertAtHead(head,30);
   display(head);
   return 0;
}