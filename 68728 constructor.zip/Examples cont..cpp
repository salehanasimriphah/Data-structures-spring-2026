//Pointer to array (array name is a pointer itself)

#include <iostream>
using namespace std;
int main() 
{
    int arr[5] = {10, 20, 30, 40, 50};
    int* ptr = arr;  // array name 'arr' is a pointer to arr[0]
    cout << "Accessing array elements using pointer:\n";
    for (int i = 0; i < 5; i++)
    {
        cout << "Element " << i << " = " << *(ptr + i) << endl;
    }    
return 0;
}


