//Rihab Sajid
//69585
#include<iostream>
using namespace std;
class construct
{
	public:
	float area;
	construct()
	{
		area=0;
	}
	construct(int a,int b)
	{
		area=a*b;
	}
	display()
	{
		cout<<area<<endl;
	}
};
int main()
{
	construct c;
	construct c1(3,4);
	c.display();
	c1.display();
	return 0;
}
