//Rihab Sajid
//69585
#include<iostream>
using namespace std;
void add(int a,int b)
{
	int sum;
	sum=a+b;
	cout<<"Sum is "<<sum<<endl;
}
void add(float a,float b,float c)
{
	float sum;
	sum=a+b+c;
	cout<<"Sum is "<<sum<<endl;
}
int main()
{
	add(3,4);
	add(7.5,3.5,2.34);
	return 0;
}
