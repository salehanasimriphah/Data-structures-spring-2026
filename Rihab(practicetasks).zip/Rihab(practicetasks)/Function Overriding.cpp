//Rihab Sajid
//69585
#include<iostream>
using namespace std;
class parent
{
	public:
void show()
	{
		cout<<"Base Function"<<endl;
	}
};
class child:public parent
{
    public:
void show()
	{
		cout<<"Derived Function"<<endl;
	}
};
int main()
{
	child c;
	c.show();
	c.parent::show();
	return 0;
}
