#include <iostream>
using namespace std;

int main() {
    int r = 5, c = 5;
    int* arr = new int[r * c];

    for(int i = 0; i < r; i++) {
        cout << "Enter elements in row " << i + 1 << ":\n";
        for(int j = 0; j < c; j++) {
            cin >> arr[i * c + j];
        }
    }

    delete[] arr;
    return 0;
}

