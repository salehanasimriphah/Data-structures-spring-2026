#include <iostream>
using namespace std;

int main() {
    char str[] = "computer";
    char *cp = str;

    cout << str << endl;
    cout << cp << endl;

    return 0;
}

