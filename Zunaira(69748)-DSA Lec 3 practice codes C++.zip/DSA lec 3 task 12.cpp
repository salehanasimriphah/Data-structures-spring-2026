#include <iostream>
using namespace std;

int* min(int &x, int &y) {
    if(x < y)
        return &x;
    else
        return &y;
}

int main() {
    int a, b, *c;
    cout << "Enter a: ";
    cin >> a;
    cout << "Enter b: ";
    cin >> b;

    c = min(a, b);
    cout << "The minimum number is: " << *c;

    return 0;
}

