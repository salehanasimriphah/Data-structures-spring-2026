#include <iostream>
#include <cstring>
using namespace std;

struct student {
    int rollno;
    char name[20];
};

int main() {
    student *stu;
    stu = new student;

    stu->rollno = 1;
    strcpy(stu->name, "Aira");

    cout << stu->rollno << " " << stu->name;

    delete stu;
}

