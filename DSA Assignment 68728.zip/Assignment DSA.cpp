#include <iostream>
using namespace std;

int arr[100];
int size = 0;
int heapType = 0; 

void heapifyUp(int i) {
    int parent = (i - 1) / 2;
    if (i > 0) {
        if (heapType == 1 && arr[i] > arr[parent]) {
            swap(arr[i], arr[parent]);
            heapifyUp(parent);
        } 
		else if (heapType == 2 && arr[i] < arr[parent]) {
            swap(arr[i], arr[parent]);
            heapifyUp(parent);
        }
    }
}

void heapifyDown(int i) {
    int left = 2 * i + 1;
    int right = 2 * i + 2;
    int target = i;

    if (heapType == 1) {
        if (left < size && arr[left] > arr[target]) target = left;
        if (right < size && arr[right] > arr[target]) target = right;
    } 
	else {
        if (left < size && arr[left] < arr[target]) target = left;
        if (right < size && arr[right] < arr[target]) target = right;
    }

    if (target != i) {
        swap(arr[i], arr[target]);
        heapifyDown(target);
    }
}

void insert(int val) {
    arr[size] = val;
    size++;
    heapifyUp(size - 1);
}

void deleteRoot() {
    if (size == 0) {
        cout << "Heap is empty!" << endl;
        return;
    }
    cout << "Deleted root: " << arr[0] << endl;
    arr[0] = arr[size - 1];
    size--;
    heapifyDown(0);
}

void displayHeap() {
    string heapName = (heapType == 1) ? "Max" : "Min";
    cout << "Array of " << heapName << " heap: ";
    for (int i = 0; i < size; i++) {
        cout << arr[i];
        if (i < size - 1) cout << ", ";
    }
    cout << endl;
}

int main() {
    int n;
    cout << "Enter size of Array: ";
    cin >> n;

    cout << "Enter elements: ";
    for (int i = 0; i < n; i++) {
        int val;
        cin >> val;
        arr[size] = val;
        size++;
    }

    cout << "\nWhich heap do you want:" << endl;
    cout << "1. Max Heap" << endl;
    cout << "2. Min Heap" << endl;
    cout << "3. Exit" << endl;
    cout << "Choice: ";
    cin >> heapType;

    if (heapType == 3) return 0;

    for (int i = size / 2 - 1; i >= 0; i--) {
        heapifyDown(i);
    }

    int choice;
    do {
        cout << "\nWhat do you want to do:" << endl;
        cout << "1. Insert" << endl;
        cout << "2. Delete" << endl;
        cout << "3. Exit" << endl;
        cout << "Choice: ";
        cin >> choice;

        if (choice == 1) {
            int val;
            cout << "Enter element to insert: ";
            cin >> val;
            insert(val);
            displayHeap();
        } else if (choice == 2) {
            deleteRoot();
            displayHeap();
        }

    } while (choice != 3);

    return 0;
}
