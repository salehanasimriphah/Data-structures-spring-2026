#include<iostream>
using namespace std;
struct Node
{
    int data;
    Node*next;
};

Node*head=NULL;
void insertatposition(int val,int pos)
{
    Node*temp=new Node();
    temp->data=val;
    if(pos==1)
	{
        if(head==NULL)
		{
            head=temp;
            temp->next=head;
            return;
        }
        Node*ptr=head;
        while(ptr->next!=head)
		{
            ptr=ptr->next;
        }
        temp->next=head;
        ptr->next=temp;
        head=temp;
        return;
    }
    Node*ptr=head;
    for(int i=1;i<pos-1;i++)
	{
        ptr=ptr->next;
        if(ptr==head)
		{
            cout<<"Invalid position"<<endl;
            return;
        }
    }
    temp->next=ptr->next;
    ptr->next=temp;
}

void display()
{
    if(head==NULL)
	{
        cout<<"List is empty"<<endl;
        return;
    }
    Node*ptr=head;
    do
	{
        cout<<ptr->data<<" ";
        ptr=ptr->next;
    }while(ptr!=head);

    cout<<" ";
}
int main()
{
    int n,x,pos;
    cout<<"Enter number of nodes: ";
    cin>>n;
    for(int i=0;i<n;i++)
	{
        cout<<"Enter value:";
        cin>>x;
        insertatposition(x,i+1);
    }

    cout<<"Enter value to insert: ";
    cin>>x;
    cout<<"Enter position: ";
    cin>>pos;

    insertatposition(x,pos);

    cout<<"Circular list: ";
    display();

    return 0;
}