#include<iostream>
using namespace std;
struct Node
{
    int data;
    Node*next;
};

Node*head=NULL;

void deleteFront()
{
    if(head==NULL){
        cout<<"List is empty"<<endl;
        return;
    }

    if(head->next==head)
	{
        delete head;
        head=NULL;
        return;
    }

    Node*ptr=head;
    while(ptr->next!=head)
	{
        ptr=ptr->next;
    }
    Node*temp=head;
    head=head->next;
    ptr->next=head;
    delete temp;
}

void insertLast(int val)
{
    Node*temp=new Node();
    temp->data=val;
    if(head==NULL)
	{
        head=temp;
        temp->next=head;
        return;
    }
    Node*ptr=head;
    while(ptr->next!=head)
	{
        ptr=ptr->next;
    }

    ptr->next=temp;
    temp->next=head;
}

void display()
{
    if(head==NULL)
	{
        cout<<"List is empty"<<endl;
        return;
    }

    Node*ptr=head;
    do{
        cout<<ptr->data<<" ";
        ptr=ptr->next;
    }while(ptr!=head);

    cout<<" ";
}

int main()
{
    insertLast(10);
    insertLast(20);
    insertLast(30);

    cout<<"Before Deletion: ";
    display();

    deleteFront();

    cout<<"After Deletion:";
    display();

    return 0;
}