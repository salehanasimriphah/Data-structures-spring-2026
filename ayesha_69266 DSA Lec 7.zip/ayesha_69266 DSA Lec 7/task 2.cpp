#include<iostream>
using namespace std;
struct Node
{
    int data;
    Node*next;
};

Node*head=NULL;
void insertLast(int val)
{
    Node*temp=new Node();
    temp->data=val;
    if(head==NULL)
	{
        head=temp;
        temp->next=head;
        return;
    }
    Node*ptr=head;
    while(ptr->next!=head)
	{
        ptr=ptr->next;
    }
    ptr->next=temp;
    temp->next=head;
}

void display()
{
    if(head==NULL)
	{
        cout<<"List is empty"<<endl;
        return;
    }
    Node*ptr=head;
    do
	{
        cout<<ptr->data<<" ";
        ptr=ptr->next;
    }while(ptr!=head);

    cout<<"  ";
}

int main()
{
    int n,x;
    cout<<"Enter number of nodes: ";
    cin>>n;

    for(int i=0;i<n;i++)
	{
        cout<<"Enter value: ";
        cin>>x;
        insertLast(x);
    }

    cout<<"Circular list: ";
    display();

    return 0;
}
