#include <iostream>
using namespace std;

// Node structure
struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

// Insert function
Node* insert(Node* root, int key) {
    if (root == NULL)
        return new Node(key);

    if (key < root->data)
        root->left = insert(root->left, key);
    else if (key > root->data)
        root->right = insert(root->right, key);

    return root;
}

// In-order Traversal
void inorder(Node* root) {
    if (root == NULL) return;

    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

// Search function
Node* search(Node* root, int key) {
    if (root == NULL || root->data == key)
        return root;

    if (key > root->data)
        return search(root->right, key);

    return search(root->left, key);
}

// Find minimum (in-order successor)
Node* findMin(Node* root) {
    while (root->left != NULL)
        root = root->left;
    return root;
}

// Delete function
Node* deleteNode(Node* root, int key) {
    if (root == NULL) return root;

    if (key < root->data)
        root->left = deleteNode(root->left, key);

    else if (key > root->data)
        root->right = deleteNode(root->right, key);

    else {
        // Case 1: No child
        if (root->left == NULL && root->right == NULL)
            return NULL;

        // Case 2: One child
        else if (root->left == NULL)
            return root->right;

        else if (root->right == NULL)
            return root->left;

        // Case 3: Two children
        Node* temp = findMin(root->right);
        root->data = temp->data;
        root->right = deleteNode(root->right, temp->data);
    }

    return root;
}

// Main function
int main() {
    Node* root = NULL;

    // Insert given values
    int arr[] = {100, 50, 150, 20, 75, 125, 175, 60, 160};

    for (int i = 0; i < 9; i++) {
        root = insert(root, arr[i]);
    }

    // Inorder Traversal
    cout << "In-order Traversal: ";
    inorder(root);

    // Search 160
    int key = 160;
    Node* result = search(root, key);

    if (result != NULL)
        cout << "\n160 Found in BST";
    else
        cout << "\n160 Not Found";

    // Delete 50
    root = deleteNode(root, 50);

    cout << "\nIn-order after deleting 50: ";
    inorder(root);

    return 0;
}