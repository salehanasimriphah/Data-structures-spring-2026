#include <iostream>
using namespace std;

// Node Structure
struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

// Insert Function
Node* insert(Node* root, int key) {
    if (root == NULL) {
        return new Node(key);
    }

    if (key < root->data) {
        root->left = insert(root->left, key);
    } else if (key > root->data) {
        root->right = insert(root->right, key);
    }

    return root;
}

// Search Function (Recursive)
Node* search(Node* root, int key) {
    // Base Case
    if (root == NULL || root->data == key) {
        return root;
    }

    // If key is greater, go right
    if (key > root->data) {
        return search(root->right, key);
    }

    // If key is smaller, go left
    return search(root->left, key);
}

// Inorder Traversal (for checking tree)
void inorder(Node* root) {
    if (root == NULL) return;

    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

// Main Function
int main() {
    Node* root = NULL;

    // Insert elements
    root = insert(root, 50);
    insert(root, 30);
    insert(root, 70);
    insert(root, 20);
    insert(root, 40);
    insert(root, 60);
    insert(root, 80);

    cout << "Inorder Traversal: ";
    inorder(root);

    int key;
    cout << "\nEnter value to search: ";
    cin >> key;

    Node* result = search(root, key);

    if (result != NULL) {
        cout << "Value found in BST!";
    } else {
        cout << "Value NOT found in BST!";
    }

    return 0;
}