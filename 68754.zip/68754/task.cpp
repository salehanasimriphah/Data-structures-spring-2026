#include<iostream>
using namespace std;

struct Node{
	int data;
	Node* next;
};

void deleteAtposition(Node*& head,int position){
	if(head ==NULL){
		cout<<"Nothing to delete";
		return;
	}
	if(position==1){
		Node* temp =head;
		head=head->next;
		cout<<"deleted "<<temp->data<<endl;
		delete temp;
		return;
	}
	Node* temp =head;
	for(int i=1;temp!=NULL && i<position -1;i++){
		temp= temp->next;
	}

	if (temp ==NULL ||temp->next==NULL){
		cout<<"invalid position!"<<endl;
		return;
	}
	Node*del=temp->next;
	temp->next=del->next;
	cout<<"deleted "<<del->data<<endl;
	delete del;	
}

void display(Node* head){
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}
int main() {
  
    Node* head = new Node{10, NULL};
    head->next = new Node{40, NULL};
    head->next->next = new Node{50, NULL};

   display(head);
    deleteAtposition(head, 2);

    return 0;
}