#include <iostream>
#include <string>
using namespace std;

// Node structure for the binary tree
struct Node {
    string value;   // operator or operand
    Node* left;
    Node* right;

    Node(string val) {
        value = val;
        left = right = nullptr;
    }
};

// Inorder traversal ? Infix expression
void inorder(Node* root) {
    if (root == nullptr) return;

    // Add parentheses for clarity in infix
    if (root->left || root->right) cout << "(";
    inorder(root->left);
    cout << root->value;
    inorder(root->right);
    if (root->left || root->right) cout << ")";
}

// Preorder traversal ? Prefix expression
void preorder(Node* root) {
    if (root == nullptr) return;
    cout << root->value << " ";
    preorder(root->left);
    preorder(root->right);
}

// Postorder traversal ? Postfix expression
void postorder(Node* root) {
    if (root == nullptr) return;
    postorder(root->left);
    postorder(root->right);
    cout << root->value << " ";
}

int main() {
    /*
       Example Expression: (a + b) * (c - d)
       
                 *
               /   \
             +       -
            / \     / \
           a   b   c   d
    */

    Node* root = new Node("*");
    root->left = new Node("+");
    root->right = new Node("-");

    root->left->left = new Node("a");
    root->left->right = new Node("b");

    root->right->left = new Node("c");
    root->right->right = new Node("d");

    cout << "Infix Expression: ";
    inorder(root);
    cout << endl;

    cout << "Prefix Expression: ";
    preorder(root);
    cout << endl;

    cout << "Postfix Expression: ";
    postorder(root);
    cout << endl;

    return 0;
}