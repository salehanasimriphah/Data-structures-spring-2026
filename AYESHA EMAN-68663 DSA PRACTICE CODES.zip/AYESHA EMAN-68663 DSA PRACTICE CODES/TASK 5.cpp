#include <iostream>
#include <string>
class BankAccount {
private:
    std::string name;
    int accountNumber;
    double balance;
public:
    // Default constructor
    BankAccount() : name("Unknown"), accountNumber(0), balance(0.0) {}
    // Parameterized constructor
    BankAccount(std::string n, int accNum, double bal)
        : name(n), accountNumber(accNum), balance(bal) {}
    // Copy constructor
    BankAccount(const BankAccount& other)
        : name(other.name), accountNumber(other.accountNumber), balance(other.balance) {}
    // Display method
    void display()  {
        std::cout << "Name: " << name
                  << ", Account Number: " << accountNumber
                  << ", Balance: " << balance << std::endl;
    }
};

int main() {
    BankAccount a1; // Tests Default Constructor
    BankAccount a2("Alice", 1001, 500.0); // Tests Parameterized Constructor
    BankAccount a3 = a2; // Tests Copy Constructor
    a1.display();
    a2.display();
    a3.display();
    return 0;
}



