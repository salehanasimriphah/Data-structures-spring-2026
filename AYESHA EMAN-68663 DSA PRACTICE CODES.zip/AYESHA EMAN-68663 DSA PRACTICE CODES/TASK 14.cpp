#include <iostream>
using namespace std;

int main() { // Use int main() as it is the standard
    char str[] = "cumputer"; 
    char *cp = str;

    // Task: Change 'u' at index [1] to 'o'
    str[1] = 'o'; 

    cout << "Using variable name: " << str << endl;
    cout << "Using pointer variable: " << cp << endl;

    return 0;
}

