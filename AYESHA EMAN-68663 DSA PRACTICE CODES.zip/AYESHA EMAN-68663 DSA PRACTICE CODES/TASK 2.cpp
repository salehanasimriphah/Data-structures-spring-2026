#include <iostream>
#include <stack>
#include <string>
int main() {
    // Create a stack of strings
    std::stack<std::string> browser_history;
    // Use push() to add items (pages visited) to the stack
    browser_history.push("google.com");
    browser_history.push("openai.com");
    browser_history.push("github.com");
    std::cout << "Current page: " << browser_history.top() << std::endl; // The last one pushed
    // Use pop() to go back (remove the top item)
    browser_history.pop();
    std::cout << "Going back to: " << browser_history.top() << std::endl; // The new top item
    // Check if the stack is empty
    if (!browser_history.empty()) {
        std::cout << "Stack is not empty." << std::endl;
    }
    return 0;
}

