#include <iostream>
int main() {
    int original_list[3] = {1, 2, 3};
    // copied_list is just a reference (alias) to original_list
    int (&copied_list)[3] = original_list;
    // Modify through the reference
    copied_list[2] = 4;  // change the last element

    // Print original_list
    std::cout << "original_list: ";
    for (int i = 0; i < 3; i++) {
        std::cout << original_list[i] << " ";
    }  
    std::cout << std::endl;
    // Now demonstrate an actual copy
    int copied_array[3];
    for (int i = 0; i < 3; i++) {
        copied_array[i] = original_list[i];  // manual copy
    }
 copied_array[0] = 99; // change copy only
    std::cout << "copied_array: ";
    for (int i = 0; i < 3; i++) {
        std::cout << copied_array[i] << " ";
    }
    std::cout << std::endl;
    std::cout << "original_list after modifying copy: ";
    for (int i = 0; i < 3; i++) {
        std::cout<< original_list[i] << " "; } std::cout << std::endl; 
return 0;
}

