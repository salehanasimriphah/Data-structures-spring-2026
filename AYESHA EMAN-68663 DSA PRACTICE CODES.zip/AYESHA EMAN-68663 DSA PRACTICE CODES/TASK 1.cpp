#include <iostream>
#include <string>
class Car {
private:
    // Attributes (Data members)
    // We keep these private to enforce "Encapsulation"
    std::string brand;
    std::string model;
public:
    // 1. Implementation of the Constructor
    // This runs automatically when we create a new Car object
    Car(std::string b, std::string m) {
        brand = b;
        model = m;
        std::cout << "Car object created: " << brand << " " << model << std::endl;
    }
    // 2. Class Method (Behavior)
    void drive() {
        std::cout << "The " << brand << " " << model << " is moving." << std::endl;
    }
};
int main() {
    // 3. Use of the Constructor (Instantiating the class)
    Car myCar("Toyota", "Corolla");
    // Calling the method
    myCar.drive();
    return 0;
}

