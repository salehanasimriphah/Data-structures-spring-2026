#include <iostream>
using namespace std;
// Define a structure
struct Student {
    string name;
    int marks;
};
// Function to update marks using pointer to struct
void updateMarks(Student* s, int newMarks) 
{    
s->marks = newMarks;  // same as (*s).marks = newMarks;
}
          int main() 
	{    Student s1 = {"Saleha", 75};    
	cout << "Before update: " << s1.name << " has " << s1.marks << " marks." << endl;    
// Pass address of s1 to the function
    updateMarks(&s1, 90);
    cout << "After update: " << s1.name << " has " << s1.marks << " marks." << endl;
    return 0;
}

