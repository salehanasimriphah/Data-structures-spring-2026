#include <iostream>
using namespace std;
// 1. Define the structure
struct Exam {
    string name;
    string status;
};
// 2. Function to update status using a pointer to the struct
void updateStatus(Exam* e, string newStatus) {
    e->status = newStatus;  // Accessing the member via pointer
}
int main() {
    // 3. Create 3 objects (an array is the easiest way to hold them)
    Exam students[3] = {
        {"Alice", "Pass"},
        {"Jack", "Fail"},
        {"June", "Pass"}
    };
    cout << "Before Update: " << students[0].name << " is " << students[0].status << endl;
    // 4. Use a pointer to point to the first student (Alice)
    // We pass the address of the first element of the array
    updateStatus(&students[0], "Fail");
    cout << "After Update:  " << students[0].name << " is " << students[0].status << endl;

    return 0;
}

