#include <iostream>
using namespace std;
int main() 
          {    
          int a = 10;    
          int *p;       // declaring pointer    
          p = &a;       // storing address of 'a' in pointer p    
         cout << "Value of a: " << a << endl;    
         cout << "Address of a: " << &a << endl;    
        cout << "Value stored in pointer p: " << p << endl;    
        cout << "Value at address p points to: " << *p << endl;    
        return 0;
       }

