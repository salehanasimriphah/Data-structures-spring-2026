
#include<iostream>
using namespace std;
void cube(int x)
{ 
x= x*x*x; 
}
int main()
{int y=10; 
 cout<<y;
cube(y); 
cout<<y;
return 0;
}
