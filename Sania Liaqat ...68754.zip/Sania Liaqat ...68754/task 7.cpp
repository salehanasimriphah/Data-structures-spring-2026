#include<iostream>
using namespace std;
class student
{ int rollno; 
 char name[20];
void indata()
	{cin>> s1.rollno;gets(s1.name); } 
	 void showdata() {cout<<stu.rollno<<stu.name;} }; 
	  void main()
{ student s1 , *stu; 
 s1.indata();
stu=&s1; 
s1.outdata(); stu->outdata();}
