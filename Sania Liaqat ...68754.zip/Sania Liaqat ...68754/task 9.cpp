#include<iostream>
using namespace std;

class student
{
    int rollno;
    char name[20];

public:
    void indata()
    {
        cout<<"Enter roll number: ";
        cin>>rollno;

        cout<<"Enter name: ";
        cin>>name;
    }

    void showdata()
    {
        cout<<"Roll No: "<<rollno<<endl;
        cout<<"Name: "<<name<<endl;
    }
};

int main()
{
    student s1, *stu;

    s1.indata();

    stu = &s1;

    cout<<"\nUsing object:\n";
    s1.showdata();

    cout<<"\nUsing pointer:\n";
    stu->showdata();

    return 0;
}
