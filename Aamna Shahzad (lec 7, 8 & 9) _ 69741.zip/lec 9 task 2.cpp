#include<iostream>
using namespace std;

struct Node{
int data;
Node* next;
};

class Stack{
Node* top;
public:
Stack(){top=NULL;}

void push(int x){
Node* newNode=new Node();
newNode->data=x;
newNode->next=top;
top=newNode;
}

void pop(){
if(top==NULL){
cout<<"Stack is empty"<<endl;
return;
}
Node* temp=top;
cout<<"Deleted: "<<top->data<<endl;
top=top->next;
delete temp;
}

void Top(){
if(top==NULL){
cout<<"Stack is empty"<<endl;
return;
}
cout<<"Top element: "<<top->data<<endl;
}
};

int main(){
Stack s;

s.push(10);
s.push(20);
s.push(30);

s.Top();

s.pop();

s.Top();

return 0;
}
