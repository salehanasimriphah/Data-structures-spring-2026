#include<iostream>
using namespace std;

class Stack{
private:
    int *stackArray;
    int stackSize;
    int top;

public:
    Stack(int size){
        stackSize=size;
        stackArray=new int[size];
        top=-1;
    }

    bool isEmpty(){
        if(top==-1)
            return true;
        else
            return false;
    }

    bool isFull(){
        if(top==stackSize-1)
            return true;
        else
            return false;
    }

    void push(int value){
        if(isFull()){
            cout<<"Stack is full"<<endl;
            return;
        }
        top=top+1;
        stackArray[top]=value;
    }

    int pop(){
        if(isEmpty()){
            cout<<"Stack is empty"<<endl;
            return -1;
        }
        return stackArray[top--];
    }

    int Top(){
        if(isEmpty()){
            cout<<"Stack is empty"<<endl;
            return -1;
        }
        return stackArray[top];
    }

    void displayStack(){
        if(isEmpty()){
            cout<<"Stack is empty"<<endl;
            return;
        }
        for(int i=top;i>=0;i--){
            cout<<stackArray[i]<<" ";
        }
        cout<<endl;
    }
};

int main(){
    Stack stack(5);
    int choice;

    do{
        cout<<"Menu"<<endl;
        cout<<"1-- PUSH"<<endl;
        cout<<"2-- POP"<<endl;
        cout<<"3-- DISPLAY"<<endl;
        cout<<"4-- Exit"<<endl;
        cout<<"Enter choice=";
        cin>>choice;

        switch(choice){
        case 1:
            int n;
            cin>>n;
            stack.push(n);
            break;

        case 2:
            cout<<"Deleted: "<<stack.pop()<<endl;
            break;

        case 3:
            stack.displayStack();
            break;
        }

    }while(choice!=4);

    return 0;
}
