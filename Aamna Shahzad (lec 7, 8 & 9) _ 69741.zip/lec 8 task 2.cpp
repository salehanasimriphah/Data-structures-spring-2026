#include<iostream>
#include<stack>
#include<fstream>
#include<cmath>
using namespace std;

int evaluatePostfix(string postfix)
{
    stack<int> s;
    int x,y,temp;

    for(int i=0;i<postfix.size();i++)
    {
        if(postfix[i]>='0' && postfix[i]<='9')
        {
            s.push(postfix[i]-'0');
        }
        else
        {
            x=s.top(); s.pop();
            y=s.top(); s.pop();

            switch(postfix[i])
            {
                case '+': temp=y+x; break;
                case '-': temp=y-x; break;
                case '*': temp=y*x; break;
                case '/': temp=y/x; break;
                case '%': temp=y%x; break;
                case '^': temp=pow(y,x); break;
            }
            s.push(temp);
        }
    }
    return s.top();
}

int main()
{
    ifstream file("MyFile.txt");
    string expression;

    while(getline(file,expression))
    {
        int result=evaluatePostfix(expression);
        cout<<"Result: "<<result<<endl;
    }

    return 0;
}
