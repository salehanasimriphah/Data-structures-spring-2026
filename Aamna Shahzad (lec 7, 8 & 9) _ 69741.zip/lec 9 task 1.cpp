#include<iostream>
using namespace std;
#define MAX 5

class Stack{
int arr[MAX],top;
public:
Stack(){top=-1;}

void push(int x){
if(top==MAX-1){
cout<<"Stack is full"<<endl;
return;
}
top++;
arr[top]=x;
}

void pop(){
if(top==-1){
cout<<"Stack is empty"<<endl;
return;
}
cout<<"Deleted: "<<arr[top]<<endl;
top--;
}

void Top(){
if(top==-1){
cout<<"Stack is empty"<<endl;
return;
}
cout<<"Top element: "<<arr[top]<<endl;
}
};

int main(){
Stack s;

s.push(10);
s.push(20);
s.push(30);

s.Top();

s.pop();

s.Top();

return 0;
}
