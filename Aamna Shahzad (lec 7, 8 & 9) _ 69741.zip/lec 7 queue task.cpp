#include<iostream>
using namespace std;
#define MAX 5

class Queue{
int arr[MAX],front,rear;
public:
Queue(){front=0;rear=-1;}

void enqueue(int x){
if(rear==MAX-1){cout<<"Queue is full"<<endl;return;}
rear=rear+1;
arr[rear]=x;
}

void dequeue(){
if(front>rear){cout<<"Queue is empty"<<endl;return;}
cout<<"Deleted: "<<arr[front]<<endl;
front=front+1;
}

void display(){
if(front>rear){cout<<"Queue is empty"<<endl;return;}
for(int i=front;i<=rear;i++)cout<<arr[i]<<" ";
cout<<endl;
}
};

int main(){
Queue q;
q.enqueue(10);
q.enqueue(20);
q.enqueue(30);
q.display();

q.dequeue();
q.display();

return 0;
}
