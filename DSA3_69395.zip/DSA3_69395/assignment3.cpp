#include <iostream>
using namespace std;

struct Tree {
    char data;
    Tree* left;
    Tree* right;
};

Tree* createNode(char val) {
    Tree* newNode = new Tree;
    newNode->data = val;
    newNode->left = nullptr;
    newNode->right = nullptr;
    return newNode;
}

void PreorderTraversal(Tree* root) {
    if (root == nullptr) return;

    cout << root->data;
    PreorderTraversal(root->left);
    PreorderTraversal(root->right);
}

void InorderTraversal(Tree* root) {
    if (root == nullptr) return;

    InorderTraversal(root->left);
    cout << root->data;
    InorderTraversal(root->right);
}

void PostorderTraversal(Tree* root) {
    if (root == nullptr) return;

    PostorderTraversal(root->left);
    PostorderTraversal(root->right);
    cout << root->data;
}

int main() {

    // Expression tree for (a + b) * (c - d)

    Tree* root = createNode('*');

    root->left = createNode('+');
    root->right = createNode('-');

    root->left->left = createNode('a');
    root->left->right = createNode('b');

    root->right->left = createNode('c');
    root->right->right = createNode('d');


    cout << "In-order (Infix): ";
    InorderTraversal(root);
    cout << endl;

    cout << "Pre-order (Prefix): ";
    PreorderTraversal(root);
    cout << endl;

    cout << "Post-order (Postfix): ";
    PostorderTraversal(root);
    cout << endl;

    return 0;
}