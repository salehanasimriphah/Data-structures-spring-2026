#include <iostream>
using namespace std;

#define MAX_SIZE 50

class SimpleStack {
private:
    int data[MAX_SIZE];
    int topIndex;

public:
    SimpleStack() {
        topIndex = -1;
    }

    bool isFull() {
        return topIndex == MAX_SIZE - 1;
    }

    bool isEmpty() {
        return topIndex == -1;
    }

    void push(int val) {
        if (isFull()) {
            cout << "Error: Stack is full!" << endl;
            return;
        }
        data[++topIndex] = val;
        cout << "Pushed: " << val << endl;
    }

    void pop() {
        if (isEmpty()) {
            cout << "Error: Stack is empty!" << endl;
            return;
        }
        cout << "Popped: " << data[topIndex--] << endl;
    }

    void showTop() {
        if (isEmpty()) {
            cout << "Stack is empty" << endl;
        } else {
            cout << "Current Top: " << data[topIndex] << endl;
        }
    }
};

int main() {
    SimpleStack s;
    s.push(100);
    s.push(200);
    s.showTop();
    s.pop();
    s.showTop();
    return 0;
}
