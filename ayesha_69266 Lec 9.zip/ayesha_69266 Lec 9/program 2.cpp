#include <iostream>
using namespace std;

struct Node {
    char info;
    Node* nextNode;
};

class CharStack {
private:
    Node* top;

public:
    CharStack() {
        top = NULL;
    }

    void push(char c) {
        Node* newNode = new Node();
        newNode->info = c;
        newNode->nextNode = top;
        top = newNode;
        cout << "Inserted: " << c << endl;
    }

    void pop() {
        if (top == NULL) {
            cout << "Stack Underflow" << endl;
            return;
        }
        Node* temp = top;
        cout << "Removed: " << top->info << endl;
        top = top->nextNode;
        delete temp;
    }

    void printStack() {
        Node* curr = top;
        cout << "Current Stack: ";
        while (curr != NULL) {
            cout << curr->info << " -> ";
            curr = curr->nextNode;
        }
        cout << "NULL" << endl;
    }
};

int main() {
    CharStack cs;
    cs.push('X');
    cs.push('Y');
    cs.push('Z');
    cs.printStack();
    cs.pop();
    cs.printStack();
    return 0;
}
