#include <iostream>
#include <string>
using namespace std;

class StringStack {
    string* arr;
    int top;
    int limit;

public:
    StringStack(int size) {
        limit = size;
        arr = new string[limit];
        top = -1;
    }

    void push(string s) {
        if (top == limit - 1) {
            cout << "Stack is full" << endl;
            return;
        }
        arr[++top] = s;
        cout << "Added string: " << s << endl;
    }

    string peek() {
        if (top == -1) return "Empty";
        return arr[top];
    }

    void pop() {
        if (top == -1) {
            cout << "Nothing to pop" << endl;
            return;
        }
        top--;
    }
};

int main() {
    StringStack ss(5);
    ss.push("Hello");
    ss.push("World");
    cout << "Top is: " << ss.peek() << endl;
    ss.pop();
    cout << "Top now: " << ss.peek() << endl;
    return 0;
}
