#include<iostream>
#include<conio.h>
using namespace std;

struct Node{
    int data;
    Node *next;
};

// Insert at beginning
void insertatbegin(Node *&head,int value){
    Node * newNode=new Node();
    newNode->data=value;
    newNode->next = head;
    head = newNode;
}

// Insert at end
void insertatend(Node*&head,int value){
    Node* newNode=new Node();
    newNode->data=value;
    newNode->next=NULL;
    
    if(head==NULL){
        head=newNode;
    }else{
        Node*temp=head;
        while(temp->next!=NULL){
            temp=temp->next;
        }
        temp->next=newNode;
    }
}

// Insert at specific position
void insertatspecific(Node*& head, int value, int pos) {
    Node* newNode = new Node();
    newNode->data = value;

    if (pos == 1) {
        newNode->next = head;
        head = newNode;
        return;
    }

    Node* temp = head;
    int count = 1;

    while (count < pos - 1 && temp != NULL) {
        temp = temp->next;
        count++;
    }

    if (temp == NULL) {
        cout << "Invalid position!" << endl;
        delete newNode;
    } else {
        newNode->next = temp->next;
        temp->next = newNode;
    }
}

// Delete at specific position
void deleteatspecific(Node*& head, int pos) 
{

    if (head == NULL) 
	{
        cout << "List is empty!" << endl;
        return;
    }

    Node* temp = head;

    // Delete first node
    if (pos == 1) {
        head = temp->next;
        delete temp;
        cout << "Node deleted successfully!" << endl;
        return;
    }

    int count = 1;

    while (count < pos - 1 && temp != NULL) {
        temp = temp->next;
        count++;
    }

    if (temp == NULL || temp->next == NULL) {
        cout << "Invalid position!" << endl;
        return;
    }

    Node* nodeToDelete = temp->next;
    temp->next = nodeToDelete->next;
    delete nodeToDelete;

    cout << "Node deleted successfully!" << endl;
}

// Display list
void traverse(Node* head)
{
    Node *temp=head;
    while(temp!=NULL){
        cout<< "Data : " << temp->data<< endl;
        temp= temp->next;
    }
}

int main()
{
    Node * head=NULL;
    int value;
    int pos;
    int choice;

    do{
        cout<<"\nMenu : " << endl;
        cout<<"1. Insert at beginning "<< endl;
        cout<<"2. Insert at end "<< endl;
        cout<<"3. Insert at specific position "<< endl;
        cout<<"4. Delete at specific position"<< endl;
        cout<<"5. Display list"<< endl;
        cout<<"6. Exit"<< endl;
        cout<<"Choose any one : ";
        cin>>choice;

        switch(choice){
            case 1 :
                cout<< "Enter value to insert : ";
                cin>>value;
                insertatbegin(head,value);
                break;

            case 2 :
                cout<< "Enter value to insert : ";
                cin>>value;
                insertatend(head,value);
                break;

            case 3 :
                cout<< "Enter value to insert : ";
                cin>>value;
                cout<<"Enter position where u want to insert : ";
                cin>>pos;
                insertatspecific(head,value,pos);
                break;

            case 4:
                cout<<"Enter position to delete : ";
                cin>>pos;
                deleteatspecific(head,pos);
                break;

            case 5:
                cout<<"Displaying List  : " << endl;
                traverse(head);
                break;

            case 6 :    
                cout<<"Exiting the menu " << endl;
                break;

            default:
                cout<<"Invalid choice " << endl;
        }

    }
	while(choice!=6);

    return 0;
}
