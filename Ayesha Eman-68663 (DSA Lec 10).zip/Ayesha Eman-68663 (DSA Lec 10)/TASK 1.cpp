#include <iostream>
using namespace std;

// Node structure
class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

// Preorder Traversal (Root ? Left ? Right)
void Preorder(Node* ptr) {
    if (ptr != NULL) {
        cout<<ptr->data<<" ";
        Preorder(ptr->left);
        Preorder(ptr->right);
    }
}

// Inorder Traversal (Left ? Root ? Right)
void Inorder(Node* ptr) {
    if (ptr != NULL) {
        Inorder(ptr->left);
        cout<<ptr->data<<" ";
        Inorder(ptr->right);
    }
}

// Postorder Traversal (Left ? Right ? Root)
void Postorder(Node* ptr) {
    if (ptr != NULL) {
        Postorder(ptr->left);
        Postorder(ptr->right);
        cout<<ptr->data<<" ";
    }
}

void CustomTraversal(Node* temp) {
    if (temp != NULL) {
        cout<<temp->data<<" ";       
        CustomTraversal(temp->left);
        CustomTraversal(temp->right);
        cout<<temp->data<<" ";      
    }
}

void CustomTraversalCount(Node* temp, int count) {
    if (temp != NULL) {
        if (count % 2 == 0) cout<<temp->data<<" ";
        count++;
        CustomTraversalCount(temp->left, count);
        CustomTraversalCount(temp->right, count);
    }
}

int main() {
    Node* root = new Node(14);
    root->left = new Node(4);
    root->right = new Node(15);
    root->left->left = new Node(3);
    root->left->right = new Node(9);
    root->right->right = new Node(18);

    cout<<"Preorder: ";
    Preorder(root);
    cout<<endl;

    cout<<"Inorder: ";
    Inorder(root);
    cout<<endl;

    cout<<"Postorder: ";
    Postorder(root);
    cout<<endl;

    cout<<"Custom Traversal (before & after): ";
    CustomTraversal(root);
    cout<<endl;

    cout<<"Custom Traversal (even depth only): ";
    CustomTraversalCount(root, 0);
    cout<<endl;

    return 0;
}
