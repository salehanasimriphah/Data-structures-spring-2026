#include <iostream>
using namespace std;

struct node
{
    int data;
    node* next;

    node(int val)
    {
        data = val;
        next = NULL;
    }
};

void insertAtPosition(node* &head, int val, int pos)
{
    node* ptr = new node(val);

    if(pos == 1)
    {
        ptr->next = head;
        head = ptr;
        return;
    }

    node* temp = head;
    int count = 1;

    while(count < pos-1 && temp != NULL)
    {
        temp = temp->next;
        count++;
    }

    ptr->next = temp->next;
    temp->next = ptr;
}

void deleteAtPosition(node* &head, int pos)
{
    if(pos == 1)
    {
        node* ptr = head;
        head = head->next;
        delete ptr;
        return;
    }

    node* temp = head;
    int count = 1;

    while(count < pos-1)
    {
        temp = temp->next;
        count++;
    }

    node* ptr = temp->next;
    temp->next = temp->next->next;

    delete ptr;
}

void display(node* head)
{
    node* temp = head;

    while(temp != NULL)
    {
        cout << temp->data << " -> ";
        temp = temp->next;
    }

    cout << "NULL" << endl;
}

int main()
{
    node* head = NULL;

    insertAtPosition(head, 1, 1);
    insertAtPosition(head, 2, 2);
    insertAtPosition(head, 3, 3);
    insertAtPosition(head, 4, 2);

    cout << "Linked List: ";
    display(head);

    deleteAtPosition(head, 3);

    cout << "After Deletion: ";
    display(head);

    return 0;
}
