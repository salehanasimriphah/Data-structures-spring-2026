#include <iostream>
using namespace std;

struct node
{
    int data;
    node* next;
    node* prev;

    node(int val)
    {
        data = val;
        next = NULL;
        prev = NULL;
    }
};

void insertAtStart(node* &head, int val)
{
    node* newnode = new node(val);

    if(head != NULL)
    {
        newnode->next = head;
        head->prev = newnode;
    }

    head = newnode;
}

void insertAtEnd(node* &head, int val)
{
    node* newnode = new node(val);

    if(head == NULL)
    {
        head = newnode;
        return;
    }

    node* temp = head;

    while(temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = newnode;
    newnode->prev = temp;
}

void deleteFromStart(node* &head)
{
    if(head == NULL)
    {
        cout<<"List is empty"<<endl;
        return;
    }

    node* temp = head;
    head = head->next;

    if(head != NULL)
        head->prev = NULL;

    delete temp;
}

void deleteFromEnd(node* &head)
{
    if(head == NULL)
    {
        cout<<"List is empty"<<endl;
        return;
    }

    if(head->next == NULL)
    {
        delete head;
        head = NULL;
        return;
    }

    node* temp = head;

    while(temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->prev->next = NULL;
    delete temp;
}

void display(node* head)
{
    node* temp = head;

    while(temp != NULL)
    {
        cout<<temp->data<<" <-> ";
        temp = temp->next;
    }

    cout<<"NULL"<<endl;
}

int main()
{
    node* head = NULL;

    insertAtStart(head,3);
    insertAtStart(head,2);
    insertAtStart(head,1);

    insertAtEnd(head,4);
    insertAtEnd(head,5);

    cout<<"Doubly Linked List:"<<endl;
    display(head);

    deleteFromStart(head);
    cout<<"After deleting from start:"<<endl;
    display(head);

    deleteFromEnd(head);
    cout<<"After deleting from end:"<<endl;
    display(head);

    return 0;
}
