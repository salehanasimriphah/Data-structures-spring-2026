#include <iostream>
using namespace std;

// Node class
class node {
public:
    int data;
    node* next;

    node(int val) {
        data = val;
        next = NULL;
    }
};

// Insert at Head (for creating list)
void insertAtHead(node* &head, int val) {
    node* ptr = new node(val);
    ptr->next = head;
    head = ptr;
}

// Delete at Any Position
void deleteAtPosition(node* &head, int pos) {
    // delete first node
    if (pos == 1) {
        node* ptr = head;
        head = head->next;
        delete ptr;
        return;
    }

    node* temp = head;
    node* prev = NULL;
    int count = 1;

    
    while (count < pos && temp != NULL) {
        prev = temp;
        temp = temp->next;
        count++;
    }

    // delete node
    prev->next = temp->next;
    delete temp;
}

// Display
void display(node* head) {
    node* temp = head;

    while (temp != NULL) {
        cout << temp->data << " -> ";
        temp = temp->next;
    }

    cout << "NULL" << endl;
}

// Main function
int main() {
    node* head = NULL;

    // create list: 1 -> 2 -> 3 -> 4
    insertAtHead(head, 4);
    insertAtHead(head, 3);
    insertAtHead(head, 2);
    insertAtHead(head, 1);

    cout << "Before Deletion: ";
    display(head);

    // delete at position
    deleteAtPosition(head, 3);

    cout << "After Deletion: ";
    display(head);

    return 0;
}