#include <iostream>
using namespace std;

// Node class
class node {
public:
    int data;
    node* next;

    node(int val) {
        data = val;
        next = NULL;
    }
};

// Insert at Head
void insertAtHead(node* &head, int val) {
    node* ptr = new node(val);
    ptr->next = head;
    head = ptr;
}

// Insert at Any Position
void insertAtPosition(node* &head, int val, int pos) {
    // if position is 1 (start)
    if (pos == 1) {
        insertAtHead(head, val);
        return;
    }

    node* temp = head;
    int count = 1;

    // move to position-1
    while (count < pos - 1 && temp != NULL) {
        temp = temp->next;
        count++;
    }

    // create new node
    node* ptr = new node(val);

    // link nodes
    ptr->next = temp->next;
    temp->next = ptr;
}

// Display
void display(node* head) {
    node* temp = head;

    while (temp != NULL) {
        cout << temp->data << " -> ";
        temp = temp->next;
    }

    cout << "NULL" << endl;
}

// Main function
int main() {
    node* head = NULL;

    // initial list
    insertAtHead(head, 3);
    insertAtHead(head, 2);
    insertAtHead(head, 1);

    cout << "Before Insertion: ";
    display(head);

    // insert at position
    insertAtPosition(head, 99, 2);

    cout << "After Insertion: ";
    display(head);

    return 0;
}