#include<iostream>
using namespace std;

struct node
{
    int data;
    node* next;
};

int main()
{
    node* head = NULL;
    int choice, value, pos;

    do
    {
        cout<<"\n1 Insert";
        cout<<"\n2 Delete";
        cout<<"\n3 Display";
        cout<<"\n4 Exit";
        cout<<"\nEnter choice: ";
        cin>>choice;

        // INSERT
        if(choice == 1)
        {
            cout<<"Enter value: ";
            cin>>value;
            cout<<"Enter position: ";
            cin>>pos;

            node* newnode = new node;
            newnode->data = value;
            newnode->next = NULL;

            if(pos == 1)
            {
                newnode->next = head;
                head = newnode;
            }
            else
            {
                node* temp = head;
                int count = 1;

                while(temp != NULL && count < pos-1)
                {
                    temp = temp->next;
                    count++;
                }

                if(temp == NULL)
                {
                    cout<<"Invalid Position!";
                }
                else
                {
                    newnode->next = temp->next;
                    temp->next = newnode;
                }
            }
        }

        // DELETE
        else if(choice == 2)
        {
            cout<<"Enter position to delete: ";
            cin>>pos;

            if(head == NULL)
            {
                cout<<"List is empty!";
            }
            else if(pos == 1)
            {
                node* temp = head;
                head = head->next;
                delete temp;
            }
            else
            {
                node* temp = head;
                int count = 1;

                while(temp->next != NULL && count < pos-1)
                {
                    temp = temp->next;
                    count++;
                }

                if(temp->next == NULL)
                {
                    cout<<"Invalid Position!";
                }
                else
                {
                    node* del = temp->next;
                    temp->next = del->next;
                    delete del;
                }
            }
        }

        // DISPLAY
        else if(choice == 3)
        {
            node* temp = head;
            while(temp != NULL)
            {
                cout<<temp->data<<" -> ";
                temp = temp->next;
            }
            cout<<"NULL";
        }

    } while(choice != 4);

    return 0;
}
