#include <iostream>
#include <string>
using namespace std;

class SmartDevice {
public:
    // Function Overloading
    void setTemperature(int temp) {
        cout << "Setting temperature to " << temp << " degrees Celsius." << endl;
    }

    void setTemperature(string mode) {
        cout << "Setting mode to: " << mode << endl;
    }

    // Function Overriding (Virtual)
    virtual void turnOn() {
        cout << "SmartDevice is powering up..." << endl;
    }
};

class Thermostat : public SmartDevice {
public:
    void turnOn() override {
        cout << "Thermostat: Calibrating sensors..." << endl;
    }
};

class WaterHeater : public SmartDevice {
public:
    void turnOn() override {
        cout << "WaterHeater: Heating water..." << endl;
    }
};

int main() {
    SmartDevice device;

    // Overloading
    device.setTemperature(22);
    device.setTemperature("BOOST");

    // Overriding
    SmartDevice* devices[2];
    devices[0] = new Thermostat();
    devices[1] = new WaterHeater();

    for (int i = 0; i < 2; i++) {
        devices[i]->turnOn();
    }

    delete devices[0];
    delete devices[1];

    return 0;
}