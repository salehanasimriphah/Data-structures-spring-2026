#include <iostream>
using namespace std;

class Calculator {
public:
    int add(int a, int b) {
        return a + b;
    }

    double add(double a, double b, double c) {
        return a + b + c;
    }
};

int main() {
    Calculator obj;

    cout << obj.add(2, 3) << endl;
    cout << obj.add(2.5, 3.5, 1.5) << endl;

    return 0;
}