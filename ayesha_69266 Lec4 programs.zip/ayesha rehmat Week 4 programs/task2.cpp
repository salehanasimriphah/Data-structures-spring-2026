#include<iostream>
using namespace std;
Class Student{
Int age;
Public:
Student()
{
age=10;
}
Void show()
{
Cout<<�age=�<<age;
}
};
int main()
{
student obj1;
Obj1.show();
}
return 0;

}
