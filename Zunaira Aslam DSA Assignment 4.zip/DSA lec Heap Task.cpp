//Zunaira Aslam 69748
#include <iostream>
using namespace std;

class Heap
{
    int arr[100];
    int size;
    int type; 

public:
    Heap()
    {
        size = 0;

        cout << "Choose Heap Type:\n";
        cout << "1. Max Heap\n";
        cout << "2. Min Heap\n";
        cout << "Enter choice: ";
        cin >> type;

        if (type != 1 && type != 2)
        {
            cout << "Invalid choice!\n";
            exit(0);
        }
    }

    void insertValue()
    {
        if (size >= 100)
        {
            cout << "Heap Overflow!\n";
            return;
        }

        int value;
        cout << "Enter value: ";
        cin >> value;

        arr[size] = value;
        int i = size;
        size++;

        if (type == 1) 
        {
            while (i > 0 && arr[i] > arr[(i - 1) / 2])
            {
                swap(arr[i], arr[(i - 1) / 2]);
                i = (i - 1) / 2;
            }
        }
        else 
        {
            while (i > 0 && arr[i] < arr[(i - 1) / 2])
            {
                swap(arr[i], arr[(i - 1) / 2]);
                i = (i - 1) / 2;
            }
        }

        cout << "Inserted Successfully!\n";
    }

    void deleteRoot()
    {
        if (size == 0)
        {
            cout << "Heap is empty!\n";
            return;
        }

        cout << "Deleted root: " << arr[0] << endl;

        arr[0] = arr[size - 1];
        size--;

        int i = 0;

        while (true)
        {
            int left = 2 * i + 1;
            int right = 2 * i + 2;
            int target = i;

            if (type == 1) 
            {
                if (left < size && arr[left] > arr[target])
                    target = left;

                if (right < size && arr[right] > arr[target])
                    target = right;
            }
            else 
            {
                if (left < size && arr[left] < arr[target])
                    target = left;

                if (right < size && arr[right] < arr[target])
                    target = right;
            }

            if (target != i)
            {
                swap(arr[i], arr[target]);
                i = target;
            }
            else
                break;
        }
    }

    void display()
    {
        if (size == 0)
        {
            cout << "Heap is empty!\n";
            return;
        }

        cout << "Heap Elements: ";
        for (int i = 0; i < size; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }

    void displayTree()
    {
        if (size == 0)
        {
            cout << "Heap is empty!\n";
            return;
        }

        cout << "\nHeap Tree Representation:\n\n";

        int i = 0;
        int level = 0;

        while (i < size)
        {
            int nodes = (1 << level); 
            int count = 0;

            
            for (int j = 0; j < nodes && i < size; j++)
            {
                cout << arr[i] << " ";
                i++;
                count++;
            }

            cout << endl;
			if (i < size)
            {
                for (int j = 0; j < count; j++)
                {
                    cout << "/ \\ ";
                }
                cout << endl;
            }

            level++;
        }
    }
};

int main()
{
    Heap h;
    int choice;

    while (true)
    {
        cout << "\n===== HEAP MENU =====\n";
        cout << "1. Insert\n";
        cout << "2. Delete Root\n";
        cout << "3. Display Heap\n";
        cout << "4. Display Tree\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            h.insertValue();
            break;

        case 2:
            h.deleteRoot();
            break;

        case 3:
            h.display();
            break;

        case 4:
            h.displayTree();
            break;

        case 0:
            cout << "Program Ended\n";
            return 0;

        default:
            cout << "Invalid choice!\n";
        }
    }
}
