#include <iostream>
using namespace std;

struct Node {
    string data;
    Node* left;
    Node* right;
};

Node* createNode(string value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

void inorder(Node* root) {
    if (root != NULL) {
        if (root->left != NULL) cout << "(";
        inorder(root->left);
        cout << root->data;
        inorder(root->right);
        if (root->right != NULL) cout << ")";
    }
}

void preorder(Node* root) {
    if (root != NULL) {
        cout << root->data << " ";
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(Node* root) {
    if (root != NULL) {
        postorder(root->left);
        postorder(root->right);
        cout << root->data << " ";
    }
}

int main() {
   

    Node* root = createNode("*");
    root->left = createNode("+");
    root->right = createNode("C");

    root->left->left = createNode("A");
    root->left->right = createNode("B");

    cout << "Infix Expression: ";
    inorder(root);

    cout << "\nPrefix Expression: ";
    preorder(root);

    cout << "\nPostfix Expression: ";
    postorder(root);

    return 0;
}
