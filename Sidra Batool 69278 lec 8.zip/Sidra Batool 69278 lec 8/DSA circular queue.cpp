#include<iostream>
using namespace std;
#define MAX_SIZE 5
class Queue{
	private:
		int queue[MAX_SIZE];
		int rear;
		int front;
		
	public:
		Queue(){
			front=-1;
			rear=-1;
		}
		
		bool isempty(){
            if(front == -1 && rear == -1){
               return true;
            }
            else{
			   return false;
            }
        }
        
        void enqueue(int value){
            //queue is full
            if((rear+1)%MAX_SIZE==front){
                cout<<"Queue is full"<<endl;
			}
            else{
            //first element inserted
              if(front==-1){
                front=rear=0;
              }
              else{
                	//insert element at rear
                  rear=(rear+1)%MAX_SIZE;
			  }
                queue[rear]=value;
            }
        }
            
            void dequeue(){
               if(isempty()){
                  cout<<"Queue is empty\n";
               }
               else{
                 //only one element
                  if(front==rear){
                    front=rear=-1;
                  }
                  else{
                    front=(front+1)%MAX_SIZE;
                  }
                }
            }

            void showfront(){
               if(isempty()){
			     cout<<"Queue is empty\n";
			   }
               else{
                  cout<<"element at front is:"<<queue[front];
               } 
            }
            
        void displayQueue(){
                if(isempty()){
                   cout<<"Queue is empty"<<endl;
                }
                else{
                   int i=front;
                    if(front<=rear){
                        for(i=front;i<=rear;i++){
                           cout<<queue[i]<<" ";
                        }
                      }
                    else{
                      while(i<MAX_SIZE){
                        cout<<queue[i]<<" ";
                        i++;
                      }
                
                     i=0;
                     while(i<=rear){
                       cout<<queue[i]<<" ";
                       i++;
                     }  
                    }
              cout<<endl;
              cout<<"Rear = "<<rear<<endl;
          } 
	    }
};
int main(){
    Queue obj;    
    obj.dequeue();      //deQueue     
    cout<<"Queue created:"<<endl; 
    obj.enqueue(10); 
    obj.enqueue(20);
    obj.enqueue(30);
    obj.enqueue(40);
    obj.enqueue(50);    
    obj.displayQueue();
    obj.enqueue(60); 
    obj.dequeue();
    obj.displayQueue();
    obj.enqueue(60); 
    obj.displayQueue();
    obj.enqueue(70);    
    return 0;
}
