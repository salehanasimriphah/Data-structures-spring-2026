#include<iostream>
using namespace std;
#define MAX_SIZE 5
class Queue{
	private:
		int queue[MAX_SIZE];
		int rear;
		int front;
		
	public:
		Queue(){
			front=-1;
			rear=-1;
		}
		
		bool isFull(){
			if(rear==MAX_SIZE-1){
				return true;
			}
			else{
				return false;
			}
		}
		
		bool isEmpty(){
			if(front==-1 && rear==-1){
				return true;
			}
			else{
				return false;
			}
		}
		
		void enqueue(int value){
			if(isFull()){
				cout<<"Queue overflow cannot enqueue "<<value<<endl;
				return;
			}
			if(isEmpty()){
				front=0;
				rear=0;
			}
			else{
				rear++;
			}
			queue[rear]=value;
			cout<<"Enqueued "<<value<<endl;
		}
		
		void dequeue(){
			if(isEmpty()){
				cout<<"Queue underflow cannot dequeue "<<endl;
				return;
			}
			int value=queue[front];
			
			if(front==rear){
				front=-1;
				rear=-1;
			}
			else{
				front++;
			}
			
			cout<<"Dequeue "<<value<<endl;
			
		}
};
int main(){
	Queue q;
	q.enqueue(10);
	q.enqueue(20);
	q.enqueue(30);
	q.enqueue(40);
	q.dequeue();
	q.dequeue();
	return 0;
}
