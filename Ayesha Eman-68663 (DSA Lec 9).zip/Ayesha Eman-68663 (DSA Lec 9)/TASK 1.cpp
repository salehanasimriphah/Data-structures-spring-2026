#include <iostream>
#define n 100
using namespace std;

class stack {
    int *arr;   
    int top;    

public:
    stack() {
        arr = new int[n];
        top = -1;
    }
    void push(int x) {
        if (top == n - 1) {
            cout<<"Stack Overflow"<<endl;
            return;
        }
        top++;
        arr[top] = x;
        cout<<"Item pushed: "<<arr[top]<<endl;
    }
    void pop() {
        if (top == -1) {
            cout<<"Stack Underflow"<<endl;
            return;
        }
        cout<<"Item removed: "<<arr[top]<<endl;
        top--;
    }

    int Top() {
        if (top == -1) {
            cout<<"No elements in stack"<<endl;
            return -1;
        }
        return arr[top];
    }

    bool empty() {
        return top == -1;
    }
};

int main() {
    stack st;

    st.push(10);
    st.push(20);
    st.push(30);
    st.push(40);

    cout<<"Top element: "<<st.Top()<<endl; 
    st.pop();

    cout<<"Top element: "<<st.Top()<<endl; 
    st.pop();

    cout<<"Top element: "<<st.Top()<<endl; 
    st.pop();

    cout<<"Top element: "<<st.Top()<<endl; 
    st.pop();

    cout<<"Is stack empty? "<<st.empty()<<endl; 

    return 0;
}
