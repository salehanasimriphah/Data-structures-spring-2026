#include <iostream>
using namespace std;
class Node {
public:
    int data;
    Node* next;
    Node(int val) {
        data = val;
        next = NULL;
    }
};

class Stack {
private:
    Node* top;

public:
    Stack() {
        top = NULL;
    }

    bool isEmpty() {
        return top == NULL;
    }

    void push(int data) {
        Node* newNode = new Node(data);
        newNode->next = top;
        top = newNode;
        cout<<"Item pushed: "<<data<<endl;
    }

    int pop() {
        if (isEmpty()) {
            cout<<"Stack Underflow"<<endl;
            return -1;
        }
        int val = top->data;
        Node* temp = top;
        top = top->next;
        delete temp;
        cout<<"Item removed: "<<val<<endl;
        return val;
    }

    int peek() {
        if (isEmpty()) {
            cout<<"No elements in stack"<<endl;
            return -1;
        }
        return top->data;
    }

    void display() {
        Node* temp = top;
        cout<<"Stack (List): ";
        while (temp != NULL) {
            cout<<temp->data<<" -> ";
            temp = temp->next;
        }
        cout<<"NULL"<<endl;
    }
};

int main() {
    Stack s;
    s.push(1);
    s.push(2);
    s.push(3);
    s.display();

    cout<<"Top element: "<<s.peek()<<endl;
    cout<<"Popped: "<<s.pop()<<endl;
    s.display();

    return 0;
}
