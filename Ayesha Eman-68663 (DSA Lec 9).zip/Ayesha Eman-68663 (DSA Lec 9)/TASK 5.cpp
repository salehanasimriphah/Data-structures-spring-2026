#include <iostream>
using namespace std;

#define SIZE 10

class Stack {
    char arr[SIZE];
    int top;

public:
    Stack() 
	{ 
	    top = -1; 
    }
    void push(char x) {
        if (top == SIZE - 1) {
            cout<<"Stack Overflow"<<endl;
            return;
        }
        arr[++top] = x;
    }

    void pop() {
        if (top == -1) {
            cout<<"Stack Underflow"<<endl;
            return;
        }
        top--;
    }

    void display() {
        cout<<"Stack: ";
        for (int i=top; i>=0; i--) cout<<arr[i]<<" ";
        cout<<endl;
    }
};

int main() {
    Stack S;

    S.push('A'); 
	S.display();
    S.push('B'); 
	S.display();
    S.push('C'); 
	S.display();
    S.pop();    
	S.display();
    S.pop();     
	S.display();
    S.push('D'); 
	S.display();
    S.push('E'); 
	S.display();
    S.pop();     
	S.display();
    S.pop();     
	S.display();

    return 0;
}
