#include <iostream>
using namespace std;
// Node structure
class Node {
public:
    int data;
    Node* next;

    Node(int val) {
        data = val;
        next = NULL;
    }
};
// Stack using linked list
class Stack {
private:
    Node* top;

public:
    Stack() {
        top = NULL;
    }

    // Check if empty
    bool isEmpty() {
        return top == NULL;
    }

    // Push operation
    void push(int data) {
        Node* newNode = new Node(data);
        if (isEmpty()) {
            top = newNode;
        } else {
            newNode->next = top;
            top = newNode;
        }
        cout<<"Item pushed: "<<data<<endl;
    }

    // Pop operation
    void pop() {
        if (isEmpty()) {
            cout<<"Stack Underflow"<<endl;
            return;
        }
        cout<<"Item removed: "<<top->data<<endl;
        Node* temp = top;
        top = top->next;
        delete temp;
    }

    // Top element
    int peek() {
        if (isEmpty()) {
            cout<<"No elements in stack"<<endl;
            return -1;
        }
        return top->data;
    }

    // Display stack
    void display() {
        Node* temp = top;
        cout<<"Stack: ";
        while (temp != NULL) {
            cout<<temp->data<<" -> ";
            temp = temp->next;
        }
        cout<<"NULL"<<endl;
    }
};

int main() {
    Stack obj;

    obj.push(1);
    obj.push(2);
    obj.push(3);

    obj.display(); 

    cout<<"Top element: "<<obj.peek()<<endl;
    obj.pop();

    cout<<"Top element: "<<obj.peek()<<endl; 
    obj.pop();

    cout<<"Top element: "<<obj.peek()<<endl; 
    obj.pop();

    cout<<"Is stack empty? "<<obj.isEmpty()<<endl; 

    return 0;
}
