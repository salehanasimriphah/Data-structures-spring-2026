#include <iostream>
#define STACK_CAPACITY 100
using namespace std;

class Stack {
private:
    int arr[STACK_CAPACITY];
    int top;

public:
    Stack() {
        top = -1;
    }

    bool isEmpty() {
        return top == -1;
    }

    bool isFull() {
        return top == STACK_CAPACITY - 1;
    }

    void push(int value) {
        if (!isFull()) {
            arr[++top] = value;
            cout<<"Item pushed: "<<value<<endl;
        } else {
            cout<<"Stack full can't add new value"<<endl;
        }
    }

    int pop() {
        if (!isEmpty()) {
            return arr[top--];
        } else {
            cout<<"Stack is empty returning -1"<<endl;
            return -1;
        }
    }

    int Top() {
        if (!isEmpty()) {
            return arr[top];
        } else {
            cout<<" Stack is empty returning -1"<<endl;
            return -1;
        }
    }

    void displayStack() {
        cout<<"Stack (Array): ";
        for (int i=top; i>=0; i--) {
            cout<<arr[i]<<" -> ";
        }
        cout<<"NULL"<<endl;
    }
};

int main() {
    Stack s;
    s.push(10);
    s.push(20);
    s.push(30);
    s.displayStack();

    cout<<"Top element: "<<s.Top()<<endl;
    cout<<"Popped: "<<s.pop()<<endl;
    s.displayStack();

    return 0;
}
