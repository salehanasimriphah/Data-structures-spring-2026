//Rihab Sajid
//69585
#include <iostream>
using namespace std;

class Heap
{
    int arr[100];
    int size;
    int type;

public:
    Heap()
    {
        size = 0;
        cout << "1. Max Heap\n";
        cout << "2. Min Heap\n";
        cout << "Enter Choice: ";
        cin >> type;

        if (type != 1 && type != 2)
        {
        cout << "Invalid Choice!\n";
        exit(0);
        }
    }
    
    void insert()
    {
        int value;
        cout << "Enter Value: ";
        cin >> value;
        size++;
        arr[size] = value;
        int i = size;

        if (type == 1)
        {
            while (i > 1 && arr[i] > arr[i / 2])
            {
                swap(arr[i], arr[i / 2]);
                i = i / 2;
            }
        }

        else
        {
            while (i > 1 && arr[i] < arr[i / 2])
            {
                swap(arr[i], arr[i / 2]);
                i = i / 2;
            }
        }

        cout << "Value Inserted Successfully!\n";
    }

    void deleteRoot()
    {
        if (size == 0)
        {
            cout << "Heap is Empty!\n";
            return;
        }
        cout << "Deleted Element: " << arr[1] << endl;
        arr[1] = arr[size];
        size--;
        int i = 1;

        if (type == 1)
        {
            while (true)
            {
                int left = 2 * i;
                int right = 2 * i + 1;
                int largest = i;

                if (left <= size && arr[left] > arr[largest])
                    largest = left;

                if (right <= size && arr[right] > arr[largest])
                    largest = right;

                if (largest != i)
                {
                    swap(arr[i], arr[largest]);
                    i = largest;
                }
                else
                    break;
            }
        }

        else
        {
            while (true)
            {
                int left = 2 * i;
                int right = 2 * i + 1;
                int smallest = i;

                if (left <= size && arr[left] < arr[smallest])
                {
				    smallest = left;
				}

                if (right <= size && arr[right] < arr[smallest])
                {
				    smallest = right;
				}

                if (smallest != i)
                {
                    swap(arr[i], arr[smallest]);
                    i = smallest;
                }
                else
                    break;
            }
        }
    }

    void display()
    {
        if (size == 0)
        {
            cout << "Heap is Empty!\n";
            return;
        }

        cout << "Heap Elements: ";

        for (int i = 1; i <= size; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};

int main()
{
    Heap h;
    int choice;

    while (true)
    {
        cout << "\n HEAP MENU \n";
        cout << "1. Insert\n";
        cout << "2. Delete Root\n";
        cout << "3. Display\n";
        cout << "0. Exit\n";
        cout << "Enter Choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            h.insert();
            break;
        case 2:
            h.deleteRoot();
            break;
        case 3:
            h.display();
            break;
        case 0:
            cout << "Program Ended\n";
            return 0;
        default:
            cout << "Invalid Choice!\n";
        }
    }
}
