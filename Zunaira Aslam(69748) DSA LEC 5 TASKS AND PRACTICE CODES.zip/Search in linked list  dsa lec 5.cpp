#include<iostream>
using namespace std;

class node{
public:
    int data;
    node* next;

    node(int val){
        data=val;
        next=NULL;
    }
};

void insert(node* &head,int val){

    node* ptr=new node(val);

    if(head==NULL){
        head=ptr;
        return;
    }

    node* temp=head;

    while(temp->next!=NULL){
        temp=temp->next;
    }

    temp->next=ptr;
}

bool search(node* head,int key){

    while(head!=NULL){

        if(head->data==key)
            return true;

        head=head->next;
    }

    return false;
}

int main(){

    node* head=NULL;

    insert(head,1);
    insert(head,2);
    insert(head,3);

    if(search(head,2))
        cout<<"Value Found";
    else
        cout<<"Value Not Found";

}
