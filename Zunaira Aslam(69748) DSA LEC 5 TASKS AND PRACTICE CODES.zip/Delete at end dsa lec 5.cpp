#include<iostream>
using namespace std;

class node{
public:
    int data;
    node* next;

    node(int val){
        data=val;
        next=NULL;
    }
};
void insert(node* &head,int val){
node* ptr=new node(val);
if(head==NULL){
        head=ptr;
        return;
    }
node* temp=head;
while(temp->next!=NULL){
        temp=temp->next;
    }

    temp->next=ptr;
}

void deleteAtEnd(node* &head){

    node* ptr=head;
    node* prev;

    while(ptr->next!=NULL){
        prev=ptr;
        ptr=ptr->next;
    }

    prev->next=NULL;
    delete ptr;
}
void display(node* head){
while(head!=NULL){
        cout<<head->data<<" -> ";
        head=head->next;
    }
cout<<"NULL";
}
int main(){
node* head=NULL;
insert(head,1);
    insert(head,2);
    insert(head,3);

    deleteAtEnd(head);

    display(head);

}
