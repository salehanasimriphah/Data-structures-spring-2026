#include<iostream>
using namespace std;

class node{
public:
    int data;
    node* next;

    node(int val){
        data=val;
        next=NULL;
    }
};
void insert(node* &head,int val){
node* ptr=new node(val);
if(head==NULL){
    head=ptr;
        return;
    }

    node* temp=head;

    while(temp->next!=NULL){
        temp=temp->next;
    }

    temp->next=ptr;
}

void deleteAtPosition(node* &head,int pos){

    if(pos==1){
        node* ptr=head;
        head=head->next;
        delete ptr;
        return;
    }

    node* temp=head;

    for(int i=1;i<pos-1;i++){
        temp=temp->next;
    }

    node* del=temp->next;
    temp->next=del->next;

    delete del;
}

void display(node* head){

    while(head!=NULL){
        cout<<head->data<<" -> ";
        head=head->next;
    }

    cout<<"NULL";
}
int main(){
node* head=NULL;
insert(head,1);
insert(head,2);
insert(head,3);
insert(head,4);
deleteAtPosition(head,3);
display(head);

}
