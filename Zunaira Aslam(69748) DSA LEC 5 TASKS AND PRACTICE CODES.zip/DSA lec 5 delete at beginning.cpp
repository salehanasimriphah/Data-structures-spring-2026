#include<iostream>
using namespace std;

class node{
public:
    int data;
    node* next;

    node(int val){
        data=val;
        next=NULL;
    }
};

void insert(node* &head,int val){

    node* ptr=new node(val);
    ptr->next=head;
    head=ptr;
}

void deleteAtHead(node* &head){

    node* ptr=head;
    head=head->next;
    delete ptr;
}

void display(node* head){

    while(head!=NULL){
        cout<<head->data<<" -> ";
        head=head->next;
    }

    cout<<"NULL";
}

int main(){

    node* head=NULL;

    insert(head,3);
    insert(head,2);
    insert(head,1);

    deleteAtHead(head);

    display(head);

}
