#include<iostream>
using namespace std;
class node{
public:
    int data;
    node* next;
node(int val){
        data=val;
        next=NULL;
    }
};
void insertAtPosition(node* &head,int val,int pos){
node* ptr=new node(val);
if(pos==1){
        ptr->next=head;
        head=ptr;
        return;
    }
node* temp=head;

    for(int i=1;i<pos-1;i++){
        temp=temp->next;
    }

    ptr->next=temp->next;
    temp->next=ptr;
}

void display(node* head){

    while(head!=NULL){
        cout<<head->data<<" -> ";
        head=head->next;
    }

    cout<<"NULL";
}

int main(){

    node* head=NULL;
     insertAtPosition(head,1,1);
    insertAtPosition(head,2,2);
    insertAtPosition(head,4,3);
    insertAtPosition(head,3,3);

    display(head);

}
