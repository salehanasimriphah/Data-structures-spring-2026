#include<iostream>
using namespace std;
class node{
public:
    int data;
    node* next;
	node(int val){
        data = val;
        next = NULL;
    }
};
void insertAtHead(node* &head,int val){
    node* ptr = new node(val);
    ptr->next = head;
    head = ptr;
}
void display(node* head){
    node* temp = head;
	while(temp!=NULL){
        cout<<temp->data<<" -> ";
        temp=temp->next;
    }
cout<<"NULL";
}
int main(){
node* head=NULL;
insertAtHead(head,3);
    insertAtHead(head,2);
    insertAtHead(head,1);
display(head);

}
