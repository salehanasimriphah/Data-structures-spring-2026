#include<iostream>
using namespace std;
class node{
public:
    int data;
    node* next;
node(int val){
        data = val;
        next = NULL;
}
};
void insertAtTail(node* &head,int val){
node* ptr=new node(val);
if(head==NULL){
        head=ptr;
        return;
    }
   node* temp=head;
   while(temp->next!=NULL){
        temp=temp->next;
    }

    temp->next=ptr;
}

void display(node* head){

    while(head!=NULL){
        cout<<head->data<<" -> ";
        head=head->next;
    }

    cout<<"NULL";
}
int main(){

    node* head=NULL;

    insertAtTail(head,1);
    insertAtTail(head,2);
    insertAtTail(head,3);
    insertAtTail(head,4);

    display(head);

}
