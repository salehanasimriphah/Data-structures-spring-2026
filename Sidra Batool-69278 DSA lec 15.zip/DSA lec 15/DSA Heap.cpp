#include <iostream>
using namespace std;
class MaxHeap {
    int *arr;
    int size;
    int capacity;
public:
    MaxHeap(int cap) {
        capacity = cap;
        size = 0;
        arr = new int[cap];
    }
    void insert(int value) {
        if (size == capacity) {
		   return;
	   }
	   
        int i = size;
        arr[size++] = value;

        while (i != 0 && arr[(i - 1) / 2] < arr[i]) {
            swap(arr[i], arr[(i - 1) / 2]);
            i = (i - 1) / 2;
        }
    }
    void heapify(int i) {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        if (left < size && arr[left] > arr[largest]){
            largest = left;
        }
        if (right < size && arr[right] > arr[largest]){
            largest = right;
        }
        if (largest != i) {
            swap(arr[i], arr[largest]);
            heapify(largest);
        }
    }
    
    int extractMax() {
        if (size <= 0){
		   return -1;
	    }
	    
        if (size == 1){
		   return arr[--size];
	    }
	    
        int root = arr[0];
        arr[0] = arr[--size];
        heapify(0);
        return root;
    }
    
    void buildHeap() {
        for (int i = (size / 2) - 1; i >= 0; i--)
            heapify(i);
    }
    
    void display() {
        for (int i = 0; i < size; i++)
            cout << arr[i] << " ";
        cout << endl;
    }
};
int main() {
    MaxHeap h(10);
    h.insert(40);
    h.insert(10);
    h.insert(30);
    h.insert(50);
    h.insert(20);
    cout << "Heap: ";
    h.display();
    cout << "Deleted Max: " << h.extractMax() << endl;
    cout << "Heap After Deletion: ";
    h.display();
}