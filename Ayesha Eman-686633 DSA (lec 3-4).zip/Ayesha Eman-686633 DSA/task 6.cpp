#include<iostream>
using namespace std;
void add(int a,int b)
{
	cout<<"sum is :"<<a+b<<endl;
}
void add(double a,double b)
{
	cout<<"sum is :"<<a+b<<endl;
}
int main()
{
	add(1,5);
	add(1.2,2.2);
}
