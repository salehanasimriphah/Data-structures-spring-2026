#include<iostream>
using namespace std;

class student{
    int age;
	public:
    student()
    {
      age=10;
    }
    void show()
   {
      cout<<"age="<<age;
   }
};
int main()
{
    student obj1;
    obj1.show();
}

