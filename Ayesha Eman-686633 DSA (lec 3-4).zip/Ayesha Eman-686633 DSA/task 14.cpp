#include<iostream>
using namespace std;

struct student
{ int rollno;
  char name[20];
}; 
int main()
{
  student s1;
  cin>>s1.rollno;
  gets(s1.name);  
  student *stu;
  stu=&s1; 
  cout<<stu->rollno<<stu->name;
}

