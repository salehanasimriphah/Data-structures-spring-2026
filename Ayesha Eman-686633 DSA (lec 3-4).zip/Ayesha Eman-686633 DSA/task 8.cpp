#include <iostream>
using namespace std;

class Parent {
public:
    void show()
    {
        cout<<"Base Function"<<endl;
    }
};

class child : public Parent
{
public:
    void show()
    {
        cout<<"Derived Function"<<endl;
    }
};

int main()
{
    child obj;
    obj.Parent::show();   
    return 0;
}
