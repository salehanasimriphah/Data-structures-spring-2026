#include<iostream>
using namespace std;
class student
{
public:   
    string name;
    int age;
    void show()
    { 
        cout<<"your name :"<<name<<endl;
        cout<<"your age is:"<<age<<endl;
    }
};
int main()
{
   student obj1;
   obj1.name = "sana";
   obj1.age = 30;
   obj1.show();
   return 0;
}


