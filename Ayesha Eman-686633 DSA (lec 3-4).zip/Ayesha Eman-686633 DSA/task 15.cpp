#include <iostream>
using namespace std;

class student
{
public:                 
    int rollno;
    char name[20];

    void indata()
    {
        cout<<"Enter roll no: ";
        cin>>rollno;

        cout<<"Enter name: ";
        cin>>name;   
    }

    void outdata()
    {
        cout<<"Roll No: "<<rollno<<endl;
        cout<<"Name: "<<name<<endl;
    }
};

int main()
{
    student s1, *stu;
    s1.indata();

    stu=&s1;   

    s1.outdata();
    stu->outdata();  

    return 0;
}
