#include<iostream>
using namespace std;
struct Node{
	int data;
	Node *next;
};
void InsertAtEnd(Node *&head,int value){
	Node *node1=new Node();
	node1->data=value;
	node1->next=NULL;
	
	if(head==NULL){
		node1->next=head;
		head=node1;
	}
	else{
		Node *temp=head;
		while(temp->next!=NULL){
			temp=temp->next;
		}
		temp->next=node1;
	}
	
}

void display(Node *head){
	Node *temp=head;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp=temp->next;
	}
}
int main(){
	Node *head=NULL;
	InsertAtEnd(head,10);
	display(head);
	cout<<endl;
	
	InsertAtEnd(head,20);
	display(head);
	cout<<endl;
	
	InsertAtEnd(head,30);
	display(head);
	cout<<endl;
	
	return 0;
}