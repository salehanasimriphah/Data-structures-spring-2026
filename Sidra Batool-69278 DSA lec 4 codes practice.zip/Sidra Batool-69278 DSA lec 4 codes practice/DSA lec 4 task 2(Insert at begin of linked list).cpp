#include<iostream>
using namespace std;
struct Node{
	int data;
	Node *next;
};
void InsertAtBegin(Node *&head,int value){
	Node *node1=new Node();
	node1->data=value;
	node1->next=head;
	head=node1;
}
void display(Node *head){
	Node *temp=head;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp=temp->next;
	}
}
int main(){
	Node *head=NULL;
	InsertAtBegin(head,10);
	display(head);
	cout<<endl;
	
	InsertAtBegin(head,20);
	display(head);
	cout<<endl;
	
	InsertAtBegin(head,30);
	display(head);
	cout<<endl;
	return 0;
}