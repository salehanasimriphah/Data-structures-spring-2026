#include<iostream>
using namespace std;
struct Node{
	int data;
	Node *next;
};
void DeleteAtPosition(Node *head,int pos){
	if(head==NULL){
		cout<<"Linked list is empty"<<endl;
		return;
	}
	 
	 if(pos==1){
	 	Node *temp=head;
	 	head=head->next;
	 	cout<<"Deleting from Begin: "<<temp->data<<endl;
	 	delete temp;
	 }
	 
	 Node *temp=head;
	 int count=1;
	 while(count<pos-1 && temp!=NULL){
	 	temp=temp->next;
	 }
	 if(temp==NULL){
	 	cout<<"Invalid position"<<endl;
	 }
	 else{
	 	Node *del=temp->next;
	 	temp->next=del->next;
	 	cout<<"Deleting: "<<del->data<<endl;
	 	delete del;
	 }
}
void InsertAtBegin(Node *&head,int value){
	Node *node1=new Node();
	node1->data=value;
	node1->next=head;
	head=node1;
}

void display(Node *head){
	Node *temp=head;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp=temp->next;
	}
}
int main(){
	Node *head=NULL;
	
	InsertAtBegin(head,10);
	display(head);
	cout<<endl;
	
	InsertAtBegin(head,20);
	display(head);
	cout<<endl;
	
	InsertAtBegin(head,30);
	display(head);
	cout<<endl;
	
	DeleteAtPosition(head,2);
	display(head);
	cout<<endl;
	
	return 0;
}