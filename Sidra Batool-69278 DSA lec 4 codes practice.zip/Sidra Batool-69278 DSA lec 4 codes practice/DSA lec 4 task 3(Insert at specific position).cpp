#include<iostream>
using namespace std;
struct Node{
	int data;
	Node *next;
};
void InsertAtPosition(Node *&head,int value,int pos){
	Node *node1=new Node();
	node1->data=value;
	
	if(pos==1){
		node1->next=head;
		head=node1;
		return;
	}
	
	Node *temp=head;
	int count=1;
	while(count<pos-1 && temp!=NULL){
		temp=temp->next;
		count++;
	}
	if(temp==NULL){
		cout<<"Invalid Position"<<endl;
		delete node1;
	}
	else
	{
	node1->next=temp->next;
	temp->next=node1;
   }
}

void display(Node *head){
	Node *temp=head;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp=temp->next;
	}
}
int main(){
	Node *head=NULL;
	
	InsertAtPosition(head,10,1);
	display(head);
	cout<<endl;
	
	InsertAtPosition(head,20,2);
	display(head);
	cout<<endl;
	
	InsertAtPosition(head,30,3);
	display(head);
	cout<<endl;
	
	InsertAtPosition(head,25,3);
	display(head);
	cout<<endl;
	return 0;
}