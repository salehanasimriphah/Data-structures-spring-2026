#include<iostream>
using namespace std;
struct Node{
	int data;
	Node *next;
};

void InsertAtBegin(Node *&head,int value){
	Node *node1=new Node();
	node1->data=value;
	node1->next=head;
	head=node1;
}
void DeleteAtBegin(Node *&head){
	
	if(head==NULL){
		cout<<"Linked list is empty"<<endl;
		return;
	}
	else{
		Node *temp=head;
		head=head->next;
		cout<<"Deleting from Begin: "<<temp->data<<endl;
		delete temp;
	}
}
void display(Node *head){
	Node *temp=head;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp=temp->next;
	}
}
int main(){
	Node *head=NULL;
	
	InsertAtBegin(head,10);
	display(head);
	cout<<endl;
	
	InsertAtBegin(head,20);
	display(head);
	cout<<endl;
	
	InsertAtBegin(head,30);
	display(head);
	cout<<endl;
	
	DeleteAtBegin(head);
	display(head);
	cout<<endl;
	
	return 0;
}