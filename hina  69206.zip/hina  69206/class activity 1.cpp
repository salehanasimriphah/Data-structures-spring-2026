#include <iostream>
#include <string>
// Define the Student class
class Student {
public:
    // Attributes
    std::string name;
    int roll_no;
    double gpa;
    // Constructor to initialize the attributes
    Student(std::string student_name, int student_roll_no, double student_gpa) {
        name = student_name;
        roll_no = student_roll_no;
        gpa = student_gpa;
    }
    // Method to display student information
    void display_info() {
        std::cout << "Name: " << name << std::endl;
        std::cout << "Roll No: " << roll_no << std::endl;
        std::cout << "GPA: " << gpa << std::endl;
    }
};
int main() {
    // Create an object of the Student class
    Student student1("hina rauf", 101, 3.85);
    // Call the display_info() method to show the student's details
    student1.display_info();
    return 0;
}
