#include <iostream>
using namespace std;
int main() 
{
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;    // Dynamically allocate memory for the array
    int* arr = new int[size];    // Input values
    cout << "Enter " << size << " elements:\n";
    for (int i = 0; i < size; i++) 
           {
           cin >> arr[i];  // same as *(arr + i)
            }    // Output values    
   cout << "You entered:\n";
    for (int i = 0; i < size; i++) 
{
        cout << arr[i] << " ";
    }    // Free the allocated memory
    delete[] arr;
    return 0;
}
