#include <iostream>
using namespace std;

void updateArray(int *arr, int size) {
    for(int i = 0; i < size; i++) {
        arr[i] = arr[i] * 2;
    }
}

int main() {
    int numbers[3] = {1, 2, 3};

    updateArray(numbers, 3);

    cout << "Updated Array: ";
    for(int i = 0; i < 3; i++) {
        cout << numbers[i] << " ";
    }

    return 0;
}
