#include <iostream>
#include <string>

class Car {
public:
    // Attributes
    std::string brand;
    std::string model;
    int year;

    // Constructor to initialize the attributes
    Car(std::string carBrand, std::string carModel, int carYear) {
        brand = carBrand;
        model = carModel;
        year = carYear;
    }

    // Method to start the car
    void start() {
        std::cout << brand << " " << model << " is starting..." << std::endl;
    }
};

int main() {
	 Car car1("Toyota", "Corolla", 2022);

    // Car start karna
    car1.start();

    return 0;
}
