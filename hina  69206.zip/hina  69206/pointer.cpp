#include <iostream>
using namespace std;

// Function that receives pointer
void changeValue(int *ptr) {
    *ptr = 100;   // Dereferencing pointer
}

int main() {
    int num = 10;

    cout << "Before function call: " << num << endl;

    changeValue(&num);   // Address pass kar rahe hain

    cout << "After function call: " << num << endl;

    return 0;
}
