#include <iostream>
using namespace std;

class Car {
public:
    string brand;

    // Default Constructor
    Car() {
        brand = "Toyota";
        cout << "Constructor Called" << endl;
    }
};

int main() {
    Car c1;   // Automatically constructor call hoga

    cout << "Brand: " << c1.brand << endl;

    return 0;
}
