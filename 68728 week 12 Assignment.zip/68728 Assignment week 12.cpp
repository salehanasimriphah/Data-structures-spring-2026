#include <iostream>
using namespace std;
struct TreeNode {
    char data;
    TreeNode* left;
    TreeNode* right;
    TreeNode(char val)
    {
    	data = val;
    	right=left = NULL;
	}
};
void inOrder(TreeNode* root) {
    if (root == NULL){
    	return;
	}
        inOrder(root->left);
        cout << root->data << " ";
        inOrder(root->right);
    }
void preOrder(TreeNode* root) {
    if (root == NULL){
    	return;
	}
        cout << root->data << " ";
        preOrder(root->left);
        preOrder(root->right);
    }
void postOrder(TreeNode* root) {
    if (root == NULL){
    	return;
	}
        postOrder(root->left);
        postOrder(root->right);
        cout << root->data << " ";
}
int main() {
TreeNode* root = new TreeNode('A');
root->left = new TreeNode('B');
root->left->left = new TreeNode('D');
root->left->right = new TreeNode('E');
root->right = new TreeNode('C');
root->right->left = new TreeNode('F');
root->right->right = new TreeNode('G');
root->left->left->left= new TreeNode('H');
root->left->left->right= new TreeNode('I');
cout << "In-order traversal: ";
inOrder(root);
cout << endl;
cout << "Pre-order traversal: ";
preOrder(root);
cout << endl;
cout << "Post-order traversal: ";
postOrder(root);
cout << endl;
    return 0;
}
