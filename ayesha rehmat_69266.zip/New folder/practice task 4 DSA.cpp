#include <iostream>
#include <string>

class Car {
public:
    std::string brand;
    std::string model;
    int year;
    Car(std::string carBrand, std::string carModel, int carYear) {
        brand = carBrand;
        model = carModel;
        year = carYear;
    }
    void start() {
        std::cout << brand << " " << model << " is starting..." << std::endl;
    }
};

int main() {
    Car car1("honda", "aspire", 2022);
    car1.start();
    
    return 0;
}
