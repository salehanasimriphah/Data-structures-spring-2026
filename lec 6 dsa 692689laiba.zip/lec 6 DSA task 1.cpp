#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
    Node* prev;

    Node(int value) {
        data = value;
        next = NULL;
        prev = NULL;
    }
};

void insertAtPosition(Node* &head, int pos, int value) {

    Node* newNode = new Node(value);
    Node* temp = head;

    for(int i = 1; i < pos-1; i++) {
        temp = temp->next;
    }

    newNode->next = temp->next;
    newNode->prev = temp;

    if(temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;
}

void display(Node* head) {
    Node* temp = head;
    while(temp != NULL) {
        cout << temp->data << "  ";
        temp = temp->next;
    }
    cout << "NULL"<<endl;
}

int main() {

    Node* head = new Node(10);
    Node* second = new Node(20);
    Node* third = new Node(30);
    Node* fourth = new Node(50);

    head->next = second;

    second->prev = head;
    second->next = third;

    third->prev = second;
    third->next = fourth;

    fourth->prev = third;

    cout << "Before Insertion:"<<endl;
    display(head);

    insertAtPosition(head,4,40);

    cout << "After Insertion at position 4:"<<endl;
    display(head);

    return 0;
}