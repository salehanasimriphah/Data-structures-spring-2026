#include <iostream>
using namespace std;

struct Node 
{
    int data;
    Node* next;
};
Node* head = NULL;

void insertAtPosition(int value, int pos) 
{
    Node* newNode = new Node;
    newNode->data = value;
    newNode->next = NULL;
   
    if (pos == 1) 
	{
        newNode->next = head;
        head = newNode;
        return;
    }
   
    Node* temp = head;
    int i = 1;
    while (i < pos - 1 && temp != NULL) 
	{
        temp = temp->next;
        i++;
    }
    
    if (temp == NULL)
	{
        cout << "Invalid position" << endl; 
        return;
    }
    
    newNode->next = temp->next;
    temp->next = newNode;
}

void display() 
{
    Node* temp = head;
    
  
    if (temp == NULL) {
        cout << "Invalid Position" << endl;
        return;
    }
    
    while (temp != NULL)
	{
        cout << temp->data << endl;
        temp = temp->next;
    }
    
}

int main() 
{
   
    insertAtPosition(10, 1);  
    insertAtPosition(20, 2);  
    insertAtPosition(30, 3);  
     display();
 cout<<"Insert at position 2"<<endl;
 insertAtPosition(50,2);
    display();
    
    return 0;
}