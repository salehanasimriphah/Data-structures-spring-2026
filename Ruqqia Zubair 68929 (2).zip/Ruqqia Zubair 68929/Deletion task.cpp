#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* head = NULL;
void deleteAtPosition(int position) {

    if (head == NULL) {
        cout << "Empty list" << endl;
        return;
    }
    if (position == 1) {
        Node* temp = head;
        head = head->next;
        delete temp;
        return;
    }

    Node* temp = head;

    for (int i = 1; i < position - 1 && temp != NULL; i++) 
	{
        temp = temp->next;
    }

    if (temp == NULL || temp->next == NULL) 
	{
        cout << "Invalid Position!" << endl;
        return;
    }

    Node* nodeToDelete = temp->next;
    temp->next = nodeToDelete->next;

    delete nodeToDelete;
}
void insertAtBeginning(int value) 
{
    Node* newNode = new Node;
    newNode->data = value;
    newNode->next = head;
    head = newNode;
}
void display() {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data <<endl;
        temp = temp->next;
    }
  
}

int main() {

    insertAtBeginning(40);
    insertAtBeginning(30);
    insertAtBeginning(20);
    insertAtBeginning(10);
cout<<"Before deletion"<<endl;
    display();
 cout<<"After deletion"<<endl;   
    deleteAtPosition(3);
    display();
}