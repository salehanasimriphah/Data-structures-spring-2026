#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

void insertAtPosition(Node*& head, int data, int position) {

    Node* newNode = new Node();
    newNode->data = data;
    newNode->next = NULL;
    newNode->prev = NULL;

    Node* temp = head;

    for(int i = 1; i < position-1; i++) {
        temp = temp->next;
    }

    newNode->next = temp->next;
    newNode->prev = temp;

    if(temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;
}

void printList(Node* head) {
    while(head != NULL) {
        cout << head->data << " ";
        head = head->next;
    }
}

int main() {

    Node* head = new Node{10,NULL,NULL};
    Node* n2 = new Node{20,head,NULL};
    head->next = n2;

    Node* n3 = new Node{30,n2,NULL};
    n2->next = n3;

    Node* n4 = new Node{40,n3,NULL};
    n3->next = n4;

    insertAtPosition(head,25,4);

    printList(head);
}
