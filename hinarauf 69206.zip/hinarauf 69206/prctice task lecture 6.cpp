
#include <iostream>
using namespace std;

struct Node{
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;
void insertBegin(int val){
    Node* newNode = new Node;
    newNode->data = val;
    newNode->prev = NULL;
    newNode->next = head;

    if(head != NULL)
        head->prev = newNode;

    head = newNode;
}
void insertEnd(int val){
    Node* newNode = new Node;
    newNode->data = val;
    newNode->next = NULL;

    if(head == NULL){
        newNode->prev = NULL;
        head = newNode;
        return;
    }

    Node* temp = head;
    while(temp->next != NULL)
        temp = temp->next;

    temp->next = newNode;
    newNode->prev = temp;
}
 
void insertPosition(int val,int pos){

    if(pos == 1){
        insertBegin(val);
        return;
    }

    Node* newNode = new Node;
    newNode->data = val;

    Node* temp = head;

    for(int i=1;i<pos-1;i++)
        temp = temp->next;

    newNode->next = temp->next;
    newNode->prev = temp;

    if(temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;
}
void deleteBegin(){

    if(head == NULL){
        cout<<"List Empty\n";
        return;
    }

    Node* temp = head;
    head = head->next;

    if(head != NULL)
        head->prev = NULL;

    delete temp;
}
void deleteEnd(){

    if(head == NULL){
        cout<<"List Empty\n";
        return;
    }

    Node* temp = head;

    while(temp->next != NULL)
        temp = temp->next;

    if(temp->prev != NULL)
        temp->prev->next = NULL;
    else
        head = NULL;

    delete temp;
}
void deletePosition(int pos){

    Node* temp = head;

    for(int i=1;i<pos;i++)
        temp = temp->next;

    if(temp->prev != NULL)
        temp->prev->next = temp->next;

    if(temp->next != NULL)
        temp->next->prev = temp->prev;

    delete temp;
}
void display(){

    Node* temp = head;

    while(temp != NULL){
        cout<<temp->data<<" <-> ";
        temp = temp->next;
    }
    cout<<"NULL\n";
}

int main(){

    int choice,val,pos;

    do{

        cout<<"\n1 Insert Begin"<<endl;
        cout<<"\n2 Insert End"<<endl;
        cout<<"\n3 Insert Position"<<endl;
        cout<<"\n4 Delete Begin"<<endl;
        cout<<"\n5 Delete End"<<endl;
        cout<<"\n6 Delete Position"<<endl;
        cout<<"\n7 Display"<<endl;
        cout<<"\n8 Exit"<<endl;

        cout<<"\nEnter choice: ";
        cin>>choice;

        switch(choice){

        case 1:
            cout<<"Enter value: ";
            cin>>val;
            insertBegin(val);
            break;

        case 2:
            cout<<"Enter value: ";
            cin>>val;
            insertEnd(val);
            break;

        case 3:
            cout<<"Enter value and position: ";
            cin>>val>>pos;
            insertPosition(val,pos);
            break;

        case 4:
            deleteBegin();
            break;

        case 5:
            deleteEnd();
            break;

        case 6:
            cout<<"Enter position: ";
            cin>>pos;
            deletePosition(pos);
            break;

        case 7:
            display();
            break;

        }

    }while(choice!=8);

}
