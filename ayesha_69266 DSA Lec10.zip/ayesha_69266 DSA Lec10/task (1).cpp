#include <iostream>
using namespace std;

class TreeNode {
public:
    char val;
    TreeNode* left;
    TreeNode* right;

    TreeNode(char data) {
        val = data;
        left = right = NULL;
    }
};

void printLeaves(TreeNode* node) {
    if (node == NULL) return;
    
    if (node->left == NULL && node->right == NULL) {
        cout << node->val << " ";
    }
    
    printLeaves(node->left);
    printLeaves(node->right);
}

int main() {
    TreeNode* root = new TreeNode('A');
    root->left = new TreeNode('B');
    root->right = new TreeNode('C');
    root->left->left = new TreeNode('D');
    root->right->left = new TreeNode('E');
    root->right->right = new TreeNode('F');

    cout << "Tree Leaves: ";
    printLeaves(root);
    cout << endl;

    return 0;
}
