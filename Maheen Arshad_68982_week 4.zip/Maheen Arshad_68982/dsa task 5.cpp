#include <iostream>
using namespace std;

struct node
{
    int data;
    node* next;

    node(int val)
    {
        data = val;
        next = NULL;
    }
};

void insertAtTail(node*& head, int val)
{
    node* ptr = new node(val);

    if (head == NULL)
    {
        head = ptr;
        return;
    }

    node* temp = head;
    while (temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = ptr;
}

// delete from beginning 
void deleteAtHead(node*& head)
{
    if (head == NULL)
        return;

    node* ptr = head;
    head = head->next;
    delete ptr;
}

void display(node* head)
{
    node* temp = head;
    while (temp != NULL)
    {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

int main()
{
    node* head = NULL;

    insertAtTail(head, 10);
    insertAtTail(head, 20);
    insertAtTail(head, 30);

    cout << "Before deletion: ";
    display(head);

    deleteAtHead(head);

    cout << "After deletion: ";
    display(head);

    return 0;
}
