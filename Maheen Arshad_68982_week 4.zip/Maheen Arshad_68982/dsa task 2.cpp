#include <iostream>
using namespace std;

struct node
{
    int data;
    node* next;

    node(int val)
    {
        data = val;
        next = NULL;
    }
};

void insertAtHead(node*& head, int val)
{
    node* ptr = new node(val);
    ptr->next = head;
    head = ptr;
}

void insertAtPosition(node*& head, int val, int pos)
{
    if (pos == 1)
    {
        insertAtHead(head, val);
        return;
    }

    node* ptr = new node(val);
    node* temp = head;

    for (int i = 1; i < pos - 1 && temp != NULL; i++)
    {
        temp = temp->next;
    }

    if (temp == NULL)
    {
        cout << "Position out of range!" << endl;
        return;
    }

    ptr->next = temp->next;
    temp->next = ptr;
}

void display(node* head)
{
    node* temp = head;
    while (temp != NULL)
    {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

int main()
{
    node* head = NULL;

    insertAtHead(head, 30);
    insertAtHead(head, 20);
    insertAtHead(head, 10);

    insertAtPosition(head, 25, 3);   

    display(head);

    return 0;
}
