#include <iostream>
using namespace std;

struct node
{
    int data;
    node* next;

    node(int val)
    {
        data = val;
        next = NULL;
    }
};

void insertAtTail(node*& head, int val)
{
    node* ptr = new node(val);

    if (head == NULL)
    {
        head = ptr;
        return;
    }

    node* temp = head;
    while (temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = ptr;
}

bool search(node* head, int key)
{
    node* temp = head;
    while (temp != NULL)
    {
        if (temp->data == key)
        {
            return true;
        }
        temp = temp->next;
    }
    return false;
}

void display(node* head)
{
    node* temp = head;
    while (temp != NULL)
    {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

int main()
{
    node* head = NULL;

    insertAtTail(head, 10);
    insertAtTail(head, 20);
    insertAtTail(head, 30);

    display(head);

    int key = 20;
    if (search(head, key))
        cout << key << " found in list." << endl;
    else
        cout << key << " not found in list." << endl;

    key = 40;
    if (search(head, key))
        cout << key << " found in list." << endl;
    else
        cout << key << " not found in list." << endl;

    return 0;
}
