#include <iostream>
using namespace std;

struct node
{
    int info;
    node *next;
};

node *start = NULL;

// Add at front
void addfront()
{
    node *t = start;
    node *n = new node;

    cout << "Enter the information: ";
    cin >> n->info;

    if (start == NULL)
    {
        start = n;
        start->next = start;
    }
    else
    {
        n->next = start;
        while (t->next != start)
            t = t->next;

        t->next = n;
        start = n;
    }
}

// Add at last
void addlast()
{
    node *t = start;
    node *n = new node;

    cout << "Enter the information: ";
    cin >> n->info;

    if (start == NULL)
    {
        start = n;
        start->next = start;
    }
    else
    {
        while (t->next != start)
            t = t->next;

        t->next = n;
        n->next = start;
    }
}

// Delete from front
void delfront()
{
    node *t = start;

    if (start == NULL)
        cout << "Empty list" << endl;
    else if (start->next == start)
    {
        delete t;
        start = NULL;
    }
    else
    {
        while (t->next != start)
            t = t->next;

        node *temp = start;
        start = start->next;
        delete temp;
        t->next = start;
    }
}

// Delete from last
void dellast()
{
    node *t = start;

    if (start == NULL)
        cout << "Empty list" << endl;
    else if (start->next == start)
    {
        delete t;
        start = NULL;
    }
    else
    {
        while (t->next->next != start)
            t = t->next;

        delete t->next;
        t->next = start;
    }
}

// Display
void display()
{
    node *t = start;

    if (start == NULL)
        cout << "Empty list" << endl;
    else
    {
        do
        {
            cout << t->info << " ";
            t = t->next;
        } while (t != start);
        cout << endl;
    }
}

// Main
int main()
{
    int choice;

    do
    {
        cout << endl;
        cout << "--- MENU ---" << endl;
        cout << "1. Add Front" << endl;
        cout << "2. Add Last" << endl;
        cout << "3. Delete Front" << endl;
        cout << "4. Delete Last" << endl;
        cout << "5. Display" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            addfront();
            break;
        case 2:
            addlast();
            break;
        case 3:
            delfront();
            break;
        case 4:
            dellast();
            break;
        case 5:
            display();
            break;
        case 6:
            cout << "Exiting..." << endl;
            break;
        default:
            cout << "Invalid choice!" << endl;
        }

    } while (choice != 6);

    return 0;
}