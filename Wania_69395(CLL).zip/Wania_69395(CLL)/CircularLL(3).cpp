#include <iostream>
using namespace std;

struct node
{
    int info;
    node *next;
};

node *start = NULL;

void addfront()
{
    node *t = start;
    node *n = new node;

    cout << "Enter the information: ";
    cin >> n->info;

    if (start == NULL)
    {
        start = n;
        start->next = start;
    }
    else
    {
        n->next = start;
        while (t->next != start)
            t = t->next;

        t->next = n;
        start = n;
    }
}
void deleteNode(int pos)
{
   
    if (start == NULL)
    {
        cout << "List is empty" << endl;
        return;
    }

    node *temp = start;
    node *current = NULL;

   
    if (pos == 1)
    {
       
        if (start->next == start)
        {
            delete start;
            start = NULL;
            return;
        }

        
        while (temp->next != start)
            temp = temp->next;

        node *old = start;
        start = start->next;
        temp->next = start;   
        delete old;

        return;
    }

  
    current = start;

  
    for (int i = 1; i < pos - 1; i++)
    {
        current = current->next;

      
        if (current->next == start)
        {
            cout << "Invalid position" << endl;
            return;
        }
    }

    temp = current->next; 

   
    if (temp == start)
    {
        cout << "Invalid position" << endl;
        return;
    }

   
    current->next = temp->next;

    delete temp;
}
void display()
{
    node *t = start;

    if (start == NULL)
        cout << "Empty list" << endl;
    else
    {
        do
        {
            cout << t->info << " ";
            t = t->next;
        } while (t != start);
        cout << endl;
    }
}

 int main(){
 	
  
  addfront();
  addfront();
  addfront();
  addfront();

  
  display();
  cout<<"Deleting position 3 : " << endl;
  deleteNode(3);
   display();
//Invalid position
  deleteNode(7);
    

    
    return 0;
}