#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int val) {
        data = val;
        next = nullptr;
    }
};
void insertAtPosition(Node* &head, int data, int position) {
    Node* newNode = new Node(data);
  
    if (head == nullptr) {
        head = newNode;
        newNode->next = head; 
        return;
    }
    if (position == 1) {
        Node* last = head;
        while (last->next != head) {
            last = last->next;
        }
        last->next = newNode;
        newNode->next = head;
        head = newNode;
        return;
    }
  
    Node* current = head;
    for (int i = 1; i < position - 1; ++i) {
        current = current->next;
        if (current == head) { 
            cout << "Error: Position out of bounds." << endl;
            return;
        }
    }
    newNode->next = current->next;
    current->next = newNode;
}

void printCircularList(Node* head) {
    if (head == nullptr) {
        cout << "List is empty." << endl;
        return;
    }
    Node* temp = head;
    do {
        cout << temp->data << " -> ";
        temp = temp->next;
    } while (temp != head);
    cout << "(back to " << head->data << ")" << endl;
}
int main() {
    
    Node* head = new Node(10);
    head->next = new Node(20);
    head->next->next = new Node(30);
    head->next->next->next = head; 
    std::cout << "Original List: ";
    printCircularList(head);
   
    insertAtPosition(head, 25, 3);
    cout << "List after inserting 25 at position 3: ";
    printCircularList(head);
   
    insertAtPosition(head, 5, 1);
    cout << "List after inserting 5 at position 1: ";
    printCircularList(head);
    return 0;
}
