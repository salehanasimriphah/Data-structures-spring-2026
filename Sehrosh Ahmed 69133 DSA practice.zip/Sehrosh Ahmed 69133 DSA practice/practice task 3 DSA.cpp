#include <iostream>
#include <queue>
#include <string>
int main() {
    std::queue<std::string> customerQueue;
    customerQueue.push("Sehrosh");
    customerQueue.push("Maheen");
    customerQueue.push("Amna");
    std::cout << "Front of queue: " << customerQueue.front() << std::endl;
    std::cout << "Back of queue: " << customerQueue.back() << std::endl;
    while (!customerQueue.empty()) 
	{
        std::cout << "Dequeuing: " << customerQueue.front() << std::endl;
        customerQueue.pop();
        if (!customerQueue.empty()) {
            std::cout << "Now front: " << customerQueue.front() << std::endl;
            std::cout << "Now back: " << customerQueue.back() << std::endl;
        } else {
            std::cout << "Queue is now empty." << std::endl;
        }
    }
    return 0;
}

