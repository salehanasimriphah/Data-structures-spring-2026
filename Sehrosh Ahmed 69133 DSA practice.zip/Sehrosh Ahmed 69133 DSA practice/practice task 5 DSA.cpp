#include <iostream>
#include <string>
class Student {
public:
    std::string name;
    int rollno;
    double gpa;
    Student(std::string student_name, int student_roll_no, double student_gpa) {
        name = student_name;
        rollno = student_roll_no;
        gpa = student_gpa;
    }
    void display_info() {
        std::cout << "Name: " << name << std::endl;
        std::cout << "Roll No: " << rollno << std::endl;
        std::cout << "GPA: " << gpa << std::endl;
    }
};
int main() 
{
    Student student1("Sehrosh", 234, 3.90);
    student1.display_info();
    return 0;
}

