#include <iostream>
#include <stack>
#include <string>
int main() 
{
    std::stack<std::string> browser_history;
    browser_history.push("google.com");
    browser_history.push("github.com");
    std::cout << "Current page: " << browser_history.top() << std::endl;
    browser_history.pop();
    std::cout << "Going back to: " << browser_history.top() << std::endl;
    if (!browser_history.empty()) 
	{
        std::cout << "Stack is not empty." << std::endl;
    }
    return 0;
}

