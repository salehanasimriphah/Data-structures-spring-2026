#include <iostream>
#include <string>
class Car {
private:
    std::string brand;
    std::string model;
public:
    Car(std::string b, std::string m) 
	{
        brand = b;
        model = m;
        std::cout << "Car object created: " << brand << " " << model << std::endl;
    }
    void drive() 
	{
        std::cout << "The " << brand << " " << model << " is moving." << std::endl;
    }
};
int main() 
{
    Car myCar("Toyota", "Corolla");
    myCar.drive();
    return 0;
}

