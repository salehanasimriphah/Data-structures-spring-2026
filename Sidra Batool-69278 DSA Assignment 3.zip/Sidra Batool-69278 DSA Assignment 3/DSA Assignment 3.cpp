#include <iostream>
using namespace std;

struct Node {
    string data;
    Node* left;
    Node* right;

    Node(string val) {
        data = val;
        left = right = NULL;
    }
};

bool isOperator(string s) {
    return (s == "+" || s == "-" || s == "*" || s == "/" || s == "^");
}

Node* createTree(bool isRoot = false) {
    string val;

    if (isRoot) {
        cout << "Enter ROOT operator: ";
    } else {
        cout << "Enter node (operator or operand): ";
    }

    cin >> val;

    if (isRoot && !isOperator(val)) {
        cout << " Root must be an operator!\n";
        return createTree(true);
    }

    Node* node = new Node(val);

    if (isOperator(val)) {
        cout << "Enter LEFT child of " << val << endl;
        node->left = createTree();

        cout << "Enter RIGHT child of " << val << endl;
        node->right = createTree();
    }

   
    return node;
}

void inorder(Node* root) {
    if (!root){
	   return;
    }

    if (isOperator(root->data)) {
	   cout << "(";
    }

    inorder(root->left);
    cout << root->data;
    inorder(root->right);

    if (isOperator(root->data)) {
	   cout << ")";
    }
}

void preorder(Node* root) {
    if (!root){
	  return;
    }

    cout << root->data << " ";
    preorder(root->left);
    preorder(root->right);
}

void postorder(Node* root) {
    if (!root){
	  return;
    }

    postorder(root->left);
    postorder(root->right);
    cout << root->data << " ";
}

int main() {
    cout << " Expression Tree Builder " << endl;

    Node* root = createTree(true);

    cout << "\nInfix expression: "; 
    inorder(root);

    cout << "\nPrefix expression: ";
    preorder(root);

    cout << "\nPostfix expression: ";
    postorder(root);

    return 0;
}