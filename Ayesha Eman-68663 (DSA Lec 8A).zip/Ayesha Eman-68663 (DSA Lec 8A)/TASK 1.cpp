#include <iostream>
using namespace std;

class Stack {
private:
    int*stackArray;
    int stackSize;
    int myTop;
public:
    Stack(int size)
	{
        stackArray=new int[size];
        stackSize=size;
        myTop=-1;
    }
    ~Stack()
	{
	    delete[]stackArray;
	}
    bool isEmpty()
	{ 
	    return(myTop==-1);
    }
    bool isFull()
	{   
	    return(myTop==stackSize-1);
	}
    void push(int value)
	{
        if(isFull())
		{
		    cout<<"Stack is full! Cannot push "<<value<<endl;
			return;
		}
        stackArray[++myTop]=value;
        cout<<value<<" pushed successfully."<<endl;
    }
    int pop()
	{
        if(isEmpty())
		{
		    cout<<"Stack is empty! Cannot pop."<<endl;
			return-1;
		}
        return stackArray[myTop--];
    }
    int Top()
	{
        if(isEmpty())
		{
		    cout<<"Stack is empty! No top element."<<endl;
			return-1;
		}
        return stackArray[myTop];
    }
    void displayStack()
	{
        if(isEmpty())
		{
		    cout<<"Stack is empty."<<endl;
			return;
		}
        cout<<"Stack elements (bottom to top): ";
        for(int i=0;i<=myTop;i++)
		cout<<stackArray[i]<<" ";
        cout<<endl;
    }
};
int main(){
    Stack stack(5);
    int choice,value;
    do{
        cout<<"\nMenu\n1--PUSH\n2--POP\n3--DISPLAY\n4--TOP\n5--Exit\nEnter choice=";
        cin>>choice;
        switch(choice)
		{
        case 1:
		       cout<<"Enter value to push:";
		       cin>>value;
			   stack.push(value);
			   break;
        case 2:
		       value=stack.pop();
			   if(value!=-1)
			      cout<<"Popped:"<<value<<endl;
				  break;
        case 3:
		       stack.displayStack();
			   break;
        case 4:
		       value=stack.Top();
			   if(value!=-1)
			      cout<<"Top element:"<<value<<endl;
				  break;
        case 5:
		       cout<<"Exiting program..."<<endl;
			   break;
        default:
		       cout<<"Invalid choice! Try again."<<endl;
        }
    }while(choice!=5);
    return 0;
}
