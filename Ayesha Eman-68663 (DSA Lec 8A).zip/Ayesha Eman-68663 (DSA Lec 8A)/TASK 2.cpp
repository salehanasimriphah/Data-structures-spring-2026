#include <iostream>
#include <stack>
#include <sstream>
#include <string>
#include <cmath>
using namespace std;

int evaluatePostfix(string postfix) {
    stack<int> s;
    stringstream ss(postfix);
    string token;
    int x, y, temp;

    while (ss >> token) {
        if (isdigit(token[0])) {
            s.push(stoi(token));   
        } else {
            x = s.top(); s.pop();
            y = s.top(); s.pop();
            switch (token[0]) {
                case '+': temp = y + x; break;
                case '-': temp = y - x; break;
                case '*': temp = y * x; break;
                case '/': temp = y / x; break;
                case '%': temp = y % x; break;
                case '^': temp = pow(y, x); break;
                default: return -1;
            }
            s.push(temp);
        }
    }
    return s.top();
}

int main() {
    string postfix;
    cout << "Enter postfix expression (space-separated): ";
    getline(cin, postfix);
    cout << "Result = " << evaluatePostfix(postfix) << endl;
    return 0;
}
