#include<iostream>
#include<string>
using namespace std;
struct exam{
	string student_name;
	string status;
};
void update_status(exam *s, string newstatus){
	s->status= newstatus;
}
int main()
{
	exam s1 = {"alice", "pass" };
	exam s2 = {"Jack", "Fail" };
	exam s3 = {"june", "Pass" };
	cout << "Before update: " << s1.student_name  << " status  "<< s1.status << endl; 
	cout << "Before update: " << s2.student_name  << " status  "<< s2.status << endl; 
	cout << "Before update: " << s3.student_name   << " status  " << s3.status << endl; 
	cout<<endl;
	update_status(&s1, "fail");
	cout << "After update: " << s1.student_name  << " status  "<< s1.status << endl; 
	return 0;
	
}
