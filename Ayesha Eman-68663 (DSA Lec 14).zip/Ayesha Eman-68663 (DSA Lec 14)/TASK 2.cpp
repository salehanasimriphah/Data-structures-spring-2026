#include <iostream>
using namespace std;

// Recursive function to calculate factorial of n
int F(int n)
{
    if (n == 0)
        return 1; // base case
    else
        return n * F(n - 1); // recursive step
}

int main()
{
    int n;
    cout << "Enter a number: ";
    cin >> n;

    cout << "Factorial of " << n << " is: " << F(n) << endl;

    return 0;
}
