#include <iostream>
using namespace std;

// Recursive function to print array elements in reverse order
void printArray(int array[], int size)
{
    if (size == 0)
        return; // base case
    else
    {
        cout << array[size - 1] << endl; // print current element
        printArray(array, size - 1);     // recursive call
    }
}

int main()
{
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int array[size];
    cout << "Enter " << size << " elements: ";
    for (int i = 0; i < size; i++)
        cin >> array[i];

    cout << "\nArray elements in reverse order:\n";
    printArray(array, size);

    return 0;
}
