#include <iostream>
using namespace std;

// Recursive function to calculate the sum of numbers from 1 to n
int sum(int n)
{
    if (n == 1)
        return n; // base case
    else
        return n + sum(n - 1); // recursive step
}

int main()
{
    int n;
    cout << "Enter a positive integer: ";
    cin >> n;

    cout << "Sum of numbers from 1 to " << n << " is: " << sum(n) << endl;

    return 0;
}
