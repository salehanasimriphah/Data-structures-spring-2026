#include <iostream>
using namespace std;

// Recursive function to solve Tower of Hanoi
void Move(int n, char Beg, char Aux, char End)
{
    if (n == 1)
        cout << "Move the top disk from " << Beg << " to " << End << endl;
    else
    {
        Move(n - 1, Beg, End, Aux);   // Move n-1 disks from Beg to Aux
        Move(1, Beg, Aux, End);       // Move the remaining disk to End
        Move(n - 1, Aux, Beg, End);   // Move n-1 disks from Aux to End
    }
}

int main()
{
    int n;
    cout << "Enter the number of disks: ";
    cin >> n;

    cout << "\nSequence of moves:\n";
    Move(n, 'A', 'B', 'C'); // A = source, B = auxiliary, C = destination

    return 0;
}
