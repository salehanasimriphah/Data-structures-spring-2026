#include <iostream>
using namespace std;

// Recursive function to calculate x raised to the power n
int power(int x, int n)
{
    if (n == 0)
        return 1; // base case
    else
        return x * power(x, n - 1); // recursive step
}

int main()
{
    int x, n;
    cout << "Enter base number (x): ";
    cin >> x;
    cout << "Enter exponent (n): ";
    cin >> n;

    cout << x << " raised to the power " << n << " is: " << power(x, n) << endl;

    return 0;
}
