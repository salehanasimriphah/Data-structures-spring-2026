#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

void insertAtFourth(Node*& head, int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->prev = NULL;
    newNode->next = NULL;

    Node* temp = head;
    int count = 1;

    while (temp != NULL && count < 3) {
        temp = temp->next;
        count++;
    }

    if (temp == NULL) {
        cout << "List has fewer than 3 nodes, cannot insert at 4th position." << endl;
        delete newNode;
        return;
    }

    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next != NULL) {
        temp->next->prev = newNode;
    }
    temp->next = newNode;
}

void display(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    Node* head = new Node{10, NULL, NULL};
    Node* second = new Node{20, head, NULL};
    head->next = second;
    Node* third = new Node{30, second, NULL};
    second->next = third;
    Node* fourth = new Node{40, third, NULL};
    third->next = fourth;
    Node* fifth = new Node{50, fourth, NULL};
    fourth->next = fifth;

    cout << "Original List: ";
    display(head);

    insertAtFourth(head, 99);

    cout << "After inserting 99 at 4th position: ";
    display(head);

    return 0;
}
