#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

void deleteFromEnd(Node*& head) {
    if (head == NULL) {
        cout << "List is empty, nothing to delete." << endl;
        return;
    }

    if (head->next == NULL) {
        delete head;
        head = NULL;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }

    temp->prev->next = NULL;
    delete temp;
}

void printList(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    
    Node* head = new Node{10, NULL, NULL};
    Node* second = new Node{20, head, NULL};
    head->next = second;
    Node* third = new Node{30, second,NULL};
    second->next = third;
    Node* fourth = new Node{40, third, NULL};
    third->next = fourth;

    cout << "Original List: ";
    printList(head);

    deleteFromEnd(head);

    cout << "After deleting from end: ";
    printList(head);

    return 0;
}
