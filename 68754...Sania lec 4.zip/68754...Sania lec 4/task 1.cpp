#include<iostream>
class Animal {
public: 
    
    std::string name;
    std::string breed;
    int age;

    
    void eat() {
       
        std::cout << name << " is eating." << std::endl;
    }

    void play() {
        
        std::cout << name << " is playing." << std::endl;
    }

    void sleep() {
        
        std::cout << name << " is sleeping." << std::endl;
    }
};
int main() { 
 
Animal dog; 
 
dog.name = "Buddy"; 
dog.breed = "Golden Retriever"; 
dog.age = 5;  
dog.play(); 
dog.sleep(); 
return 0; }
