#include <iostream>
using namespace std;

#define SIZE 5   

class Queue {
private:
    int A[SIZE];
    int front, rear;

public:
    Queue() {
        front = rear = -1;
    }
    bool isempty() {
        return (front == -1 && rear == -1);
    }
    void enqueue(int value) {
        if ((rear + 1) % SIZE == front) {
            cout << "Queue is full" << endl;
        } else {
            if (front == -1) front = 0; 
            rear = (rear + 1) % SIZE;
            A[rear] = value;
        }
    }
    void dequeue() {
        if (isempty()) {
            cout << "Queue is empty" << endl;
        } else if (front == rear) {
            front = rear = -1;
        } else {
            front = (front + 1) % SIZE;
        }
    }
    void showfront() {
        if (isempty()) {
            cout << "Queue is empty" << endl;
        } else {
            cout << "Element at front is: " << A[front] << endl;
        }
    }
    void displayQueue() {
        if (isempty()) {
            cout << "Queue is empty" << endl;
        } else {
            cout << "Queue elements: ";
            int i = front;
            while (true) {
                cout << A[i] << " ";
                if (i == rear) break;
                i = (i + 1) % SIZE;
            }
            cout << endl << "Rear = " << rear << endl;
        }
    }
};

int main() {
    Queue obj;

    obj.dequeue();       
    cout << "Queue created:" << endl;

    obj.enqueue(10);
    obj.enqueue(20);
    obj.enqueue(30);
    obj.enqueue(40);
    obj.enqueue(50);

    obj.displayQueue();

    obj.enqueue(60);   
    obj.dequeue();
    obj.displayQueue();

    obj.enqueue(60);
    obj.displayQueue();

    obj.enqueue(70);   
    obj.showfront();   

    return 0;
}
