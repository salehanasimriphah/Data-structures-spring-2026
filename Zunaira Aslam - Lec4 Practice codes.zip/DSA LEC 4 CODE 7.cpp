#include <iostream>
using namespace std;
// Base class
class Parent {
public:
    void show() {
        cout << "This is Parent class function." << endl;
}
};
// Derived class
class Child : public Parent {
public:
    void show() {
        cout << "This is Child class function." << endl;
    }
};
int main() {
    Child obj;

    obj.show();          // Calls Child function
    obj.Parent::show();  // Calls Parent function

return 0;
}
