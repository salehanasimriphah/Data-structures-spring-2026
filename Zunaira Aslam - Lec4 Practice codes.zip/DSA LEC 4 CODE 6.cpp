#include <iostream>
using namespace std;
class Parent {
public:
void show() {
cout << "This is Parent class function." << endl;
    }
};

class Child : public Parent {
public:
    void show() {
        cout << "This is Child class function." << endl;
    }
};

int main() {
    Child obj;
    obj.show();

    return 0;
}
