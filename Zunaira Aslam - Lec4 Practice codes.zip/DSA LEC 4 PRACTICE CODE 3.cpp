#include <iostream>
using namespace std;

class Student {
    int age;

public:
    Student() {
        age = 10;
    }
    Student(int a) {
        age = a;
    }

    void show() {
        cout << "Age = " << age << endl;
    }
};

int main() {
Student obj1;
cout << "Default Constructor Output:" << endl;
obj1.show();
cout << endl;
Student obj2(25);
cout << "Parameterized Constructor Output:" << endl;
obj2.show();

    return 0;
}
