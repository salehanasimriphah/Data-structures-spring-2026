#include <iostream>
using namespace std;

class Student {
    int age;

public:
Student() {
age = 0;
  }

    Student(int a) {
        age = a;
    }

    void show () {
        cout << "Age = " << age << endl;
    }
};

int main() {
    Student s1;
    Student s2(25);

    s1.show();
    s2.show();

    return 0;
}
