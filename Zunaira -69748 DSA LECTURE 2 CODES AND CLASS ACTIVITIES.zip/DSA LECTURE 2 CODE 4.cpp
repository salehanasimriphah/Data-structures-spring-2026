#include <iostream>
#include <string>
using namespace std;
class Robot {
public:
    string name;
    string model;

  Robot(string robotName, string robotModel) {
        name = robotName;
        model = robotModel;
 }
};

int main() {
    Robot my_robot("Wall-E", "Cleaner-Bot");
    cout << "Robot Name: " << my_robot.name << endl;
    cout << "Robot Model: " << my_robot.model << endl;
 return 0;
}

