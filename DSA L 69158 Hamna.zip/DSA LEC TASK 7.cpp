#include<iostream>
using namespace std;

struct Exam{
	string name;
	string status;

};

void update(Exam*e , string new_status){
	cout<<"Student status before updation: "<<e->status<<endl;
	
	e->status=new_status;
	
	cout<<"Student name: "<<e->name<<endl;
	cout<<"Status after updation: "<<e->status<<endl;
}




int main(){
    Exam*exam=new Exam();
    exam->name="Alice";
    exam->status="pass";
    
    update(exam , "fail");
    
    Exam*exam1=new Exam();
    exam1->name="Jack";
    exam->status="fail";
    
    Exam*exam2= new Exam();
    exam2->name="june";
    exam2->status="pass";
    
    
}
