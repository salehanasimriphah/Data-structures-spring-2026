#include<iostream>
using namespace std;

class Car{
	string brand;
	string model;
	
	public:
		Car(string m , string b){
			model=m;
			brand=b;
		}
		
	public:
		void drive(){
			cout<<model<<" of brand "<<brand<<" is moving";
		}
};

int main(){
	Car car_object("Mercedez" , "Benz AG");
	car_object.drive();
}
