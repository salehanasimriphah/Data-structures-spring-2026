#include<iostream>
using namespace std;

class BankAccount{
	string customer_name;
	int account_number;
	double balance;
	
	public:
		BankAccount(){
			customer_name="No name";
			account_number=0;
			balance=0.00;
		}
		
	public:
	  BankAccount(string name , int num , double b){
		customer_name=name;
		account_number=num;
		balance=b;
	}
	
	public:
		BankAccount(const BankAccount&other){
			customer_name=other.customer_name;
			account_number=other.account_number;
			balance=other.balance;
		}
		
	public:
		void display(){
			cout<<"Customer name: "<<customer_name<<endl;
			cout<<"Account Number: "<<account_number<<endl;
			cout<<"Balance: "<<balance<<endl;
		}
};

int main(){
	BankAccount b1;
	b1.display();
	
	BankAccount b2("Hina" , 237899 ,120000.0);
	b2.display();
	
	BankAccount b3=b2;
	b3.display();
}
