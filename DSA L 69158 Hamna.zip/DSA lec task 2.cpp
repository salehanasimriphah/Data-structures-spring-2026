#include<iostream>
using namespace std;

class Student{
	string name;
	int rollno;
	double gpa;
	
	public:
		Student(string n , int num , double g){
			name=n;
			rollno=num;
			gpa=g;
		}
		
	public:
		void display_info(){
			cout<<"Name: "<<name<<endl;
			cout<<"Student rollnumber: "<<rollno<<endl;
			cout<<"Student gpa: "<<gpa<<endl;
		}
};

int main(){
	Student student1("Hania" , 23 , 3.45);
	Student student2("Ali" , 56 , 3.96);
	Student student3("Zimal" , 12 , 3.66);
	
	student1.display_info();
	student2.display_info();
	student3.display_info(); 
	
}
