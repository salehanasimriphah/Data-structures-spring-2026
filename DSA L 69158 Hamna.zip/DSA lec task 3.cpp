#include<iostream>
using namespace std;

class Robot{
	string name;
	string model;
	
	public:
		Robot(string n ,string m){
			name=n;
			model=m;
		}
	 
	public:
		Robot(const Robot& other){
			name=other.name;
			model=other.model;
		}
		
	public:
		void display(){
			cout<<"Robot name: "<<name<<endl;
			cout<<"Robot model: "<<model<<endl;
		}
};

int main(){
	Robot my_robot("Robo_waiter" , "Samsung");
	Robot my_robot1=my_robot;
	
	
	my_robot.display();
	my_robot1.display();
}
