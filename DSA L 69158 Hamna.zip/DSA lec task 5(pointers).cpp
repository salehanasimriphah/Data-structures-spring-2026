#include<iostream>
using namespace std;

int main(){
	int a=10;
	int*ptr=&a;
	
	cout<<"Value of a: "<<a<<endl;
	cout<<"Adress of variable: "<<&a<<endl;
	cout<<"Address of a pointer: "<<ptr<<endl;
	cout<<"Value of pointer: "<<*ptr<<endl;
	
}
