#include<iostream>
using namespace std;

struct student
{
    int rollno;
    char name[20];
};

int main()
{
    student s1;   

    cout<<"Enter roll number: ";
    cin>>s1.rollno;

    cout<<"Enter name: ";
    cin>>s1.name;   }
    