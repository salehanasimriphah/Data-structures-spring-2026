#include<iostream>
#include<string>
using namespace std;

class Student
{
    int age;

public:
    Student()
    {
        age = 10;
    }

    void show()
    {
        cout << "age = " << age << endl;
    }
};

int main()
{
    Student obj1;
    obj1.show();

    return 0;
}