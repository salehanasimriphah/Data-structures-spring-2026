#include<iostream>
#include<string>
using namespace std;

class student
{
    string name;
    int age;

public:
    student()   // constructor
    {
        name = "sana";
        age = 20;
    }

    void show()
    {
        cout << "Your name is " << name << endl;
        cout << "Your age is " << age << endl;
    }
};

int main()
{
    student s;
    s.show();

    return 0;
}