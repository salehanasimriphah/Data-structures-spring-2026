#include<iostream>
using namespace std;

class construct
{
public:
    float area;   // ? semicolon added

    // Constructor with no parameters
    construct()
    {
        area = 0;
    }

    // Constructor with two parameters
    construct(int a, int b)
    {
        area = a * b;
    }

    void disp()
    {
        cout << area << endl;
    }
};

int main()
{
    // Constructor Overloading
    construct o;          // calls default constructor
    construct o2(10, 20); // calls parameterized constructor

    o.disp();
    o2.disp();

    return 0;   // ? corrected
}