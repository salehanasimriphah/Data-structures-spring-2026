#include<iostream>
#include<string>
using namespace std;

class Student
{
    int age;

public:
    Student(int a)
    {
        age = a;  
    }

    void show()
    {
        cout << "age = " << age << endl;
    }
};

int main()
{
    Student obj(10);
    obj.show();

    return 0;
}
