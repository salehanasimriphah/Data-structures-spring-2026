#include<iostream>
#include<cstring>
using namespace std;

struct student
{
    int rollno;
    char name[20];
};

int main()
{
    student *stu;        
    stu = new student;   

    stu->rollno = 1;
    strcpy(stu->name, "Rameeha");

    cout << "Roll No: " << stu->rollno << endl;
    cout << "Name: " << stu->name << endl;

    delete stu;   

    return 0;
}
