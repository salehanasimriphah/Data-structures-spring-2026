#include<iostream>
#include<string>
using namespace std;

class student
{
public:
    string name;
    int age;

    void show()
    {
        cout<<"Your name is: "<<name<<endl;
        cout<<"Your age is: "<<age<<endl;
    }
};

int main()
{
    student obj1;

    obj1.name = "sara";
    obj1.age = 23;

    obj1.show();

    return 0;
}