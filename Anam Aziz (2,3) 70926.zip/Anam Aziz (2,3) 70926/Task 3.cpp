#include<iostream>
#include<queue>
#include<string>
using namespace std;

int main(){
   
  
	queue<string> customerQueue;

	
	customerQueue.push("Anam");
	customerQueue.push("Elice");
	customerQueue.push("Jane");
	customerQueue.push("Peter");
	
    cout<<"Front of queue: "<<customerQueue.front()<<endl;
    cout<<" Back of queue: "<<customerQueue.back()<<endl;
    
    while(!customerQueue.empty()){
    	cout<<"Dequeuing: "<<customerQueue.front()<<endl;
    	customerQueue.pop();
	}
    
    if(!customerQueue.empty()){
    	
    cout<<"Now Front of queue: "<<customerQueue.front()<<endl;
    cout<<"Now  Back of queue: "<<customerQueue.back()<<endl;	
    	
	}
	else{
		cout<<"Queue is not empty "<<endl;
	}
	return 0;
}


