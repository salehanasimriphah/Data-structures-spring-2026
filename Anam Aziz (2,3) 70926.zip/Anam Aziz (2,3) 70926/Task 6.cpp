#include <iostream>
#include <string>
using namespace std;

class BankAccount {

    string name;
    int accountNumber;
    double balance;
public:
    BankAccount() : name("Unknown"), accountNumber(0), balance(0.0) {}
    
    BankAccount(string n, int accnum, double b){
    	name=n;
    	accountNumber=accnum;
    	balance=b;
	}
      
        
    BankAccount(const BankAccount& other)
        : name(other.name), accountNumber(other.accountNumber), balance(other.balance) {}
        
    void display() {
        cout<<"Name: "<<name<<endl;
        cout<<"Account number: "<<accountNumber<<endl;
        cout<<"Balance: "<<balance<<endl;
    }
};
int main()
{
	BankAccount a1; 
    BankAccount a2("Anam", 70926, 7065.67); 
    BankAccount a3 = a2;
    a1.display();
    a2.display();
    a3.display();
    return 0;

}
