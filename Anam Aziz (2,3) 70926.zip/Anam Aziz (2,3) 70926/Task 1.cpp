#include<iostream>
using namespace std;

class car{
	string model;
	string brand;
	public:
	car(string b,string m){
		brand=b;
		model=m;
		cout<<"Car object created "<<model<<""<<brand<<endl;
	}
	
	void drive(){
		cout<<"The"<<brand<<""<<model<<"is moving " <<endl;

	}
};
int main(){
	car c("Honda","Civic");
	c.drive();
}
