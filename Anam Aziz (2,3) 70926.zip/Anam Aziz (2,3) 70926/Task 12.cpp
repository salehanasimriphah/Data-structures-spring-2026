#include <iostream>
using namespace std;

struct Student {
    string name;
    int marks;
};

void updateMarks(Student* s, int newMarks) 
{    
s->marks = newMarks; 
}
int main() 
	{    Student s1 = {"Anam", 85};    
	cout << "Before update: " << s1.name << " has " << s1.marks << " marks." << endl;    

    updateMarks(&s1, 94);
    cout << "After update: " << s1.name << " has " << s1.marks << " marks." << endl;
    return 0;
}
