#include <iostream>
#include <stack>
#include <cmath>

using namespace std;
int evaluatePostfix(string postfix) {
    stack<int> s;

    for (int i = 0; i < postfix.length(); i++) {

        if (isdigit(postfix[i])) {
            s.push(postfix[i] - '0');
        }
        else {
            int x = s.top(); s.pop();
            int y = s.top(); s.pop();

            int temp;

            switch (postfix[i]) {
            case '+': temp = y + x; break;
            case '-': temp = y - x; break;
            case '*': temp = y * x; break;
            case '/': temp = y / x; break;
            case '%': temp = y % x; break;
            case '^': temp = pow(y, x); break;
            }

            s.push(temp);
        }
    }
return s.top();
}
int main() {
    string exp;
    cout << "Enter postfix expression: ";
    cin >> exp;

    cout << "Result: " << evaluatePostfix(exp);

    return 0;
}
