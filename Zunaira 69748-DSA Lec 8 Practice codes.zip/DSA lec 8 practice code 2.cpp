#include <iostream>
using namespace std;
class Stack {
private:
    int* stackArray;
    int stackSize;
    int topIndex;
public:
    Stack(int size) {
        stackSize = size;
        stackArray = new int[stackSize];
        topIndex = -1;
    }
	Stack() {
        delete[] stackArray;
    }
	bool isEmpty() {
        return topIndex == -1;
    }
	bool isFull() {
        return topIndex == stackSize - 1;
    }

    void push(int value) {
        if (!isFull()) {
            stackArray[++topIndex] = value;
        } else {
            cout << "Stack Overflow\n";
        }
    }

    int pop() {
        if (!isEmpty()) {
            return stackArray[topIndex--];
        } else {
            cout << "Stack Underflow\n";
            return -1;
        }
    }

    void displayStack() {
        for (int i = topIndex; i >= 0; i--) {
            cout << stackArray[i] << " ";
        }
        cout << endl;
    }
};
int main() {
    Stack s(5);
	s.push(10);
    s.push(20);
    s.push(30);
	s.displayStack();

    s.pop();
    s.displayStack();
return 0;
}
