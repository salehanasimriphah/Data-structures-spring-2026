#include <iostream>
using namespace std;
const int STACK_CAPACITY = 100;
class Stack {
private:
    int myArray[STACK_CAPACITY];
    int myTop;
public:
    Stack() {
	myTop = -1;
    }
bool isEmpty() {
        return (myTop == -1);
    }
bool isFull() {
        return (myTop == STACK_CAPACITY - 1);
    }
	void push(int value) {
        if (!isFull()) {
            myArray[++myTop] = value;
        } else {
            cout << "Stack Overflow\n";
        }
    }

    int pop() {
        if (!isEmpty()) {
            return myArray[myTop--];
        } else {
            cout << "Stack Underflow\n";
            return -1;
        }
    }

    int top() {
        if (!isEmpty()) {
            return myArray[myTop];
        } else {
            cout << "Stack is empty\n";
            return -1;
        }
    }

    void displayStack() {
        if (isEmpty()) {
            cout << "Stack is empty\n";
            return;
        }

        for (int i = myTop; i >= 0; i--) {
            cout << myArray[i] << " ";
        }
        cout << endl;
    }
};
int main() {
    Stack s;
    int choice, value;

    do {
        cout << "\n1. Push\n2. Pop\n3. Display\n4. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value: ";
            cin >> value;
            s.push(value);
            break;
        case 2:
            cout << "Popped: " << s.pop() << endl;
            break;
        case 3:
            s.displayStack();
            break;
        }
    } while (choice != 4);

    return 0;
}
