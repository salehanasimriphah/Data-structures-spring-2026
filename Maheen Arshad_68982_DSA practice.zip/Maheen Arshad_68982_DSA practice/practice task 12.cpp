#include <iostream>
using namespace std;
struct Student {
    string name;
    int marks;
};
void updateMarks(Student* s, int newMarks) 
{    
s->marks = newMarks;  
}
          int main() 
	{    Student s1 = {"Maheen",98};    
	cout << "Before update: " << s1.name << " has " << s1.marks << " marks." << endl;    
    updateMarks(&s1, 90);
    cout << "After update: " << s1.name << " has " << s1.marks << " marks." << endl;
    return 0;
}

