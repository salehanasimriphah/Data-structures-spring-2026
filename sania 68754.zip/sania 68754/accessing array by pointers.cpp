#include<iostream>
using namespace std;

int main(){
	
	int arr[5]={1,2,3,4,5};
	int *ptr=arr;
	
	cout<<"elements are:"<<endl;
	for(int i=0;i<5;i++){
		
		cout<<"element"<<i<<"="<<ptr[i]<<endl;
	}
return 0;	
}