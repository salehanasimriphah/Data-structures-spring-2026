#include <iostream>
#include <string>
using namespace std;

class Car {
public:
    string name;
    string model;
    
    // Constructor in C++
    Car(string carName, string carModel) {
        name = carName;
        model = carModel;
    }
    void display() {
        cout << "Car Name: " << name << endl;
        cout << "Car Model: " << model << endl;
    }
};

int main() {
    // Creating object of Car class
    Car c1("Toyota", "Corolla");

    // Calling function
    c1.display();

    return 0;
}

