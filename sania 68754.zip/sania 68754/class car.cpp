#include <iostream>
#include <string>
using namespace std;

class Car {
private:
    string brand;
    string model;
public:
   
    Car(string b, string m) {
        brand = b;
        model = m;
        cout<<"Car object created: "<<brand<<" "<<model<<endl;
    }
    // 2. Class Method (Behavior)
    void drive() {
        cout<<"The "<<brand<<" "<<model<<"is moving."<<endl;
    }
};
int main() {
    // 3. Use of the Constructor (Instantiating the class)
    Car myCar("Toyota", "Corolla");
    // Calling the method
    myCar.drive();
    return 0;
}