#include<iostream>
using namespace std;

void swap(int *a,int*b){
	int temp=*a;
	*a=*b;
	*b=temp;
}

int main(){
	
	int x,y;
	cout<<"enter 2 numbers"<<endl;
	cin>>x;
	cin>>y;
	
	cout<<"before swapping"<<x<<endl<<y<<endl;
	swap(&x,&y);
	cout<<"after swapping"<<x<<endl<<y<<endl;
	return 0;

}