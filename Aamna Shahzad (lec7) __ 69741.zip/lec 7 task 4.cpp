#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* deleteStart(Node* head) {
    if (head == NULL) return NULL;

    if (head->next == head) {
        delete head;
        return NULL;
    }

    Node* temp = head;
    Node* last = head;

    while (last->next != head) {
        last = last->next;
    }

    head = head->next;
    last->next = head;

    delete temp;
    return head;
}

void display(Node* head) {
    if (head == NULL) return;

    Node* temp = head;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);
}

int main() {
    Node* head = NULL;

    Node* n1 = new Node{10, NULL};
    Node* n2 = new Node{20, NULL};

    n1->next = n2;
    n2->next = n1;
    head = n1;

    head = deleteStart(head);
    display(head);
}
