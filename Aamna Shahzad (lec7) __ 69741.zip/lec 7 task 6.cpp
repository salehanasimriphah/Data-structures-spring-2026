#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* deletePosition(Node* head, int pos) {
    if (head == NULL) return NULL;

    if (pos == 1) {
        if (head->next == head) {
            delete head;
            return NULL;
        }

        Node* last = head;
        while (last->next != head) {
            last = last->next;
        }

        Node* temp = head;
        head = head->next;
        last->next = head;

        delete temp;
        return head;
    }

    Node* temp = head;
    Node* prev = NULL;

    for (int i = 1; i < pos; i++) {
        prev = temp;
        temp = temp->next;
    }

    prev->next = temp->next;
    delete temp;

    return head;
}

void display(Node* head) {
    if (head == NULL) return;

    Node* temp = head;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);
}

int main() {
    Node* head = NULL;

    Node* n1 = new Node{10, NULL};
    Node* n2 = new Node{20, NULL};
    Node* n3 = new Node{30, NULL};

    n1->next = n3;
    n3->next = n2;
    n2->next = n1;
    head = n1;

    head = deletePosition(head, 2);
    display(head);
}
