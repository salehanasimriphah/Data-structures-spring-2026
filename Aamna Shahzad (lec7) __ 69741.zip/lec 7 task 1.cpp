#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* insertStart(Node* head, int value) {
    Node* newNode = new Node;
    newNode->data = value;

    if (head == NULL) {
        newNode->next = newNode;
        head = newNode;
    } else {
        Node* temp = head;
        while (temp->next != head) {
            temp = temp->next;
        }
        newNode->next = head;
        temp->next = newNode;
        head = newNode;
    }
    return head;
}

void display(Node* head) {
    if (head == NULL) return;

    Node* temp = head;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);
}

int main() {
    Node* head = NULL;
   head= insertStart(head, 10);
    head= insertStart(head, 20);
    display(head);
}
