#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* deleteEnd(Node* head) {
    if (head == NULL) return NULL;

    if (head->next == head) {
        delete head;
        return NULL;
    }

    Node* temp = head;
    Node* prev = NULL;

    while (temp->next != head) {
        prev = temp;
        temp = temp->next;
    }

    prev->next = head;
    delete temp;

    return head;
}

void display(Node* head) {
    if (head == NULL) return;

    Node* temp = head;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);
}

int main() {
    Node* head = NULL;

    Node* n1 = new Node{10, NULL};
    Node* n2 = new Node{20, NULL};

    n1->next = n2;
    n2->next = n1;
    head = n1;

    head = deleteEnd(head);
    display(head);
}
