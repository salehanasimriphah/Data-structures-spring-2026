#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* insertPosition(Node* head, int value, int pos) {
    Node* newNode = new Node;
    newNode->data = value;

    if (pos == 1) {
        if (head == NULL) {
            newNode->next = newNode;
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != head) {
                temp = temp->next;
            }
            newNode->next = head;
            temp->next = newNode;
            head = newNode;
        }
        return head;
    }

    Node* temp = head;
    for (int i = 1; i < pos - 1; i++) {
        temp = temp->next;
    }

    newNode->next = temp->next;
    temp->next = newNode;

    return head;
}

void display(Node* head) {
    if (head == NULL) return;

    Node* temp = head;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);
}

int main() {
    Node* head = NULL;
    head = insertPosition(head, 10, 1);
    head = insertPosition(head, 20, 2);
    head = insertPosition(head, 15, 3);
    display(head);
}
