#include <iostream>
using namespace std;
struct node
{
int data;
node* next;
node* prev;
};
void insertAtStart(node* &head, int value)
{
node* newnode = new node();
newnode->data = value;
newnode->next = head;
newnode->prev = NULL;
if(head != NULL)
        head->prev = newnode;
    head = newnode;
}

void display(node* head)
{
    node* temp = head;
    while(temp != NULL)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
	}
int main()
{node* head = NULL;
insertAtStart(head, 10);
insertAtStart(head, 20);
insertAtStart(head, 30);
 cout << "Doubly Linked List: ";
    display(head);
return 0;
}
