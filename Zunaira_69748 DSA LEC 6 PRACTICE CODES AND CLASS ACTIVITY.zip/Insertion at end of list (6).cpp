#include <iostream>
using namespace std;
struct node
{int data;
    node* next;
    node* prev;
};
void insertAtEnd(node* &head, int value)
{
    node* newnode = new node();
    newnode->data = value;
    newnode->next = NULL;
if(head == NULL)
{
        newnode->prev = NULL;
        head = newnode;
        return;
  }
node* temp = head;

    while(temp->next != NULL)
        temp = temp->next;
temp->next = newnode;
    newnode->prev = temp;
}

void display(node* head)
{
    node* temp = head;

    while(temp != NULL)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }

    cout << endl;
}
int main()
{
node* head = NULL;
insertAtEnd(head, 100);
    insertAtEnd(head, 200);
    insertAtEnd(head, 300);
display(head);
return 0;
}
