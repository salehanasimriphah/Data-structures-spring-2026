#include<iostream>
using namespace std;
class Node
{
public:
    int data;
    Node* prev;
    Node* next;
	Node(int d)
    {
        data = d;
        prev = NULL;
        next = NULL;
    }
};
void insertAtFourth(Node* &head, int value)
{
    Node* newNode = new Node(value);
	Node* temp = head;
	int count = 1;
// move to 3rd node
    while(count < 3 && temp != NULL)
    {
        temp = temp->next;
        count++;
    }
	if(temp == NULL)
    {
        cout<<"Position not possible"<<endl;
        return;
    }
newNode->next = temp->next;
    newNode->prev = temp;

    if(temp->next != NULL)
    {
        temp->next->prev = newNode;
    }

    temp->next = newNode;
}

void printList(Node* head)
{
    Node* temp = head;

    while(temp != NULL)
    {
        cout<<temp->data<<" ";
        temp = temp->next;
    }
}

int main()
{
    Node* head = new Node(10);
    Node* second = new Node(20);
    Node* third = new Node(30);
    Node* fourth = new Node(40);

    head->next = second;
    second->prev = head;

    second->next = third;
    third->prev = second;

    third->next = fourth;
    fourth->prev = third;

    cout<<"Before Insertion:"<<endl;
    printList(head);

    insertAtFourth(head, 25);

    cout<<"\nAfter Insertion:"<<endl;
    printList(head);

    return 0;
}
