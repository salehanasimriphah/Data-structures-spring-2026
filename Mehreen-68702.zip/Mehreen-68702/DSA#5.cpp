#include<iostream>
using namespace std;
class BankAccount{
	private:
		string AccountHolder;
		int AccountNumber;
		float balance;
		public:
			BankAccount()
			{
				AccountHolder = "unknown";
				AccountNumber = 0;
				balance = 0.0;
			}
			BankAccount(string name,int no,float amount)
			{
				AccountHolder = name;
				AccountNumber = no;
				balance = amount;
			}
			BankAccount(const BankAccount& other)
			{
				AccountHolder = other.AccountHolder;
				AccountNumber = other.AccountNumber;
				balance = other.balance;
			}
			void displayInfo()
			{
				cout<<"Name: "<<AccountHolder<<endl;
				cout<<"Account Number: "<<AccountNumber<<endl;
				cout<<"Account Balance: "<<balance<<endl;
			}
};
int main()
{
	BankAccount p1("Mehmood",75342,5000.20);
	BankAccount p2 = p1;
	p1.displayInfo();
	p2.displayInfo();
	return 0;
}