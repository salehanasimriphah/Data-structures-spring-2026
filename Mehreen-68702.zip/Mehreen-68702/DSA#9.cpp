#include <iostream>
using namespace std;
struct Process {
    string name;
    string status;
};
void updateStatus(Process* p, string newStatus) {
    p->status = newStatus; 
}
int main() 
{
    
   Process students[3] = {
        {"Alice", "Pass"},
        {"Jack", "Fail"},
        {"June", "Pass"}
    };
    cout << "Before Update: " << students[0].name << " is " << students[0].status << endl;
    updateStatus(&students[0], "Fail");
    cout << "After Update:  " << students[0].name << " is " << students[0].status << endl;

    return 0;
}
