#include<iostream>
using namespace std;
class Car{
	private:
	 string brand;
	 string model;
	public:
	 Car(string b,string m)
	 {
	 	brand = b;
	 	model = m;
	 }
	 void drive() {
        cout << "The " << brand << " " << model << " is moving." <<endl;
    }
	
};
int main()
{
	Car c1("civic","corolla");
	c1.drive();
	return 0;
}