#include<iostream>
using namespace std;
class Student{
	public:
	int rollNo;
	string name;
	float GPA;
Student(int R,string n,float g)
	{
		rollNo = R;
		name = n;
		GPA = g;
	}
 void displayInfo()
	{
		cout<<"Name: "<<name<<endl;
		cout<<"rollNo: "<<rollNo<<endl;
		cout<<"GPA: "<<GPA<<endl;
	}
	
};
int main()
{
	Student s1(23421,"Mehreen",3.8);
	s1.displayInfo();
	return 0;
}