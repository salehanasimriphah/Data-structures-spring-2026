#include<iostream>
#include<queue>
#include<string>
int main()
{
	std::queue<std::string>customer_name;
	customer_name.push("Ali");
	customer_name.push("Mehreen");
	customer_name.push("Dua");
	customer_name.pop();
	std::cout<<"Current position"<<customer_name.front()<<std::endl;
	if(!customer_name.empty())
	{
		std::cout << "queue is not empty." << std::endl;
	}
}

