#include<iostream>
using namespace std;
struct Node{
	int data;
	Node* next;
};
void inseartatbeginning(Node*& head, int value){
	Node* newNode = new Node();
	newNode->data = value;
	newNode->next = head;
	head = newNode;
}
void display(Node* head){
	Node* temp = head;
	while(temp!= 0){
		cout<<temp-> next<<"  "<<endl;
		temp = temp-> next ;
		
	}
}
int main(){
	Node* head = 0;
	inseartatbeginning(head, 50);
	inseartatbeginning(head, 40);
	inseartatbeginning(head, 30);
	inseartatbeginning(head, 20);
	inseartatbeginning(head, 10);
	cout<<"Linked list after insertion:";
	display(head);
	return 0;
	
}

