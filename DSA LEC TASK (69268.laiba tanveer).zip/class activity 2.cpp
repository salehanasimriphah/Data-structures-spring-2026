#include <iostream>
using namespace std;

class Student {
private:
    string name;
    int roll_no;
    float gpa;

public:
    void setData(string n, int r, float g) {
        name = n;
        roll_no = r;
        gpa = g;
    }

    void display_info() {
        cout << "Name: " << name << endl;
        cout << "Roll No: " << roll_no << endl;
        cout << "GPA: " << gpa << endl;
    }
};

int main() {
    Student s1;

    s1.setData("Tashi", 12345, 3.7);
    s1.display_info();

    return 0;
}