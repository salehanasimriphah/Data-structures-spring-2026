#include<iostream>
using namespace std;
struct Node{
	Node *prev;
	int data;
	Node *next;
};
void InsertAtBegin(Node *&head,int value){
	Node *node1=new Node();
	node1->data=value;
	node1->prev=NULL;
	
	if(head==NULL){
		node1->next=NULL;
		head=node1;
		return;
	}
	
	node1->next=head;
	head->prev=node1;
	head=node1;
}
void InsertAtEnd(Node *&head,int value){
	Node *node1=new Node();
	node1->data=value;
	
	if(head==NULL){
		node1->next=NULL;
		node1->prev=NULL;
		head=node1;
		return;
	}
	
	Node *temp=head;
	while(temp->next!=NULL){
		temp=temp->next;
	}
	
	temp->next=node1;
	node1->prev=temp;
	node1->next=NULL;
	
}
void InsertAtPosition(Node *&head,int value,int pos){
	Node *node1=new Node();
	node1->data=value;
	
	if(pos==1 && head==NULL){
		node1->next=NULL;
		node1->prev=NULL;
		head=node1;
		return;
	}
	
	if(pos==1 && head!=NULL){
		node1->next=head;
		head->prev=node1;
		head=node1;
		return;
	}
	
	if(pos!=1 && head==NULL){
		cout<<"Invalid Position"<<endl;
		delete node1;
		return;
	}
	
	Node *temp=head;
	int count=1;
	while(count<pos-1 && temp!=NULL){
		temp=temp->next;
		count++;
	}
	
	if(temp==NULL){
		cout<<"Invalid Position"<<endl;
		delete node1;
		return;
	}
	
	if(temp->next==NULL){
		temp->next=node1;
		node1->prev=temp;
		node1->next=NULL;
		return;
	}
	node1->next=temp->next;
	temp->next->prev=node1;
	temp->next=node1;
	node1->prev=temp;
	
}
void DeleteAtBegin(Node *&head){
	if(head==NULL){
		cout<<"List is empty"<<endl;
		return;
	}
	
	if(head->next==NULL){
		cout<<"Deleting: "<<head->data<<endl;
		delete head;
		head=NULL;
		return;
	}
	
	Node *del=head;
	del->next->prev=NULL;
	head=head->next;
	cout<<"Deleting: "<<del->data<<endl;
	delete del;
}
void DeleteAtEnd(Node *&head){
	if(head==NULL){
		cout<<"List is empty"<<endl;
		return;
	}
	
	if(head->next==NULL){
		cout<<"Deleting: "<<head->data<<endl;
		delete head;
		head=NULL;
		return;
	}
	
	Node *temp=head;
	while(temp->next->next!=NULL){
		temp=temp->next;
	}
	
	Node *del=temp->next;
	temp->next=NULL;
	cout<<"Deleting: "<<del->data<<endl;
	delete del;
}
void DeleteAtPosition(Node *&head,int pos){
	if(head==NULL){
		cout<<"List is empty"<<endl;
		return;
	}
	
	if(pos==1 && head->next==NULL){
		cout<<"Deleting: "<<head->data<<endl;
	    delete head;
	    head=NULL;
	    return;
	}
	
	if(pos!=1 && head==NULL){
		cout<<"Invalid Position"<<endl;
		return;
	}
	
	if(pos==1 && head->next!=NULL){
		Node *del=head;
		head->next->prev=NULL;
		head=del->next;
		cout<<"Deleting: "<<del->data<<endl;
	    delete del;
	    return;
	}
	
	Node *temp=head;
	int count=1;
	while(count<pos-1 && temp!=NULL){
		temp=temp->next;
		count++;
	}
	
	if(temp==NULL || temp->next==NULL){
		cout<<"Invalid Position"<<endl;
		return;
	}
	
	if(temp->next->next==NULL){
		Node *del =temp->next;
		temp->next=NULL;
		cout<<"Deleting: "<<del->data<<endl;
	    delete del;
		return;
	}
	
	Node *del=temp->next;
	del->next->prev=temp;
	temp->next=del->next;
	cout<<"Deleting: "<<del->data<<endl;
	delete del;
}
void display(Node *head){
	if(head==NULL){
		cout<<"List is empty"<<endl;
		return;
	}
	
	Node *temp=head;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp=temp->next;
	}
	
	cout<<endl;
}
int main(){
	Node *head=NULL;
	int choice;
	do{
		cout<<"------------- Menu ------------"<<endl;
		cout<<"1. Insert at begin"<<endl;
		cout<<"2. Insert at end"<<endl;
		cout<<"3. Insert at specific position"<<endl;
		cout<<"4. Delete at begin"<<endl;
		cout<<"5. Delete at end"<<endl;
		cout<<"6. Delete at specific position"<<endl;
		cout<<"7. Display"<<endl;
		cout<<"8. Exit"<<endl;
		cout<<endl;
		
		cout<<"Enter your choice: ";
		cin>>choice;
		
		switch(choice){
			case 1:
				int value1;
				cout<<"Enter the value: ";
				cin>>value1;
				InsertAtBegin(head,value1);
				display(head);
				break;
			case 2:
				int value2;
				cout<<"Enter the value: ";
				cin>>value2;
				InsertAtEnd(head,value2);
				display(head);
				break;
			case 3:
			    int value3;
				cout<<"Enter the value: ";
				cin>>value3;
				int position;
				cout<<"Enter the position: ";
				cin>>position;
				InsertAtPosition(head,value3,position);
				display(head);
				break;
			case 4:
				DeleteAtBegin(head);
				display(head);
				break;
			case 5:
				DeleteAtEnd(head);
				display(head);
				break;
			case 6:
				int position1;
				cout<<"Enter the position: ";
				cin>>position1;
				DeleteAtPosition(head,position1);
				display(head);
				break;
			case 7:
				display(head);
				break;
			case 8:
				cout<<"Exiting....."<<endl;
				break;
			default:
				cout<<"Invalid Choice!"<<endl;
				break;
		}
		
	}while(choice!=8);
	
	return 0;
	
	
}