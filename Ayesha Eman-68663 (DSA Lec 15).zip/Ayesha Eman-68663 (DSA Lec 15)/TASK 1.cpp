#include <iostream>
#include <algorithm>
using namespace std;

// Node structure
struct Node {
    int key;
    Node* left;
    Node* right;
    int height;

    Node(int val) {
        key = val;
        left = right = NULL;
        height = 1;
    }
};

// Get height
int getHeight(Node* n) {
    if (n == NULL) return 0;
    return n->height;
}

// Get balance factor
int getBalanceFactor(Node* n) {
    if (n == NULL) return 0;
    return getHeight(n->left) - getHeight(n->right);
}

// Update height
void updateHeight(Node* n) {
    n->height = 1 + max(getHeight(n->left), getHeight(n->right));
}

// Right Rotation
Node* rightRotate(Node* y) {
    Node* x = y->left;
    Node* T2 = x->right;

    x->right = y;
    y->left = T2;

    updateHeight(y);
    updateHeight(x);

    return x;
}

// Left Rotation
Node* leftRotate(Node* x) {
    Node* y = x->right;
    Node* T2 = y->left;

    y->left = x;
    x->right = T2;

    updateHeight(x);
    updateHeight(y);

    return y;
}

// Insert (AVL)
Node* insertRecursive(Node* node, int key) {
    // 1. Normal BST insertion
    if (node == NULL)
        return new Node(key);

    if (key < node->key)
        node->left = insertRecursive(node->left, key);
    else if (key > node->key)
        node->right = insertRecursive(node->right, key);
    else
        return node; // no duplicates

    // 2. Update height
    updateHeight(node);

    // 3. Get balance factor
    int balance = getBalanceFactor(node);

    // 4. Balance cases

    // Left Left
    if (balance > 1 && key < node->left->key)
        return rightRotate(node);

    // Right Right
    if (balance < -1 && key > node->right->key)
        return leftRotate(node);

    // Left Right
    if (balance > 1 && key > node->left->key) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    // Right Left
    if (balance < -1 && key < node->right->key) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

// Inorder Traversal
void inorder(Node* root) {
    if (root == NULL) return;

    inorder(root->left);
    cout << root->key << " ";
    inorder(root->right);
}

// Main
int main() {
    Node* root = NULL;

    // Example input
    int arr[] = {100, 50, 150, 20, 75, 125, 175, 60, 160};

    for (int i = 0; i < 9; i++) {
        root = insertRecursive(root, arr[i]);
    }

    cout << "Inorder Traversal (AVL Tree): ";
    inorder(root);

    return 0;
}